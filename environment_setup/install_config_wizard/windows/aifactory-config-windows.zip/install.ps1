[CmdletBinding()]
param(
    [string]$PackageRoot = (Join-Path $PSScriptRoot 'aifactory-config'),
    [string]$InstallDirectory,
    [switch]$NoLaunch,
    [switch]$PreserveUserData
)

$ErrorActionPreference = 'Stop'

function Assert-AIFactoryPackage {
    param([string]$Directory)
    if (-not (Test-Path -LiteralPath (Join-Path $Directory 'aifactory-config.exe') -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $Directory '_internal') -PathType Container)) {
        throw "Incomplete Windows package: $Directory. Keep the executable and _internal directory together."
    }
}

function Assert-AIFactoryIdle {
    param([string]$Directory)
    $prefix = [IO.Path]::GetFullPath($Directory).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    foreach ($process in Get-Process -Name 'aifactory-config' -ErrorAction SilentlyContinue) {
        if (-not $process.Path -or $process.Path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Close the running ESAF Config Wizard before building or installing.'
        }
    }
}

function Assert-AIFactoryPlainTree {
    param([string]$Path)
    $item = Get-Item -LiteralPath $Path -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        throw 'User data contains linked paths; update it manually without following links.'
    }
    if ($item.PSIsContainer) {
        foreach ($child in Get-ChildItem -LiteralPath $Path -Force) {
            Assert-AIFactoryPlainTree -Path $child.FullName
        }
    }
}

function New-AIFactoryShortcut {
    param([string]$Directory, [string]$ProgramsDirectory = [Environment]::GetFolderPath('Programs'))
    $programs = $ProgramsDirectory
    if (-not $programs) { throw 'The current user Start Menu directory is unavailable.' }
    $folder = Join-Path $programs 'ESAF Config Wizard'
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path $folder 'ESAF Config Wizard.lnk'))
    $shortcut.TargetPath = Join-Path $Directory 'aifactory-config.exe'
    $shortcut.WorkingDirectory = $Directory
    $shortcut.IconLocation = "$($shortcut.TargetPath),0"
    $shortcut.Save()
    $legacyFolder = Join-Path $programs 'AIFactory Config Wizard'
    $legacyPath = Join-Path $legacyFolder 'AIFactory Config Wizard.lnk'
    if (Test-Path -LiteralPath $legacyPath -PathType Leaf) {
        $legacy = $shell.CreateShortcut($legacyPath)
        if ([string]::Equals($legacy.TargetPath, $shortcut.TargetPath, [StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $legacyPath -Force
            if (-not @(Get-ChildItem -LiteralPath $legacyFolder -Force).Count) {
                Remove-Item -LiteralPath $legacyFolder
            }
        }
    }
}

function Show-AIFactoryInstallSummary {
    param([string]$Directory)
    $executable = Join-Path $Directory 'aifactory-config.exe'
    Write-Host "Installed executable: $executable" -ForegroundColor Green
    Write-Host 'Start Menu: ESAF Config Wizard'
    Write-Host 'Existing taskbar pins are not replaced by this installer.'
    Write-Host 'Unpin the old taskbar icon, open ESAF Config Wizard from Start, then pin that running window.'
    try {
        $pins = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
        if (Test-Path -LiteralPath $pins -PathType Container) {
            $shell = New-Object -ComObject WScript.Shell
            foreach ($file in Get-ChildItem -LiteralPath $pins -Filter '*.lnk' -File -Force) {
                $shortcut = $shell.CreateShortcut($file.FullName)
                if ([IO.Path]::GetFileName($shortcut.TargetPath) -ieq 'aifactory-config.exe' -and
                    -not [string]::Equals($shortcut.TargetPath, $executable, [StringComparison]::OrdinalIgnoreCase)) {
                    Write-Warning "Taskbar shortcut '$($file.Name)' points to another location: $($shortcut.TargetPath)"
                }
            }
        }
    }
    catch [Runtime.InteropServices.COMException], [UnauthorizedAccessException], [IO.IOException] {
        Write-Warning "Could not inspect taskbar shortcuts; installation succeeded. $($_.Exception.Message)"
    }
}

function Invoke-AIFactoryInstall {
    param([string]$PackageRoot, [string]$InstallDirectory, [switch]$NoLaunch, [switch]$PreserveUserData)
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'This installer requires Windows. Use build.sh for native Linux/macOS packages.'
    }
    if (-not $InstallDirectory) {
        $InstallDirectory = Join-Path $env:LOCALAPPDATA 'Programs\AIFactoryConfigWizard'
    }
    $source = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\', '/')
    $destination = [IO.Path]::GetFullPath($InstallDirectory).TrimEnd('\', '/')
    if (-not $destination -or $destination -eq [IO.Path]::GetPathRoot($destination).TrimEnd('\', '/') -or
        $source -eq $destination -or
        $source.StartsWith($destination + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
        $destination.StartsWith($source + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose a dedicated installation directory separate from the package.'
    }
    Assert-AIFactoryPackage -Directory $source
    if (Test-Path -LiteralPath $destination) { Assert-AIFactoryPackage -Directory $destination }
    Assert-AIFactoryIdle -Directory $destination
    $parent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $stage = Join-Path $parent ('.aifactory-stage-' + [Guid]::NewGuid().ToString('N'))
    $backup = Join-Path $parent ('.aifactory-backup-' + [Guid]::NewGuid().ToString('N'))
    $movedOld = $false
    $movedNew = $false
    try {
        Copy-Item -LiteralPath $source -Destination $stage -Recurse
        Assert-AIFactoryPackage -Directory $stage
        if ($PreserveUserData -and (Test-Path -LiteralPath $destination)) {
            # Preserve root user data separately from package-owned binaries.
            foreach ($item in Get-ChildItem -LiteralPath $destination -Force) {
                if ($item.Name -in @('aifactory-config.exe', '_internal')) { continue }
                Assert-AIFactoryPlainTree -Path $item.FullName
                Copy-Item -LiteralPath $item.FullName -Destination $stage -Recurse -Force
            }
            $oldInternal = Join-Path $destination '_internal'
            if ((Get-Item -LiteralPath $oldInternal -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw 'The old internal package directory is linked; update it manually without following links.'
            }
            if ((Get-Item -LiteralPath (Join-Path $stage '_internal') -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw 'The new internal package directory is linked; update it manually without following links.'
            }
            # Frozen wizard/API snapshot resolution historically wrote here. Never copy other old internal files.
            $legacySnapshots = Join-Path $oldInternal 'saved-projects'
            if (Get-Item -LiteralPath $legacySnapshots -Force -ErrorAction SilentlyContinue) {
                Assert-AIFactoryPlainTree -Path $legacySnapshots
                $newSnapshots = Join-Path $stage '_internal\saved-projects'
                if (Test-Path -LiteralPath $newSnapshots) { Assert-AIFactoryPlainTree -Path $newSnapshots }
                Copy-Item -LiteralPath $legacySnapshots -Destination (Join-Path $stage '_internal') -Recurse -Force
            }
        }
        Assert-AIFactoryIdle -Directory $destination
        if (Test-Path -LiteralPath $destination) {
            Move-Item -LiteralPath $destination -Destination $backup
            $movedOld = $true
        }
        Move-Item -LiteralPath $stage -Destination $destination
        $movedNew = $true
        New-AIFactoryShortcut -Directory $destination
    }
    catch {
        if ($movedNew) { Remove-Item -LiteralPath $destination -Recurse -Force }
        if ($movedOld) { Move-Item -LiteralPath $backup -Destination $destination }
        throw
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    }
    if ($movedOld) { Remove-Item -LiteralPath $backup -Recurse -Force }
    Show-AIFactoryInstallSummary -Directory $destination
    if (-not $NoLaunch) { Start-Process -FilePath (Join-Path $destination 'aifactory-config.exe') }
}

if ($MyInvocation.InvocationName -ne '.') {
    Invoke-AIFactoryInstall -PackageRoot $PackageRoot -InstallDirectory $InstallDirectory -NoLaunch:$NoLaunch -PreserveUserData:$PreserveUserData
}