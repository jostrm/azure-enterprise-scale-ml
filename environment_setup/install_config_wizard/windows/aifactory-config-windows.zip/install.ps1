[CmdletBinding()]
param(
    [string]$PackageRoot = (Join-Path $PSScriptRoot 'aifactory-config'),
    [string]$InstallDirectory,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'

function Assert-AIFactoryPackage {
    param([string]$Directory)
    if (-not (Test-Path -LiteralPath (Join-Path $Directory 'aifactory-config.exe') -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $Directory '_internal') -PathType Container)) {
        throw "Incomplete Windows package: $Directory. Keep the executable and _internal directory together."
    }
}

function Assert-AIFactoryIdle {
    param([string]$Directory)
    $prefix = [IO.Path]::GetFullPath($Directory).TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar
    foreach ($process in Get-Process -Name 'aifactory-config' -ErrorAction SilentlyContinue) {
        if (-not $process.Path -or $process.Path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Close the running AIFactory Config Wizard before building or installing.'
        }
    }
}

function New-AIFactoryShortcut {
    param([string]$Directory)
    $programs = [Environment]::GetFolderPath('Programs')
    if (-not $programs) { throw 'The current user Start Menu directory is unavailable.' }
    $folder = Join-Path $programs 'AIFactory Config Wizard'
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut((Join-Path $folder 'AIFactory Config Wizard.lnk'))
    $shortcut.TargetPath = Join-Path $Directory 'aifactory-config.exe'
    $shortcut.WorkingDirectory = $Directory
    $shortcut.IconLocation = "$($shortcut.TargetPath),0"
    $shortcut.Save()
}

function Invoke-AIFactoryInstall {
    param([string]$PackageRoot, [string]$InstallDirectory, [switch]$NoLaunch)
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'This installer requires Windows. Use build.sh for native Linux/macOS packages.'
    }
    if (-not $InstallDirectory) {
        $InstallDirectory = Join-Path $env:LOCALAPPDATA 'Programs\AIFactoryConfigWizard'
    }
    $source = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\', '/')
    $destination = [IO.Path]::GetFullPath($InstallDirectory).TrimEnd('\', '/')
    if (-not $destination -or $destination -eq [IO.Path]::GetPathRoot($destination).TrimEnd('\', '/') -or
        $source -eq $destination -or
        $source.StartsWith($destination + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
        $destination.StartsWith($source + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose a dedicated installation directory separate from the package.'
    }
    Assert-AIFactoryPackage -Directory $source
    if (Test-Path -LiteralPath $destination) { Assert-AIFactoryPackage -Directory $destination }
    Assert-AIFactoryIdle -Directory $destination
    $parent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $stage = Join-Path $parent ('.aifactory-stage-' + [Guid]::NewGuid().ToString('N'))
    $backup = Join-Path $parent ('.aifactory-backup-' + [Guid]::NewGuid().ToString('N'))
    $movedOld = $false
    $movedNew = $false
    try {
        Copy-Item -LiteralPath $source -Destination $stage -Recurse
        Assert-AIFactoryPackage -Directory $stage
        Assert-AIFactoryIdle -Directory $destination
        if (Test-Path -LiteralPath $destination) {
            Move-Item -LiteralPath $destination -Destination $backup
            $movedOld = $true
        }
        Move-Item -LiteralPath $stage -Destination $destination
        $movedNew = $true
        New-AIFactoryShortcut -Directory $destination
    }
    catch {
        if ($movedNew) { Remove-Item -LiteralPath $destination -Recurse -Force }
        if ($movedOld) { Move-Item -LiteralPath $backup -Destination $destination }
        throw
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    }
    if ($movedOld) { Remove-Item -LiteralPath $backup -Recurse -Force }
    Write-Host "Installed: $destination" -ForegroundColor Green
    if (-not $NoLaunch) { Start-Process -FilePath (Join-Path $destination 'aifactory-config.exe') }
}

if ($MyInvocation.InvocationName -ne '.') {
    Invoke-AIFactoryInstall -PackageRoot $PackageRoot -InstallDirectory $InstallDirectory -NoLaunch:$NoLaunch
}