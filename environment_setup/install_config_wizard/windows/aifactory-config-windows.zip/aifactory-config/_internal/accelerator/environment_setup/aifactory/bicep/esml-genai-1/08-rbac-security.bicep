targetScope = 'subscription'

// ================================================================
// RBAC SECURITY DEPLOYMENT - Phase 7 Implementation  
// This file deploys all role-based access control and security:
// - Cross-resource RBAC assignments
// - User and service principal permissions
// - AI Hub and ML platform security
// - Storage and network access control
// - External bastion and VNet permissions
// - Common resource group access (ACR, VNet)
// - VNet Reader access for all identities (unless skipExistingRoleAssignments=true)
//
// IMPORTANT NOTES FOR DEPLOYMENT:
// 1. This template should only run AFTER resources are created
// 2. Set resource existence flags correctly (amlExists, aiHubExists, etc.)
// 3. If encountering RoleAssignmentExists errors, set skipExistingRoleAssignments=true
// 4. For ResourceNotFound errors, ensure resources exist before running this template
// 5. VNet Reader access granted by default; set skipExistingRoleAssignments=true on existing projects to avoid conflicts
// 6. On existing projects: Set skipExistingRoleAssignments=true if role assignments already exist
// ================================================================

@description('Diagnostic setting level for monitoring and logging')
@allowed(['gold', 'silver', 'bronze'])
param diagnosticSettingLevel string = 'silver'

// ============== PARAMETERS ==============
@description('Environment: dev, test, prod')
@allowed(['dev', 'test', 'prod'])
param env string

@description('Project number (e.g., "005")')
param projectNumber string

@description('Location for all resources')
param location string

@description('Location suffix (e.g., "weu", "swc")')
param locationSuffix string

@description('Common resource suffix (e.g., "-001")')
param commonResourceSuffix string

// AI Factory naming
param aifactorySuffixRG string
@description('Project-specific resource suffix')
param resourceSuffix string

// Required parameters for naming convention module
param aifactorySalt10char string = ''
param randomValue string
param technicalAdminsObjectID string = ''
param technicalAdminsEmail string = ''
param subscriptionIdDevTestProd string = subscription().subscriptionId
// ============================================================================
// PS-Networking: Needs to be here, even if not used, since .JSON file
// ============================================================================
@description('Required subnet IDs from subnet calculator')
param genaiSubnetId string
param aksSubnetId string
param acaSubnetId string
@description('Optional subnets from subnet calculator')
param aca2SubnetId string = ''
param aks2SubnetId string = ''
@description('App Service / Function VNet integration subnet (delegated to Microsoft.Web/serverFarms)')
param webappSubnetId string = ''
param logicappSubnetId string = ''
@description('if projectype is not genai-1, but instead all')
param dbxPubSubnetName string = ''
param dbxPrivSubnetName string = ''

// Resource group naming
param commonRGNamePrefix string


// Enable flags from parameter files
@description('Enable Azure Machine Learning deployment')
param enableAzureMachineLearning bool = false
param enableDatafactory bool = false
@description('Enable AI Foundry Hub deployment')
param enableAIFoundryHub bool = false
@description('Add AI Foundry Hub with random naming for debugging/testing')
param addAIFoundryHub bool = false
@description('Add Azure Machine Learning with random naming for debugging/testing')
param addAzureMachineLearning bool = false
@description('Enable AI Foundry V21 deployment')
param enableAIFoundry bool = false
param addAISearch bool = false
@description('Enable AI Services deployment')
param enableAIServices bool = false

@description('Enable AI Search deployment')
param enableAISearch bool = false

@description('Enable Azure OpenAI deployment')
param enableAzureOpenAI bool = false

@description('Enable Azure AI Vision deployment')
param enableAzureAIVision bool = false

@description('Enable Azure Speech deployment')
param enableAzureSpeech bool = false

@description('Enable AI Document Intelligence deployment')
param enableAIDocIntelligence bool = false

@description('Enable Azure Function deployment')
param enableFunction bool = false

@description('Enable Azure Web App deployment')
param enableWebApp bool = false

@description('Enable Logic Apps deployment (skip adding project managed identity to shared SP/MI array when true)')
param enableLogicApps bool = false

@description('Enable Container Apps deployment')
param enableContainerApps bool = false

@description('Enable Application Insights Dashboard deployment')
param enableAppInsightsDashboard bool = false

@description('Enable Cosmos DB deployment')
param enableCosmosDB bool = false

@description('Enable PostgreSQL deployment')
param enablePostgreSQL bool = false

@description('Enable Redis Cache deployment')
param enableRedisCache bool = false

@description('Enable SQL Database deployment')
param enableSQLDatabase bool = false

// Security and networking
param addBastionHost bool = false
param bastionResourceGroup string = ''
param bastionSubscription string = ''
param bastionName string = ''
param vnetNameFullBastion string = ''
param disableContributorAccessForUsers bool = false
param disableRBACAdminOnRGForUsers bool = false
@description('Contributor role ID for RBAC assignments. Default is the built-in Contributor role.')
param contributorRoleId string = 'b24988ac-6180-42a0-ab88-20f7382dd24c'

// Required resource references. Networking parameters for calculation
param vnetNameBase string
param vnetResourceGroup_param string = ''
param vnetNameFull_param string = ''
param network_env string = ''

// Private DNS configuration
param centralDnsZoneByPolicyInHub bool = false
param privDnsSubscription_param string = ''
param privDnsResourceGroup_param string = ''
@description('Own access hub, added scale set: ARM id (/subscriptions/<sub>/resourceGroups/<rg>) of the resource group holding the bootstrap-managed private DNS zones. Empty for the bootstrap scale set and every other topology.')
param own_hub_private_dns_resource_group_id string = ''

// Resource group configuration
param commonResourceGroup_param string = ''
param projectPrefix string = 'esml-'
param projectSuffix string = '-rg'
// Seeding Key Vault parameters
param inputKeyvault string
param inputKeyvaultResourcegroup string
param inputKeyvaultSubscription string
param projectServicePrincipleOID_SeedingKeyvaultName string

param useAdGroups bool = true
// Azure ML Object ID for cross-service permissions
param azureMachineLearningObjectId string = ''

// Data Lake parameters
param datalakeName_param string = ''
param commonLakeNamePrefixMax8chars string

// Common ACR usage
param useCommonACR bool = true
// Tags
param tagsProject object = {}
param tags object = {}

// Resource exists flags from Azure DevOps
param updateRbac bool = false
param miPrjExists bool = false
param amlExists bool = false
param aksExists bool = false
param aiHubExists bool = false
param aiServicesExists bool = false
param aiSearchExists bool = false
param dataFactoryExists bool = false
param openaiExists bool = false
@description('Skip creating role assignments that may already exist to avoid RoleAssignmentExists errors')
param skipExistingRoleAssignments bool = false

@description('Unique deployment identifier to avoid conflicts')
param deploymentId string = utcNow('yyyyMMddHHmmss')
@description('Common resource name identifier. Default is "esml-common"')
param commonResourceName string = 'esml-common'

var prjResourceSuffixNoDash = replace(resourceSuffix,'-','')
var cmnName = namingConvention.outputs.cmnName

// SPECIAL
var randomSalt = empty(aifactorySalt10char) || length(aifactorySalt10char) <= 5 ? substring(randomValue, 0, 10): aifactorySalt10char

// ============================================================================
// AI Factory - naming convention (imported from shared module)
// ============================================================================
module namingConvention '../modules/common/CmnAIfactoryNaming.bicep' = {
  name: take('08-naming-${targetResourceGroup}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    env: env
    projectNumber: projectNumber
    locationSuffix: locationSuffix
    commonResourceSuffix: commonResourceSuffix
    resourceSuffix: resourceSuffix
    aifactorySalt10char: aifactorySalt10char
    randomValue: randomValue
    aifactorySuffixRG: aifactorySuffixRG
    commonRGNamePrefix: commonRGNamePrefix
    technicalAdminsObjectID: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsObjectID
    technicalAdminsEmail: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsEmail
    commonResourceGroupName: commonResourceGroup
    subscriptionIdDevTestProd: subscriptionIdDevTestProd
    acaSubnetId: acaSubnetId
    aksSubnetId:aksSubnetId
    genaiSubnetId:genaiSubnetId
    aca2SubnetId: aca2SubnetId
    aks2SubnetId: aks2SubnetId
    addAIFoundryHub: addAIFoundryHub
    addAzureMachineLearning: addAzureMachineLearning
  }
}

// AI Foundry V1
var aifV1HubName = namingConvention.outputs.aifV1HubName
var aifV1ProjectName = namingConvention.outputs.aifV1ProjectName

var uniqueInAIFenv = namingConvention.outputs.uniqueInAIFenv
var aiServicesName = namingConvention.outputs.aiServicesName
var deploymentProjSpecificUniqueSuffix = '${projectName}-${env}-${randomValue}-${deploymentId}'
var storageAccount1001Name = namingConvention.outputs.storageAccount1001Name
var storageAccount2001Name = namingConvention.outputs.storageAccount2001Name
var safeNameAISearchOrg = enableAISearch? namingConvention.outputs.safeNameAISearch: ''
var openAIName = namingConvention.outputs.aoaiName

var cleanRandomValue2 = take(randomSalt, 2)

var safeNameAISearchBase = (enableAISearch && !empty(safeNameAISearchOrg))
  ? take(safeNameAISearchOrg, max(length(safeNameAISearchOrg) - 3, 0))
  : ''

var safeNameAISearchSuffix = (enableAISearch && !empty(safeNameAISearchOrg))
  ? substring(
      safeNameAISearchOrg,
      max(length(safeNameAISearchOrg) - 3, 0),
      min(3, length(safeNameAISearchOrg))
    )
  : ''

var aiSearchName = (enableAISearch && !empty(safeNameAISearchOrg))
  ? take(
      addAISearch
        ? '${safeNameAISearchBase}${cleanRandomValue2}${safeNameAISearchSuffix}'
        : safeNameAISearchOrg,
      60
    )
  : ''
// ============================================================================
// Resource definitions
// ============================================================================

// ============== VARIABLES ==============

// Network and resource group references
var projectResourceGroup_rgId = resourceId(subscriptionIdDevTestProd, 'Microsoft.Resources/resourceGroups', targetResourceGroup)
// Data lake name calculation
var datalakeName = datalakeName_param != '' ? datalakeName_param : '${commonLakeNamePrefixMax8chars}${uniqueInAIFenv_Static}esml${replace(commonResourceSuffix,'-','')}${env}'

// Calculated variables
var projectName = 'prj${projectNumber}'
var commonResourceGroup = !empty(commonResourceGroup_param) ? commonResourceGroup_param : '${commonRGNamePrefix}${commonResourceName}-${locationSuffix}-${env}${aifactorySuffixRG}'
var targetResourceGroup = '${commonRGNamePrefix}${projectPrefix}${replace(projectName, 'prj', 'project')}-${locationSuffix}-${env}${aifactorySuffixRG}${projectSuffix}'

// Networking calculations
var vnetNameFull = !empty(vnetNameFull_param) ? replace(vnetNameFull_param, '<network_env>', network_env) : '${vnetNameBase}-${locationSuffix}-${env}${commonResourceSuffix}'
var vnetResourceGroupName = !empty(vnetResourceGroup_param)? replace(vnetResourceGroup_param, '<network_env>', network_env) : commonResourceGroup

// Private DNS calculations
// Own access hub, added scale set: zones live in the bootstrap's DNS resource group, not in this scale set's.
// A literal '$(own_hub_private_dns_resource_group_id)' (ADO, variable not defined) is not an id and is ignored.
var ownHubPrivateDns = !centralDnsZoneByPolicyInHub && startsWith(toLower(own_hub_private_dns_resource_group_id), '/subscriptions/')
var ownHubPrivateDnsParts = split('${own_hub_private_dns_resource_group_id}////', '/')
var privDnsResourceGroupName = ownHubPrivateDns ? ownHubPrivateDnsParts[4] : ((!empty(privDnsResourceGroup_param) && centralDnsZoneByPolicyInHub) ? privDnsResourceGroup_param : vnetResourceGroupName)
var privDnsSubscription = ownHubPrivateDns ? ownHubPrivateDnsParts[2] : ((!empty(privDnsSubscription_param) && centralDnsZoneByPolicyInHub) ? privDnsSubscription_param : subscription().subscriptionId)
var p011_genai_team_lead_array = namingConvention.outputs.p011_genai_team_lead_array

// ============================================================================
// SPECIAL - Get PRINICPAL ID of existing AML, AIHub. Needs static name in existing
// ============================================================================
resource externalKv 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
  name: inputKeyvault
  scope: resourceGroup(inputKeyvaultSubscription, inputKeyvaultResourcegroup)
}

var miPrjName = namingConvention.outputs.miPrjName
module getProjectMIPrincipalId '../modules/get-managed-identity-info.bicep' = {
  name: take('08-getMI-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    managedIdentityName: miPrjName
  }
}

var var_miPrj_PrincipalId = getProjectMIPrincipalId.outputs.principalId
module spAndMI2ArrayModule '../modules/spAndMiArray.bicep' = {
  name: take('08-spAndMI2Array-${targetResourceGroup}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd,targetResourceGroup)
  params: {
    managedIdentityOID: enableLogicApps? '' : var_miPrj_PrincipalId
    // SP removal support: ignore the SP OID seeding secret when its name is empty or a placeholder (<todo>/<optional>) -> spAndMiArray yields an MI-only array
    servicePrincipleOIDFromSecret: (!empty(projectServicePrincipleOID_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<optional>')) ? externalKv.getSecret(projectServicePrincipleOID_SeedingKeyvaultName) : ''
    includeManagedIdentity: !enableLogicApps
  }
  dependsOn: [
      getProjectMIPrincipalId
  ]
}

// Allow skipping ACR role assignments if they already exist or project MI is pre-provisioned
var skipACRRoleAssignments = skipExistingRoleAssignments || miPrjExists

#disable-next-line BCP318
var spAndMiArray = spAndMI2ArrayModule.outputs.spAndMiArray
// Extract only the service principal (first element) - MI already handled in file 02.
// SP removal support: when no SP is configured (empty/<todo>/<optional> name) the SP is NOT at index 0,
// so emit an empty list instead of grabbing the managed identity by mistake.
var var_useProjectSP = !empty(projectServicePrincipleOID_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<optional>')
var servicePrincipalOnly = var_useProjectSP ? [spAndMiArray[0]] : []

// De-duplicate principals to avoid duplicate role assignments
// - Ensure user list is unique
// - Ensure SP/MI list is unique and has no overlap with users (in case a user OID was accidentally added to the SP/MI list)
var userIdsUnique = union(p011_genai_team_lead_array, p011_genai_team_lead_array)
var spAndMiUnique = union(spAndMiArray, spAndMiArray)

resource commonResourceGroupRef 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: commonResourceGroup!
  scope: subscription(subscriptionIdDevTestProd)
}
#disable-next-line BCP318
var uniqueInAIFenv_Static = substring(uniqueString(commonResourceGroupRef.id), 0, 5)

// ============== SHARED NAMING VARIABLES ==============
// Shared random value processing for dynamic naming (matches CmnAIfactoryNaming.bicep)
var cleanRandomValue = take(randomSalt, 2)

// ============== AML Principal ID ==============
// Azure Machine Learning dynamic naming logic (matches CmnAIfactoryNaming.bicep)
// aml-001-eus2-dev-qoygy-001 (28) + 2 = 30
var amlWithRandom = take('aml-${projectNumber}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${cleanRandomValue}${resourceSuffix}',64)
var amlName_Static = addAzureMachineLearning ? amlWithRandom : 'aml-${projectNumber}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${resourceSuffix}'

resource amlREF 'Microsoft.MachineLearningServices/workspaces@2024-10-01-preview' existing = if (!amlExists && enableAzureMachineLearning) {
  name: amlName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_amlPrincipalId = (!amlExists && enableAzureMachineLearning) ? amlREF.identity.principalId : ''

// ============== AI HUB Principal ID ==============
// AI Foundry Hub dynamic naming logic (matches CmnAIfactoryNaming.bicep)
// aif-hub-001-eus2-dev-qoygy-001 (30) + 2 = 32
var aifWithRandom = take('aif-hub-${projectNumber}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${cleanRandomValue}${resourceSuffix}',64)
var aiHubName_Static = addAIFoundryHub ? aifWithRandom : 'aif-hub-${projectNumber}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${resourceSuffix}'

// aif-p-002-1-eus2-dev-qoygy-001
var aiHubProjectName_Static = 'aif-p-${projectNumber}-1-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${resourceSuffix}'

resource aiHubREF 'Microsoft.MachineLearningServices/workspaces@2024-10-01-preview' existing = if (!aiHubExists && enableAIFoundryHub) {
  name: aiHubName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
resource existingAIHubProject 'Microsoft.MachineLearningServices/workspaces@2024-10-01-preview' existing = if (!aiHubExists && enableAIFoundryHub) {
  name: aiHubProjectName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}

#disable-next-line BCP318
var var_aiHubPrincipalId = (!aiHubExists && enableAIFoundryHub) ? aiHubREF.identity.principalId : ''
#disable-next-line BCP318
var var_aiHubProjectPrincipalId = (!aiHubExists && enableAIFoundryHub) ? existingAIHubProject.identity.principalId : ''

// ============== OPENAI Principal ID ==============
var openAIName_Static = 'aoai-${projectName}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${resourceSuffix}'
resource openAIREF 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = if (!openaiExists && enableAzureOpenAI) {
  name: openAIName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_openAIPrincipalId = (!openaiExists && enableAzureOpenAI) ? openAIREF.identity.principalId : ''

// ============== AI SERVICES Principal ID ==============
var aiServicesName_Static = replace(toLower('aiservices${projectName}${locationSuffix}${env}${uniqueInAIFenv_Static}${randomSalt}${prjResourceSuffixNoDash}'), '-', '') 
resource aiServicesREF 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = if (!aiServicesExists && enableAIServices) {
  name: aiServicesName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_aiServicesPrincipalId = (!aiServicesExists && enableAIServices) ? aiServicesREF.identity.principalId : ''

// ============== AI SEARCH Principal ID ==============
var aiSearchName_Static = addAISearch?replace(toLower('aisearch${projectName}${locationSuffix}${env}${uniqueInAIFenv_Static}${randomSalt}${cleanRandomValue}${resourceSuffix}'), '-', ''): replace(toLower('aisearch${projectName}${locationSuffix}${env}${uniqueInAIFenv_Static}${randomSalt}${resourceSuffix}'), '-', '')

resource aiSearchREF 'Microsoft.Search/searchServices@2024-06-01-preview' existing = if (!aiSearchExists && enableAISearch) {
  name: aiSearchName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_aiSearchPrincipalId = (!aiSearchExists && enableAISearch) ? aiSearchREF.identity.principalId : ''

// ============== VISION SERVICES Principal ID ==============
var visionName_Static = 'vision-${projectName}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${commonResourceSuffix}'
resource visionREF 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = if (enableAzureAIVision) {
  name: visionName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_visionPrincipalId = enableAzureAIVision ? visionREF.identity.principalId : ''

// ============== SPEECH SERVICES Principal ID ==============
var speechName_Static = 'speech-${projectName}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${commonResourceSuffix}'
resource speechREF 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = if (enableAzureSpeech) {
  name: speechName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_speechPrincipalId = enableAzureSpeech ? speechREF.identity.principalId : ''

// ============== DOCUMENT INTELLIGENCE Principal ID ==============
var docsName_Static = 'docs-${projectName}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${commonResourceSuffix}'
resource docsREF 'Microsoft.CognitiveServices/accounts@2024-10-01' existing = if (enableAIDocIntelligence) {
  name: docsName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
}
#disable-next-line BCP318
var var_docsPrincipalId = enableAIDocIntelligence ? docsREF.identity.principalId : ''

// Datalake with datalakeName based on local, static VARS such as uniqueInAIFenv_Static
resource esmlCommonLake 'Microsoft.Storage/storageAccounts@2024-01-01' existing = {
  name: datalakeName
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
}

// ============================================================================
// SPECIAL - END
// ============================================================================

// ============== EXISTING RESOURCE REFERENCES ==============

// Target resource group reference (existing from 01-foundation.bicep)
resource existingTargetRG 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: targetResourceGroup
  scope: subscription(subscriptionIdDevTestProd)
}

// ============== RBAC MODULES - KEY VAULT AND BASTION ==============

// NOTE: Common RG Key Vault and Bastion RBAC moved to 08b-rbac-common-rg.bicep for modularity

// RBAC for Project Key Vault - Service Principals only (Managed Identities already handled in 02-core-infrastructure.bicep)
module rbacKeyvaultProject '../modules/kvRbacAssignments.bicep' = {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacPrjKV${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultName: namingConvention.outputs.keyvaultName
    userObjectIds: [] // Users already handled in 02-core-infrastructure.bicep
    servicePrincipalIds: servicePrincipalOnly // Only the service principal from seeding KV
    managedIdentityIds: [] // Managed identities (Project MI + ACA MI) already handled in 02-core-infrastructure.bicep
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    spAndMI2ArrayModule
  ]
}

// Bastion Externally (Connectivity subscription and RG)
module rbacExternalBastion '../modules/rbacBastionExternal.bicep' = if(!empty(bastionResourceGroup) && !empty(bastionSubscription)) {
  scope: resourceGroup(bastionSubscription, bastionResourceGroup)
  name: take('08-rbac2GenAIUsersBas${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    user_object_ids: p011_genai_team_lead_array
    bastion_service_name: empty(bastionName) ? 'bastion-${locationSuffix}-${env}${commonResourceSuffix}' : bastionName
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacVnetReaderCommon
    rbacReadUsersToCmnVnetBastion
  ]
}


// ============== AI HUB - STORAGE PRIVATE ENDPOINT READER ROLE ASSIGNMENTS ==============
var genaiName = namingConvention.outputs.projectTypeGenAIName

// Assign Reader role on storage account 1001 blob private endpoint to AI Project
module storageReaderRole1001 '../modules/storagePendReaderToAIProject.bicep' = if(!aiHubExists && enableAIFoundryHub) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-storageReader1001${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    aiProjectName: aifV1ProjectName
    blobPrivateEndpointName: '${storageAccount1001Name}-blob-pend'
  }
}

// Assign Reader role on storage account 2001 blob private endpoint to AI Project
module storageReaderRole2001 '../modules/storagePendReaderToAIProject.bicep' = if(!aiHubExists && enableAIFoundryHub) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-storageReader2001${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount2001Name
    aiProjectName: aifV1ProjectName
    blobPrivateEndpointName: '${storageAccount2001Name}-blob-pend'
  }
}


// ============== RBAC MODULES - AI SERVICES ==============

// RBAC for OpenAI - Storage, Search, and User Access
module rbacForOpenAI '../modules/aihubRbacOpenAI.bicep' = if (enableAzureOpenAI && !openaiExists) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbac3OpenAI${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    aiSearchName: aiSearchName
    openAIServicePrincipal: var_openAIPrincipalId // Using computed variable for OpenAI principal ID
    servicePrincipleAndMIArray: spAndMiArray
    openAIName: openAIName
    userObjectIds: p011_genai_team_lead_array
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacReadUsersToCmnVnetBastion
  ]
}

// RBAC for AI Services - Storage and Search Integration
module rbacModuleAIServices '../modules/aihubRbacAIServices.bicep' = if(!aiServicesExists && enableAIServices) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbac4AIServ${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    aiSearchName: aiSearchName
    aiServicesPrincipalId: var_aiServicesPrincipalId // Using computed variable for AI Services principal ID
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC for AI Search - Cross-service Integration
module rbacModuleAISearch '../modules/aihubRbacAISearch.bicep' = if(!aiSearchExists && enableAISearch) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbac5Search${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    aiServicesName: enableAIServices ? aiServicesName : '' // Only pass AI Services name if enabled
    aiSearchMIObjectId: var_aiSearchPrincipalId // Using computed variable for AI Search principal ID
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== RBAC MODULES - AI HUB AND ML PLATFORM ==============

// RBAC for AI Hub to Azure ML Resource Group
//  Please ensure that the project managed identity has Search Index Data Reader and Search Service Contributor roles on the Search resource
module rbacAihubRbacAmlRG '../modules/aihubRbacAmlRG.bicep' = if (!aiHubExists && !empty(azureMachineLearningObjectId) && enableAIFoundryHub) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbac6Aml2RG${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    azureMachineLearningObjectId: azureMachineLearningObjectId
    aiHubName: aifV1HubName
    aiHubPrincipalId: var_aiHubPrincipalId // Using computed variable for AI Hub principal ID
    aiHubProjectName: aifV1ProjectName
    aiHubProjectPrincipalId: var_aiHubProjectPrincipalId // Using computed variable for AI Hub project principal ID
    contributorRoleId: contributorRoleId
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC for Users to AI Hub and Projects (only Foundry-specific roles)
module rbacModuleUsers '../modules/aihubRbacUsers.bicep' = if ((!aiHubExists && enableAIFoundryHub) || (!aiServicesExists && enableAIServices)) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacUsersAIHub${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    aiServicesName: enableAIServices? aiServicesName : ''
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    resourceGroupId: projectResourceGroup_rgId
    userObjectIds: userIdsUnique
    aiHubName: enableAIFoundryHub ? aifV1HubName : ''
    aiHubProjectName: enableAIFoundryHub ? aifV1ProjectName : ''
    servicePrincipleAndMIArray: spAndMiUnique
    useAdGroups: useAdGroups
    disableContributorAccessForUsers: disableContributorAccessForUsers
    disableRBACAdminOnRGForUsers:disableRBACAdminOnRGForUsers
    contributorRoleId: contributorRoleId
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== RBAC MODULES - STORAGE ACCOUNTS (INDEPENDENT) ==============
// Storage RBAC for users, groups, and service principals - runs independently
module rbacStorageUsers '../modules/storageRbacUsers.bicep' = if (!updateRbac && !skipExistingRoleAssignments) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacStorage${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    userObjectIds: userIdsUnique
    servicePrincipleAndMIArray: spAndMiUnique
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== RBAC MODULES - RESOURCE GROUP (INDEPENDENT) ==============
// Resource Group RBAC for users, groups, and service principals - runs independently
module rbacResourceGroupUsers '../modules/resourceGroupRbacUsers.bicep' = if (!updateRbac) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacRGUsers${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    resourceGroupId: projectResourceGroup_rgId
    userObjectIds: userIdsUnique
    servicePrincipleAndMIArray: spAndMiUnique
    useAdGroups: useAdGroups
    disableContributorAccessForUsers: disableContributorAccessForUsers
    disableRBACAdminOnRGForUsers: disableRBACAdminOnRGForUsers
    aiHubName: enableAIFoundryHub ? aifV1HubName : ''
    contributorRoleId: contributorRoleId
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC for Users to AI Search
module rbacModuleUsersToSearch '../modules/aiSearchRbacUsers.bicep' = if (!aiSearchExists && enableAISearch) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacAISearch${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    aiSearchName: aiSearchName
    userObjectIds: p011_genai_team_lead_array
    servicePrincipleAndMIArray: spAndMiArray
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
  ]
}

module rbacDatafactory '../modules/datafactoryRBAC.bicep' = if(!dataFactoryExists && enableDatafactory) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacDatafactory${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    additionalUserIds: p011_genai_team_lead_array
    useAdGroups: useAdGroups
    servicePrincipleAndMIArray: spAndMiArray
    datafactoryName:namingConvention.outputs.dataFactoryName
    disableContributorAccessForUsers: disableContributorAccessForUsers
    contributorRoleId: contributorRoleId
  }
  dependsOn: [
    existingTargetRG
    rbacModuleUsers
  ]
}

// ============== RBAC MODULES - OPTIONAL COGNITIVE SERVICES ==============

// RBAC for Azure AI Vision (Optional)
module rbacVision '../modules/aihubRbacVision.bicep' = if(enableAzureAIVision) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacVision${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    aiVisionMIObjectId: var_visionPrincipalId // Using computed variable for Vision principal ID
    userObjectIds: p011_genai_team_lead_array
    visonServiceName: visionName_Static // Using computed variable for Vision service name
    useAdGroups: useAdGroups
    servicePrincipleAndMIArray: spAndMiArray
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC for Azure Speech Services (Optional)
module rbacSpeech '../modules/aihubRbacSpeech.bicep' = if(enableAzureSpeech) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacSpeech${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    aiSpeechMIObjectId: var_speechPrincipalId // Using computed variable for Speech principal ID
    userObjectIds: p011_genai_team_lead_array
    speechServiceName: speechName_Static // Using computed variable for Speech service name
    useAdGroups: useAdGroups
    servicePrincipleAndMIArray: spAndMiArray
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC for AI Document Intelligence (Optional)
module rbacDocs '../modules/aihubRbacDoc.bicep' = if(enableAIDocIntelligence) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacDocs${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name
    userObjectIds: p011_genai_team_lead_array
    aiDocsIntelMIObjectId: var_docsPrincipalId // Using computed variable for Document Intelligence principal ID
    docsServiceName: docsName_Static // Using computed variable for Document Intelligence service name
    useAdGroups: useAdGroups
    servicePrincipleAndMIArray: spAndMiArray
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== RBAC MODULES - NETWORK AND VNET ACCESS ==============

// RBAC - VNet Reader access for all users, groups, SPs, and MIs
// Allows reading VNet/subnet status, endpoint status, etc. regardless of bastion configuration
// Respects skipExistingRoleAssignments flag to avoid conflicts on existing projects
module rbacVnetReaderCommon '../modules/vnetRBACReaderOnly.bicep' = if (!skipExistingRoleAssignments) {
  scope: resourceGroup(subscriptionIdDevTestProd, vnetResourceGroupName)
  name: take('08-rbacVnetReader${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    user_object_ids: userIdsUnique
    vNetName: vnetNameFull
    servicePrincipleAndMIArray: spAndMiUnique
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
  ]
}

// RBAC - Read users to Bastion, IF Bastion is added in common resource group
module rbacReadUsersToCmnVnetBastion '../modules/vnetRBACReader.bicep' = if(addBastionHost && empty(bastionSubscription)) {
  scope: resourceGroup(subscriptionIdDevTestProd, vnetResourceGroupName)
  name: take('08-rbacGenAIUsVn${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    user_object_ids: p011_genai_team_lead_array
    vNetName: vnetNameFull
    common_bastion_subnet_name: 'AzureBastionSubnet'
    servicePrincipleAndMIArray: spAndMiArray
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacVnetReaderCommon
  ]
}

// Bastion VNet Externally (Connectivity subscription and RG || AI Factory Common RG)
module rbacReadUsersToCmnVnetBastionExt '../modules/vnetRBACReader.bicep' = if(addBastionHost && !empty(bastionSubscription) && !skipACRRoleAssignments) {
  scope: resourceGroup(bastionSubscription, bastionResourceGroup)
  name: take('08-rbacUseVnet${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    user_object_ids: p011_genai_team_lead_array
    vNetName: vnetNameFullBastion
    common_bastion_subnet_name: 'AzureBastionSubnet'
    servicePrincipleAndMIArray: spAndMiArray
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacVnetReaderCommon
  ]
}

// ============== RBAC MODULES - COMMON RESOURCE GROUP ACCESS ==============
// NOTE: Common RG RBAC (ACR and Data Lake) moved to 08b-rbac-common-rg.bicep for modularity

// ============== RBAC MODULES - AZURE ML COMPUTE CLUSTER PERMISSIONS ==============

// Parse subnet resource ID to extract VNet details
var subnetIdParts = split(genaiSubnetId, '/')
var subnetSubscriptionId = subnetIdParts[2]
var subnetResourceGroup = subnetIdParts[4]
var subnetVNetName = subnetIdParts[8]
var subnetName = subnetIdParts[10]

// RBAC for Azure ML Compute Cluster Creation - Workspace-level roles
// Assigns: Azure ML Compute Operator and Azure ML Registry User roles
module rbacAmlComputeOperator '../modules/amlComputeRbac.bicep' = if(!amlExists && enableAzureMachineLearning) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('08-rbacAmlCompute${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    projectTeamGroupOrUser: p011_genai_team_lead_array
    servicePrincipleAndMIArray: spAndMiArray
    useAdGroups: useAdGroups
    amlWorkspaceName: amlName_Static
  }
  dependsOn: [
    existingTargetRG
    rbacModuleUsers
  ]
}

// RBAC for Network Contributor on GenAI Subnet - Azure ML scenario
// Required for: Joining compute clusters to VNet subnet
module rbacSubnetNetworkContributorAml '../modules/subnetRbacNetworkContributor.bicep' = if(!amlExists && enableAzureMachineLearning) {
  scope: resourceGroup(subnetSubscriptionId, subnetResourceGroup)
  name: take('08-rbacSubnetAml${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    vNetName: subnetVNetName
    subnetName: subnetName
    servicePrincipleAndMIArray: spAndMiArray
    user_object_ids: p011_genai_team_lead_array
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacReadUsersToCmnVnetBastion
  ]
}

// RBAC for Network Contributor on GenAI Subnet - AI Foundry Hub scenario
// Required for: Joining AI Foundry compute clusters to VNet subnet
module rbacSubnetNetworkContributorHub '../modules/subnetRbacNetworkContributor.bicep' = if(!aiHubExists && enableAIFoundryHub) {
  scope: resourceGroup(subnetSubscriptionId, subnetResourceGroup)
  name: take('08-rbacSubnetHub${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    vNetName: subnetVNetName
    subnetName: subnetName
    servicePrincipleAndMIArray: spAndMiArray
    user_object_ids: p011_genai_team_lead_array
    useAdGroups: useAdGroups
  }
  dependsOn: [
    existingTargetRG
    rbacReadUsersToCmnVnetBastion
  ]
}

// ============== OUTPUTS - Simplified ==============
// Note: Outputs simplified to avoid conditional module reference issues
// RBAC deployment status information

@description('Key Vault and Bastion RBAC deployment status (external bastion only - common RG bastion in 08b)')
output keystoreAndBastionRbacDeployed bool = (!empty(bastionResourceGroup) && !empty(bastionSubscription))

@description('AI Services RBAC deployment status')
output aiServicesRbacDeployed bool = (enableAzureOpenAI && !openaiExists) || (!aiServicesExists && enableAIServices) || (!aiSearchExists && enableAISearch)

@description('AI Hub and ML Platform RBAC deployment status')
output aiHubMlRbacDeployed bool = (!aiHubExists && !empty(azureMachineLearningObjectId) && enableAIFoundryHub) || (!aiHubExists && enableAIFoundryHub) || (!aiSearchExists && enableAISearch)

@description('Optional Cognitive Services RBAC deployment status')
output optionalCognitiveRbacDeployed bool = enableAzureAIVision || enableAzureSpeech || enableAIDocIntelligence

@description('Network and VNet RBAC deployment status')
output networkRbacDeployed bool = !skipExistingRoleAssignments // True if VNet reader module runs

@description('VNet Reader access granted (unless skipExistingRoleAssignments=true)')
output vnetReaderRbacDeployed bool = !skipExistingRoleAssignments

@description('NOTE: Common RG RBAC (ACR and Data Lake) moved to separate deployment (08b-rbac-common-rg.bicep)')
output commonRgRbacMovedToSeparateDeployment bool = true
