#!/bin/bash

set -eo pipefail

# ANSI color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Verify gh is available and authenticated
if ! command -v gh >/dev/null 2>&1; then
  echo -e "${RED}Error: GitHub CLI (gh) not found. Install it first.${NC}"
  exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  echo -e "${RED}Error: GitHub CLI not authenticated. Run 'gh auth login' first.${NC}"
  exit 1
fi

# Load .env file
if [ -f .env ]; then
  set -o allexport
  source .env
  set +o allexport
else
  echo "Error: .env file not found."
  exit 1
fi

# Upload names whose .env key has another spelling (.env.template keeps the old keys, union rule).
# A value under the upload name wins; otherwise the other spelling fills it.
declare -A env_spellings=(
  [ALLOW_PUBLIC_ACCESS_WHEN_BEHIND_VNET]=ALLOW_PUBLIC_ACCESS_WHEN_BEHINDVNET
  [INPUT_COMMON_SPSECRET_KEY]=INPUT_COMMON_SP_SECRET_KEY
  [DISABLE_CONTRIBUTOR_ACCESS_FOR_USERS]=DISABLE_CONTRIBUTOR_ACCESS_FORUSERS
  [DISABLE_RBAC_ADMIN_ON_RG_FOR_USERS]=DISABLE_RBAC_ADMIN_ON_RG_FORUSERS
)
# Least-privilege switches: the other spelling may only tighten access, so the template's "false"
# never overwrites a "true" set on the repository by hand. Set the upload name itself to loosen.
tighten_only=" DISABLE_CONTRIBUTOR_ACCESS_FOR_USERS DISABLE_RBAC_ADMIN_ON_RG_FOR_USERS "
for upload_name in "${!env_spellings[@]}"; do
  spelling="${env_spellings[$upload_name]}"
  if [[ -z "${!upload_name:-}" && -n "${!spelling:-}" ]]; then
    if [[ "$tighten_only" == *" $upload_name "* && "${!spelling,,}" != "true" ]]; then
      continue
    fi
    printf -v "$upload_name" '%s' "${!spelling}"
  fi
done

if [ -z "$GITHUB_NEW_REPO" ]; then
  echo -e "${RED}Error: GITHUB_NEW_REPO is not set in .env. Example: org/repo or user/repo.${NC}"
  exit 1
fi

# DIRECTORIES
current_dir=$(pwd)

# Rate limit safety: track operations and pause mid-way
op_counter=0
rate_limit_pause_after=50
rate_limit_pause_after_2=85
rate_limit_sleep_seconds=30
rate_limit_sleep_seconds_2=30
start_from_op=1  # QUICK UPDATE TIP: Run script once and note operation number at "QUICK UPDATE SECTION" message, then set this to that number
run_current_op=true

increment_counter() {
  op_counter=$((op_counter + 1))
  echo -e "${YELLOW}[${op_counter}] Processing: $1${NC}"
  if [[ $op_counter -lt $start_from_op ]]; then
    echo -e "${YELLOW}Skipping operation ${op_counter} (waiting to start at ${start_from_op})${NC}"
    run_current_op=false
    return
  fi

  run_current_op=true

  if [[ $op_counter -eq $rate_limit_pause_after ]]; then
    echo -e "${YELLOW}Hit ${rate_limit_pause_after} operations. Sleeping ${rate_limit_sleep_seconds}s to avoid GitHub secondary rate limits...${NC}"
    sleep "$rate_limit_sleep_seconds"
  elif [[ $op_counter -eq $rate_limit_pause_after_2 ]]; then
    echo -e "${YELLOW}Hit ${rate_limit_pause_after_2} operations. Sleeping ${rate_limit_sleep_seconds_2}s to avoid GitHub secondary rate limits...${NC}"
    sleep "$rate_limit_sleep_seconds_2"
  fi
}

# Function to check if a variable exists
check_variable_exists() {
  gh api "repos/$GITHUB_NEW_REPO/environments/$(github_environment_url "$1")/variables/$2" > /dev/null 2>&1
}

# Function to create or update a variable
create_or_update_variable() {
  local env
  env="$(github_environment_name "$1")"
  local name=$2
  local value=$3
  
  # Skip if single parameter mode is active and this isn't the target parameter
  if [[ -n "$single_param_name" && "$name" != "$single_param_name" ]]; then
    return
  fi
  
  # Check if the value is empty
  if [[ -z "$value" ]]; then
    # #echo -e "${RED}Error: Variable '$name' for environment '$env' has an empty value. Skipping.${NC}"
    echo -e "${YELLOW}Skipping variable '$name' for environment '$env' because the value is empty.${NC}"
    return
  fi

  increment_counter "variable $env/$name"
  if [[ "$run_current_op" != "true" ]]; then
    return
  fi
  if check_variable_exists "$env" "$name"; then
    gh api --method PATCH -H "Accept: application/vnd.github+json" "repos/$GITHUB_NEW_REPO/environments/$(github_environment_url "$env")/variables/$name" -f value="$value"
  else
    gh api --method POST -H "Accept: application/vnd.github+json" "repos/$GITHUB_NEW_REPO/environments/$(github_environment_url "$env")/variables" -f name="$name" -f value="$value"
  fi
}

# Function to check if a secret exists
check_secret_exists() {
  gh secret list --repo "$GITHUB_NEW_REPO" --env "$1" | grep -q "$2"
}

# Function to create or update a secret
create_or_update_secret() {
  local env
  env="$(github_environment_name "$1")"
  local name=$2
  local value=$3
  
  # Skip if single parameter mode is active and this isn't the target parameter
  if [[ -n "$single_param_name" && "$name" != "$single_param_name" ]]; then
    return
  fi
  
  # Check if the value is empty (prevents 'gh secret set' from prompting "Paste your secret" and hanging)
  if [[ -z "$value" ]]; then
    echo -e "${YELLOW}Skipping secret '$name' for environment '$env' because the value is empty.${NC}"
    return
  fi
  
  increment_counter "secret $env/$name"
  if [[ "$run_current_op" != "true" ]]; then
    return
  fi
  if check_secret_exists "$env" "$name"; then
    gh secret set "$name" --repo "$GITHUB_NEW_REPO" --env "$env" --body "$value"
  else
    gh secret set "$name" --repo "$GITHUB_NEW_REPO" --env "$env" --body "$value"
  fi
}

# Repo-level variable helper (used to offload common flags and reduce env var count)
create_or_update_repo_variable() {
  local name=$1
  local value=$2
  
  # Skip if single parameter mode is active and this isn't the target parameter
  if [[ -n "$single_param_name" && "$name" != "$single_param_name" ]]; then
    return
  fi
  
  if [[ -z "$value" && -v "$name" ]]; then
    case "$name" in
      AI_SEARCH_FALLBACK_LOCATION_ARRAY_DEV|AI_SEARCH_FALLBACK_LOCATION_ARRAY_STAGEPROD)
        value='[]' # An explicit empty value disables a previously approved regional opt-in.
        ;;
      SKU_AI_SEARCH_DEV_ARRAY|SKU_AI_SEARCH_STAGE_PROD_ARRAY)
        value='["basic","standard","standard2"]' # The default order defers to SKU_ARRAY_AISEARCH_*.
        ;;
    esac
  fi
  if [[ -z "$value" ]]; then
    echo -e "${YELLOW}Skipping repo variable '$name' because the value is empty.${NC}"
    return
  fi
  
  echo -e "${YELLOW}[Repo] Setting variable: $name${NC}"
  gh variable set "$name" --repo "$GITHUB_NEW_REPO" --body "$value"
}

# Prompt user for environment to run (default DEV) to avoid unnecessary rate-limited calls
echo -e "${YELLOW}Select environment to run (d=DEV, s=STAGE, p=PROD, a=ALL). Default is DEV:${NC}"
read -p "env [d/s/p/a]: " env_choice
case "${env_choice,,}" in
  a|all)  selected_environments=("dev" "stage" "prod") ;;
  s|stage) selected_environments=("stage") ;;
  p|prod)  selected_environments=("prod") ;;
  d|dev|"") selected_environments=("dev") ;;
  *) echo -e "${YELLOW}Unrecognized choice. Defaulting to DEV.${NC}"; selected_environments=("dev") ;;
esac

# Prompt for single parameter update (optional)
single_param_name=""
echo -e "${YELLOW}Do you want to update a single parameter only?${NC}"
echo -e "${YELLOW}Enter the parameter name (e.g., ENABLE_ELASTICSEARCH) or press Enter to update all:${NC}"
read -p "parameter name: " single_param_input
if [[ -n "$single_param_input" ]]; then
  single_param_name="$single_param_input"
  echo -e "${GREEN}Will update only parameter: ${single_param_name}${NC}"
else
  echo -e "${YELLOW}Will update all parameters.${NC}"
fi

# Prompt for optional resume position
echo -e "${YELLOW}Optional: resume from operation number (1-based). Leave empty to start from 1.${NC}"
echo -e "${YELLOW}TIP: Set to 82 to update Project number and ENABLE_ flags.${NC}"
read -p "start_from_op: " start_from_input
if [[ -n "$start_from_input" && "$start_from_input" =~ ^[0-9]+$ ]]; then
  start_from_op=$start_from_input
  echo -e "${YELLOW}Will start executing at operation ${start_from_op}.${NC}"
else
  start_from_op=1
fi

# Prompt user for orchestrator choice
echo -e "${YELLOW}Do you want to overwrite AZURE_CREDENTIALS with dummy value? Usually only the 1st time this is needed, to create the variable in Github (Enter 'y' or 'n')${NC}"
read -p "overwrite_azure_credential: " overwrite_azure_credential

echo -e "${YELLOW}Bootstraps config from .env as Github environment variables and secrets. ${NC}"

# Get the GitHub CLI version
gh_version=$(gh --version | grep -oP '\d+\.\d+\.\d+' | head -n 1)

# Helper to get AZURE_ENV_NAME per environment
get_azure_env_name() {
  case "$1" in
    dev) echo "dev" ;;
    stage) echo "test" ;;
    prod) echo "prod" ;;
  esac
}

# Optional (v1.23+): service enable flags and BYO customization variables.
# If a value is empty, it will be skipped.
service_and_byo_vars=(
  "UPDATE_AI_FOUNDRY"
  "FOUNDRY_DEPLOYMENT_TYPE"
  "DISABLE_AGENT_NETWORK_INJECTION"

  "ADMIN_AISEARCH_TIER"

  "VNET_RESOURCE_GROUP_PARAM"
  "VNET_NAME_FULL_PARAM"
  "COMMON_RESOURCE_GROUP_PARAM"
  "DATALAKE_NAME_PARAM"
  "KV_NAME_FROM_COMMON_PARAM"
  "SUBNET_COMMON"
  "SUBNET_COMMON_SCORING"
  "SUBNET_COMMON_POWERBI_GW"
  "SUBNET_PROJ_GENAI"
  "SUBNET_PROJ_AKS"
  "SUBNET_PROJ_AKS2"
  "SUBNET_PROJ_ACA"
  "SUBNET_PROJ_ACA2"
  "SUBNET_PROJ_WEBAPP"
  "SUBNET_PROJ_LOGICAPP"
  "SUBNET_PROJ_DATABRICKS_PUBLIC"
  "SUBNET_PROJ_DATABRICKS_PRIVATE"
  "BYO_ASEV3"
  "BYO_ASE_FULL_RESOURCE_ID"
  "BYO_ASE_APP_SERVICE_PLAN_RESOURCE_ID"
  "DEPLOY_MODEL_GPT_X"
  "MODEL_GPTX_NAME"
  "MODEL_GPTX_VERSION"
  "MODEL_GPTX_SKU"
  "MODEL_GPTX_CAPACITY"
  "DEPLOY_MODEL_TEXT_EMBEDDING_ADA_002"
  "DEPLOY_MODEL_TEXT_EMBEDDING_3_LARGE"
  "DEPLOY_MODEL_TEXT_EMBEDDING_3_SMALL"
  "DEFAULT_EMBEDDING_CAPACITY"
  "DEPLOY_MODEL_GPT_54_MINI"
  "DEFAULT_GPT_54_MINI_VERSION"
  "DEPLOY_MODEL_GPT_4O"
  "DEFAULT_GPT_4O_VERSION"
  "DEFAULT_GPT_CAPACITY"
  "DEFAULT_MODEL_SKU"

  "COSMOS_KIND"
  "POSTGRES_ADMIN_EMAILS"
  "ENABLE_ELASTICSEARCH"
  "ELASTIC_TYPE"
  "ELASTIC_EMAIL"
  "ELASTIC_FIRST_NAME"
  "ELASTIC_LAST_NAME"
  "ELASTIC_COMPANY_NAME"
  "ELASTIC_DEPLOYMENT_SIZE"
  "ELASTIC_SKU"

  "FUNCTION_RUNTIME"
  "FUNCTION_VERSION"
  "WEBAPP_RUNTIME"
  "WEBAPP_RUNTIME_VERSION"
  "ASE_SKU"
  "ASE_SKU_CODE"
  "ASE_SKU_WORKERS"

  "ACA_W_REGISTRY_IMAGE"

  "FOUNDRY_API_MANAGEMENT_RESOURCE_ID"
  "ENABLE_AKS"
  "AKS_SKU_NAME"
  "AKS_SKU_TIER"
  "AKS_ENABLE_PRIVATE_CLUSTER"

  # Low priority: run all ADD_* last
  "DEBUG_DISABLE_05_BUILD_ACR_IMAGE"
  "DEBUG_DISABLE_61_FOUNDATION"
  "DEBUG_DISABLE_62_CORE_INFRASTRUCTURE"
  "DEBUG_DISABLE_63_COGNITIVE_SERVICES"
  "DEBUG_DISABLE_64_DATABASES"
  "DEBUG_DISABLE_65_COMPUTE_SERVICES"
  "DEBUG_DISABLE_66_AI_PLATFORM"
  "DEBUG_DISABLE_67_ML_PLATFORM"
  "DEBUG_DISABLE_68_INTEGRATION"
  "DEBUG_DISABLE_69_AIFOUNDRY_2025"
  "DEBUG_DISABLE_100_RBAC_SECURITY"
  "DEBUG_DISABLE_10_AIFACTORY_DASHBOARDS"
  "ADD_AI_FOUNDRY_HUB"
  "ADD_AI_FOUNDRY"
  "ADD_AI_SEARCH"
  "ADD_AZURE_MACHINE_LEARNING"
)

# Repo-scoped variables to reduce env variable count (applied once per repo)
repo_level_vars=(
  # === Global AI Factory settings ===
  "SCALING_MODE"
  "AIFACTORY_LOCATION"
  "AIFACTORY_LOCATION_SHORT"
  "AI_SEARCH_LOCATION"
  "AI_SEARCH_FALLBACK_LOCATION_ARRAY_DEV"
  "AI_SEARCH_FALLBACK_LOCATION_ARRAY_STAGEPROD"
  "AIFACTORY_SUFFIX"
  "AIFACTORY_PREFIX"
  "DEV_SUBSCRIPTION_ID"
  "STAGE_SUBSCRIPTION_ID"
  "PROD_SUBSCRIPTION_ID"
  "TENANT_AZUREML_OID"
  "DATABRICKS_OID"
  "LAKE_PREFIX"
  "LAKE_CONTAINER_NAME"
  "AISEARCH_SEMANTIC_TIER"
  "DATABRICKS_PRIVATE"
  "AML_STUDIO_UI_PRIVATE"
  "DIAGNOSTIC_SETTING_LEVEL"

  # === RBAC model ===
  "ENABLE_PERSONAS"
  "ENABLE_PROJECT_VM"
  "UPDATE_RBAC"
  "ADMIN_PROJECT_TYPE"
  "SKIP_DIAG_AI_SEARCH"
  "SKIP_DIAG_AI_SERVICES"
  "AI_SEARCH_DISABLE_LOCAL_AUTH"
  "SKIP_DIAG_AOAI"
  "SKIP_DIAG_CONTENT_SAFETY"
  "SKIP_DIAG_DOC_INTELLIGENCE"
  "SKIP_DIAG_SPEECH"
  "SKIP_DIAG_VISION"
  "PERSONA_ACCESS_MODE"
  "PERSONA_ACCESS_MANIFEST"
  "USE_AD_GROUPS"
  "GROUPS_PROJECT_MEMBERS_ESML"
  "GROUPS_PROJECT_MEMBERS_GENAI_1"
  "GROUPS_CORETEAM_MEMBERS"
  "PERSONAS_PROJECT_ESML"
  "PERSONAS_PROJECT_GENAI_1"
  "PERSONAS_CORE_TEAM"
  
  # === Keyvault and security ===
  "KEYVAULT_SOFT_DELETE"
  "AIFACTORY_SEEDING_KEYVAULT_NAME"
  "AIFACTORY_SEEDING_KEYVAULT_RG"
  "COMMON_SERVICE_PRINCIPAL_KV_S_NAME_APPID"
  "COMMON_SERVICE_PRINCIPAL_KV_S_NAME_SECRET"
  "INPUT_COMMON_SPID_KEY"
  "INPUT_COMMON_SPSECRET_KEY"
  "INPUT_COMMON_SP_SECRET_KEY"
  "COMMON_SERVICE_PRINCIPLE_OID_KEY"
  
  # === Project settings ===
  "PROJECT_TYPE"
  "PROJECT_SERVICE_PRINCIPAL_KV_S_NAME_APPID"
  "PROJECT_SERVICE_PRINCIPAL_KV_S_NAME_OID"
  "AIFACTORY_MCP_KV_S_NAME_APPID"
  "PROJECT_SERVICE_PRINCIPAL_KV_S_NAME_S"
  "PROJECT_NUMBER"
  "PROJECT_MEMBERS_EMAILS"
  "PROJECT_IP_WHITELIST"
  "TAGS_PROJECT"
  
  # === Versioning ===
  "AIFACTORY_VERSION_MAJOR"
  "AIFACTORY_VERSION_MINOR"
  "AIFACTORY_SALT"
  "AIFACTORY_SALT_RANDOM"
  
  # === Networking ===
  "BYO_SUBNETS"
  "RUN_JOB1_NETWORKING"
  "ADD_BASTION_HOST"
  "BASTION_SUBSCRIPTION_RESOURCE_GROUP"
  "BASTION_CUSTOM_NAME"
  "ENABLE_ADMIN_VM"
  "ADMIN_VM_SIZE"
  "ENABLE_ENCRYPTION_AT_HOST"
  "ENABLE_VM_BACKUP"
  "CENTRAL_DNS_ZONE_BY_POLICY_IN_HUB"
  "ENABLE_AI_FACTORY_HUB"
  "PRIV_DNS_SUBSCRIPTION_PARAM"
  "PRIV_DNS_RESOURCE_GROUP_PARAM"
  "OWN_HUB_VNET_ID"
  "OWN_HUB_PRIVATE_DNS_RESOURCE_GROUP_ID"
  "ENABLE_PUBLIC_GENAI_ACCESS"
  "ALLOW_PUBLIC_ACCESS_WHEN_BEHIND_VNET"
  "ENABLE_PUBLIC_ACCESS_WITH_PERIMETER"
  
  # === Cost optimization ===
  "USE_COMMON_ACR_FOR_PROJECTS"
  "UPDATE_COMMON_ACR"
  
  "ENABLE_DEFENDER_FOR_AI_SUB_LEVEL"
  "ENABLE_DEFENDER_FOR_AI_RESOURCE_LEVEL"
  "CMK"
  "CMK_KEY_NAME"
  "CMK_KEY_VERSION"
  "CMK_DISABLE_FOR_AI_SEARCH"
  "CMK_DISABLE_FOR_FOUNDRY"
  "DISABLE_LOCAL_AUTH"
  "ADMIN_AISEARCH_TIER"
  "PROJECT_PREFIX"
  "PROJECT_SUFFIX"
  "UPDATE_KEYVAULT_RBAC"
  "AIFACTORY_COMMON_ONLY_DEV_ENVIRONMENT"
  "ADMIN_USERNAME"
  "ADMIN_HYBRID_BENEFIT"
  "ADMIN_COMMON_RESOURCE_SUFFIX"
  "ADMIN_PRJ_RESOURCE_SUFFIX"
  "VNET_RESOURCE_GROUP_BASE"
  "VNET_NAME_BASE"
  "SUBNET_COMMON_BASE"
  "COMMON_VNET_CIDR"
  "COMMON_SUBNET_CIDR"
  "COMMON_SUBNET_SCORING_CIDR"
  "COMMON_PBI_SUBNET_NAME"
  "COMMON_PBI_SUBNET_CIDR"
  "COMMON_BASTION_SUBNET_NAME"
  "COMMON_BASTION_SUBNET_CIDR"
  "DISABLE_WHITELISTING_FOR_BUILD_AGENTS"
  "USE_SELF_HOSTED_BUILD_AGENT"
  "SELF_HOSTED_RUNNER_LABEL"
  "USE_COMMON_ACR_OVERRIDE"
  "ACR_IP_WHITELIST"
  "ACR_ADMIN_USER_ENABLED"
  "ACR_DEDICATED"
  "ACR_SKU"
  # === RBAC: Contributor role override ===
  "BYO_CONTRIBUTOR_ROLE_ID"
  "DISABLE_CONTRIBUTOR_ACCESS_FORUSERS"
  "DISABLE_RBAC_ADMIN_ON_RG_FORUSERS"
  "DISABLE_CONTRIBUTOR_ACCESS_FOR_USERS"
  "DISABLE_RBAC_ADMIN_ON_RG_FOR_USERS"
  "DISABLE_SUBNET_JOIN_ACTION"
  # === Complete mode vs Incremental mode ===
  "ENABLE_DELETE_FOR_DISABLED_RESOURCES"
  "DELETE_ALL_SERVICES_FOR_PROJECT"
  "DELETE_KEYVAULT_ALSO"
  "DELETE_ALL_FOR_PROJECT"
  # All ENABLE_* flags moved to repo-level
  "ENABLE_AI_SERVICES"
  "ENABLE_AI_FOUNDRY_HUB"
  "ENABLE_AI_FOUNDRY"
  "ENABLE_FOUNDRY_CAPHOST"
  "CLEAN_FOUNDRY_CAPHOST"
  "ENABLE_AIFACTORY_CREATED_DEFAULT_PROJECT_FOR_AIFV2"
  "ENABLE_DATAFACTORY"
  "ENABLE_DATAFACTORY_COMMON"
  "ENABLE_AZURE_MACHINE_LEARNING"
  "ENABLE_AKS_FOR_AZURE_ML"
  "ENABLE_AKS"
  "ENABLE_DATABRICKS"
  "ENABLE_AI_SEARCH"
  "ENABLE_AI_SEARCH_SHARED_PRIVATE_LINK"
  "ENABLE_AZURE_OPENAI"
  "ENABLE_AZURE_AI_VISION"
  "ENABLE_AZURE_SPEECH"
  "ENABLE_AI_DOC_INTELLIGENCE"
  "ENABLE_BING"
  "ENABLE_BING_CUSTOM_SEARCH"
  "ENABLE_CONTENT_SAFETY"
  "ENABLE_COSMOS_DB"
  "ENABLE_POSTGRESQL"
  "ENABLE_REDIS_CACHE"
  "ENABLE_REDIS_MANAGED"
  "SKU_REDIS_MANAGED_DEV"
  "SKU_REDIS_MANAGED_STAGEPROD"
  "HIGH_AVAILABILITY_REDIS_MANAGED"
  "EVICTION_POLICY_REDIS_MANAGED"
  "CLUSTERING_POLICY_REDIS_MANAGED"
  "ENABLE_SQL_DATABASE"
  "ENABLE_ELASTICSEARCH"
  "ENABLE_FUNCTION"
  "ENABLE_WEBAPP"
  "ENABLE_CONTAINER_APPS"
  "ENABLE_AZURE_MCP_SERVER"
  "ENABLE_APPINSIGHTS_DASHBOARD"
  "ENABLE_APPLICATION_INSIGHTS"
  "ENABLE_LOGIC_APPS"
  "LOGIC_APP_TYPE"
  "ENABLE_EVENT_HUBS"
  "ENABLE_BOT_SERVICE"
  "DEV_NETWORK_ENV"
  "STAGE_NETWORK_ENV"
  "PROD_NETWORK_ENV"
  "AKS_OUTBOUND_TYPE"
  "AKS_PRIVATE_DNS_ZONE"
  "AKS_AZURE_FIREWALL_PRIVATE_IP"
  "ADMIN_AKS_GPU_SKU_DEV_OVERRIDE"
  "ADMIN_AKS_GPU_SKU_TEST_PROD_OVERRIDE"
  "ADMIN_AKS_NODES_DEV_OVERRIDE"
  "ADMIN_AKS_NODES_TEST_PROD_OVERRIDE"
  "ADMIN_AKS_VERSION_OVERRIDE"
  "ADMIN_AML_CLUSTER_MAX_NODES_DEV_OVERRIDE"
  "ADMIN_AML_CLUSTER_MAX_NODES_TEST_PROD_OVERRIDE"
  "ADMIN_AML_CLUSTER_SKU_DEV_OVERRIDE"
  "ADMIN_AML_CLUSTER_SKU_TEST_PROD_OVERRIDE"
  "ADMIN_AML_COMPUTE_INSTANCE_DEV_SKU_OVERRIDE"
  "ADMIN_AML_COMPUTE_INSTANCE_TEST_PROD_SKU_OVERRIDE"
  "TAGS"
  "SERVICE_SETTING_DEPLOY_PROJECT_VM"
  "DEBUG_DISABLE_VALIDATION_TASKS"
  "ADMIN_AI_SEARCH_TIER"
  # === AI Gateway ===
  "ENABLE_APIM"
  "APIM_GATEWAY_SUBSCRIPTION_ID"
  "APIM_GATEWAY_RESOURCE_GROUP"
  "APIM_GATEWAY_SERVICE_NAME"
  "APIM_GATEWAY_SKU"
  "APIM_GATEWAY_SKU_CAPACITY"
  "APIM_GATEWAY_API_ID"
  "APIM_GATEWAY_API_PATH"
  "APIM_GATEWAY_BACKEND_POOL_NAME"
  "APIM_GATEWAY_AGGREGATE_TPM"
  "APIM_GATEWAY_CALLER_TPM"
  "APIM_GATEWAY_RETRY_COUNT"
  "APIM_GATEWAY_ASSIGN_OPENAI_USER_ROLE"
  "APIM_GATEWAY_MANAGED_IDENTITY_PRINCIPAL_ID"
  "APIM_GATEWAY_BACKENDS_JSON"
  "APIM_GATEWAY_MANAGED_PROVISIONING"
  "APIM_GATEWAY_CONFIG_FILE"
  "ENABLE_KONG"
  "KONG_GATEWAY_VNET_RESOURCE_GROUP"
  "KONG_GATEWAY_VNET_NAME"
  "KONG_GATEWAY_SUBNET_CIDR"
  "KONG_GATEWAY_SUBNET_NAME"
  "KONG_GATEWAY_APIM_HOST"
  "KONG_GATEWAY_IMAGE"
  "KONG_GATEWAY_CPU"
  "KONG_GATEWAY_MEMORY_GB"
  # === Factory Chat Agent, AI Factory MCP & new AI Gateway SKU ===
  "ENABLE_AI_FACTORY_MCP"
  "ENABLE_FACTORY_CHAT_AGENT"
  "ENABLE_AI_FACTORY_AGENT_LIVE_VOICE"
  "ENABLE_AI_GATEWAY_SKU"
  "ADD_AI_FACTORY_MCP_2_AI_GATEWAY_SKU"
  "AIFACTORY_MCP_IMAGE"
  "AIFACTORY_MCP_API_IMAGE"
  "AIFACTORY_MCP_ENTRA_APP_ID"
  "AIFACTORY_MCP_CONTAINER_APPS_ENVIRONMENT"
  "AI_GATEWAY_SKU_RESOURCE_ID"
  "AI_GATEWAY_SKU_OUTBOUND_SUBNET_ID"
  "AIFACTORY_MCP_CLASSIC_APIM_RESOURCE_IDS"
  "AIFACTORY_MCP_CONTAINER_APP_RESOURCE_ID"
  "ADD_AI_FACTORY_MCP_2_APIM"
  "AIFACTORY_AGENT_ENTRA_APP_ID"
  "AIFACTORY_AGENT_CONTAINER_APPS_ENVIRONMENT"
  "AIFACTORY_AGENT_READER_OBJECT_IDS"
  "AIFACTORY_AGENT_VOICE_NAME"
  "AIFACTORY_AGENT_VOICE_LANGUAGES"
  "AIFACTORY_AGENT_CONFIG_FILE"
  "AIFACTORY_AGENT_MODEL_DEPLOYMENT"

  # === All service_and_byo_vars moved to repo-level ===
  "UPDATE_AI_FOUNDRY"
  "FOUNDRY_DEPLOYMENT_TYPE"
  "DISABLE_AGENT_NETWORK_INJECTION"
  "ADMIN_AISEARCH_TIER"
  "VNET_RESOURCE_GROUP_PARAM"
  "VNET_NAME_FULL_PARAM"
  "COMMON_RESOURCE_GROUP_PARAM"
  "DATALAKE_NAME_PARAM"
  "KV_NAME_FROM_COMMON_PARAM"
  "SUBNET_COMMON"
  "SUBNET_COMMON_SCORING"
  "SUBNET_COMMON_POWERBI_GW"
  "SUBNET_PROJ_GENAI"
  "SUBNET_PROJ_AKS"
  "SUBNET_PROJ_AKS2"
  "SUBNET_PROJ_ACA"
  "SUBNET_PROJ_ACA2"
  "SUBNET_PROJ_WEBAPP"
  "SUBNET_PROJ_LOGICAPP"
  "SUBNET_PROJ_DATABRICKS_PUBLIC"
  "SUBNET_PROJ_DATABRICKS_PRIVATE"
  "BYO_ASEV3"
  "BYO_ASE_FULL_RESOURCE_ID"
  "BYO_ASE_APP_SERVICE_PLAN_RESOURCE_ID"
  "DEPLOY_MODEL_GPT_X"
  "MODEL_GPTX_NAME"
  "MODEL_GPTX_VERSION"
  "MODEL_GPTX_SKU"
  "MODEL_GPTX_CAPACITY"
  "DEPLOY_MODEL_TEXT_EMBEDDING_ADA_002"
  "DEPLOY_MODEL_TEXT_EMBEDDING_3_LARGE"
  "DEPLOY_MODEL_TEXT_EMBEDDING_3_SMALL"
  "DEFAULT_EMBEDDING_CAPACITY"
  "DEPLOY_MODEL_GPT_54_MINI"
  "DEFAULT_GPT_54_MINI_VERSION"
  "DEPLOY_MODEL_GPT_4O"
  "DEFAULT_GPT_4O_VERSION"
  "DEFAULT_GPT_CAPACITY"
  "DEFAULT_MODEL_SKU"
  "COSMOS_KIND"
  "POSTGRES_ADMIN_EMAILS"
  "ELASTIC_TYPE"
  "ELASTIC_EMAIL"
  "ELASTIC_FIRST_NAME"
  "ELASTIC_LAST_NAME"
  "ELASTIC_COMPANY_NAME"
  "ELASTIC_DEPLOYMENT_SIZE"
  "ELASTIC_SKU"
  "FUNCTION_RUNTIME"
  "FUNCTION_VERSION"
  "WEBAPP_RUNTIME"
  "WEBAPP_RUNTIME_VERSION"
  "ASE_SKU"
  "ASE_SKU_CODE"
  "ASE_SKU_WORKERS"
  "ACA_W_REGISTRY_IMAGE"
  "FOUNDRY_API_MANAGEMENT_RESOURCE_ID"
  "AKS_SKU_NAME"
  "AKS_SKU_TIER"
  "AKS_ENABLE_PRIVATE_CLUSTER"
  "DEBUG_DISABLE_05_BUILD_ACR_IMAGE"
  "DEBUG_DISABLE_61_FOUNDATION"
  "DEBUG_DISABLE_62_CORE_INFRASTRUCTURE"
  "DEBUG_DISABLE_63_COGNITIVE_SERVICES"
  "DEBUG_DISABLE_64_DATABASES"
  "DEBUG_DISABLE_65_COMPUTE_SERVICES"
  "DEBUG_DISABLE_66_AI_PLATFORM"
  "DEBUG_DISABLE_67_ML_PLATFORM"
  "DEBUG_DISABLE_68_INTEGRATION"
  "DEBUG_DISABLE_69_AIFOUNDRY_2025"
  "DEBUG_DISABLE_100_RBAC_SECURITY"
  "DEBUG_DISABLE_10_AIFACTORY_DASHBOARDS"
  "ADD_AI_FOUNDRY_HUB"
  "ADD_AI_FOUNDRY"
  "ADD_AI_SEARCH"
  "ADD_AZURE_MACHINE_LEARNING"
  "POLICY_EXEMPTION_ASSIGNMENT_IDS"
  "POLICY_EXEMPTION_DEFINITION_REFERENCE_IDS"

  # === PER-ENVIRONMENT SERVICE SKUs (Dev vs Stage/Prod) ===
  # Consumed by infra-project.yml as vars.SKU_<SERVICE>_DEV / vars.SKU_<SERVICE>_STAGEPROD.
  # Core Infrastructure (02)
  "SKU_STORAGEACCOUNT_DEV"
  "SKU_STORAGEACCOUNT_STAGEPROD"
  # Cognitive Services (03); the AI Search SKUs take precedence over ADMIN_AISEARCH_TIER.
  "SKU_AISEARCH_DEV"
  "SKU_AISEARCH_STAGEPROD"
  "SKU_ARRAY_AISEARCH_DEV"
  "SKU_ARRAY_AISEARCH_STAGEPROD"
  "SKU_AI_SEARCH_DEV_ARRAY"
  "SKU_AI_SEARCH_STAGE_PROD_ARRAY"
  "AISEARCH_RETRY_CAPCITY_ARRAY"
  "SKU_AISERVICES_DEV"
  "SKU_AISERVICES_STAGEPROD"
  "SKU_OPENAI_DEV"
  "SKU_OPENAI_STAGEPROD"
  "SKU_CONTENTSAFETY_DEV"
  "SKU_CONTENTSAFETY_STAGEPROD"
  "SKU_VISION_DEV"
  "SKU_VISION_STAGEPROD"
  "SKU_SPEECH_DEV"
  "SKU_SPEECH_STAGEPROD"
  "SKU_DOCINTELLIGENCE_DEV"
  "SKU_DOCINTELLIGENCE_STAGEPROD"
  "SKU_BING_DEV"
  "SKU_BING_STAGEPROD"
  # Databases (04)
  "SKU_POSTGRESQL_DEV"
  "SKU_POSTGRESQL_STAGEPROD"
  "SKU_ARRAY_POSTGRESQL_DEV"
  "SKU_ARRAY_POSTGRESQL_STAGEPROD"
  "POSTGRESQL_RETRY_CAPACITY_ARRAY"
  "SKU_TIER_POSTGRESQL_DEV"
  "SKU_TIER_POSTGRESQL_STAGEPROD"
  "SKU_REDIS_DEV"
  "SKU_REDIS_STAGEPROD"
  "SKU_SQLDATABASE_DEV"
  "SKU_SQLDATABASE_STAGEPROD"
  "SKU_TIER_SQLDATABASE_DEV"
  "SKU_TIER_SQLDATABASE_STAGEPROD"
  # Search (Elastic Cloud); takes precedence over ELASTIC_SKU.
  "SKU_ELASTIC_DEV"
  "SKU_ELASTIC_STAGEPROD"
  # Compute (05)
  "SKU_CONTAINER_APPS_DEV"
  "SKU_CONTAINER_APPS_STAGEPROD"
  "SKU_ARRAY_CONTAINER_APPS_DEV"
  "SKU_ARRAY_CONTAINER_APPS_STAGEPROD"
  "CONTAINER_APPS_RETRY_CAPACITY_ARRAY"
  "SKU_AKS_DEV"
  "SKU_AKS_STAGEPROD"
  "SKU_TIER_AKS_DEV"
  "SKU_TIER_AKS_STAGEPROD"
  "SKU_WEBAPP_DEV"
  "SKU_WEBAPP_STAGEPROD"
  "SKU_TIER_WEBAPP_DEV"
  "SKU_TIER_WEBAPP_STAGEPROD"
  "SKU_FUNCTION_DEV"
  "SKU_FUNCTION_STAGEPROD"
  "SKU_TIER_FUNCTION_DEV"
  "SKU_TIER_FUNCTION_STAGEPROD"
  # ML Platform (07)
  "SKU_AZUREML_DEV"
  "SKU_AZUREML_STAGEPROD"
  "SKU_TIER_AZUREML_DEV"
  "SKU_TIER_AZUREML_STAGEPROD"
  "SKU_DATABRICKS_DEV"
  "SKU_DATABRICKS_STAGEPROD"
  # Integration (11)
  "SKU_LOGICAPPS_DEV"
  "SKU_LOGICAPPS_STAGEPROD"
  "SKU_EVENTHUBS_DEV"
  "SKU_EVENTHUBS_STAGEPROD"
  "SKU_BOTSERVICE_DEV"
  "SKU_BOTSERVICE_STAGEPROD"
)

# Apply repo-level variables once to reduce environment-level count
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}GitHub Variables Update Script${NC}"
echo -e "${GREEN}================================================${NC}"
echo -e "${YELLOW}TIP: To quickly update frequently-changed variables only:${NC}"
echo -e "${YELLOW}  - Edit this script and set start_from_op to the appropriate number${NC}"
echo -e "${YELLOW}  - Frequently updated variables are processed LAST in each environment:${NC}"
echo -e "${YELLOW}    • PROJECT_NUMBER, PROJECT_MEMBERS, PROJECT_MEMBERS_EMAILS${NC}"
echo -e "${YELLOW}    • PROJECT_MEMBERS_IP_ADDRESS${NC}"
echo -e "${YELLOW}    • TAGS_PROJECT${NC}"
echo -e "${YELLOW}    • All ENABLE_* flags${NC}"
echo -e "${YELLOW}  - Watch the [operation_number] output to find the right start_from_op${NC}"
echo -e "${GREEN}================================================${NC}"
echo ""

script_directory="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
environment_helper=""
for candidate in \
  "$script_directory/azure-enterprise-scale-ml/bootstrap/lib/github_environments.py" \
  "$script_directory/../../../../../bootstrap/lib/github_environments.py"; do
  if [[ -f "$candidate" ]]; then environment_helper="$candidate"; break; fi
done
[[ -n "$environment_helper" ]] || { echo "Missing GitHub environment helper; update the shared submodule."; exit 1; }
if command -v python >/dev/null 2>&1 && python --version >/dev/null 2>&1; then
  environment_python=(python)
elif command -v py >/dev/null 2>&1 && py -3 --version >/dev/null 2>&1; then
  environment_python=(py -3)
else
  environment_python=(python3)
fi
AIFACTORY_GITHUB_ENVIRONMENTS="$("${environment_python[@]}" "$environment_helper" \
  --repository "$GITHUB_NEW_REPO" --ensure "${selected_environments[@]}")"
export AIFACTORY_GITHUB_ENVIRONMENTS
github_environment_name() {
  "${environment_python[@]}" -c 'import json, os, sys; sys.stdout.write(json.loads(os.environ["AIFACTORY_GITHUB_ENVIRONMENTS"])[sys.argv[1]])' "$1"
}
github_environment_url() {
  "${environment_python[@]}" -c 'import sys; from urllib.parse import quote; sys.stdout.write(quote(sys.argv[1], safe=""))' "$1"
}
for var_name in "${repo_level_vars[@]}"; do
  var_value="${!var_name}"
  # Strip outer single quotes from TAGS and TAGS_PROJECT
  if [[ "$var_name" == "TAGS" || "$var_name" == "TAGS_PROJECT" ]]; then
    var_value="${var_value#\'}"
    var_value="${var_value%\'}"
  fi
  create_or_update_repo_variable "$var_name" "$var_value"
done

for env in "${selected_environments[@]}"; do
  create_or_update_variable "$env" "AZURE_ENV_NAME" "$(get_azure_env_name "$env")"
done

# AI Factory globals: variables and secrets (environment-specific only)
for env in "${selected_environments[@]}"; do
    echo -e "${YELLOW}Setting environment-specific variables and secrets for: $env${NC}"
    
    # Environment-specific secrets
    create_or_update_secret $env "AZURE_CLIENT_ID" "${AZURE_CLIENT_ID:-}"
    create_or_update_secret $env "AIFACTORY_SEEDING_KEYVAULT_SUBSCRIPTION_ID" "$AIFACTORY_SEEDING_KEYVAULT_SUBSCRIPTION_ID"
    create_or_update_secret $env "TENANT_ID" "$TENANT_ID"
    create_or_update_secret $env "PROJECT_MEMBERS" "$PROJECT_MEMBERS"
    create_or_update_secret $env "PROJECT_MEMBERS_IP_ADDRESS" "$PROJECT_MEMBERS_IP_ADDRESS"
    create_or_update_secret $env "KONG_CONSUMER_API_KEY" "$KONG_CONSUMER_API_KEY"

    # ========================================================================
    # FREQUENTLY UPDATED VARIABLES - Positioned last for quick start_from_op
    # ========================================================================
    echo -e "${GREEN}>>> QUICK UPDATE SECTION for $env - Note the operation number above! <<<${NC}"
done

if [[ " ${selected_environments[*]} " == *" dev "* ]]; then
  create_or_update_variable "dev" "AZURE_LOCATION" "$AIFACTORY_LOCATION"
  create_or_update_variable "dev" "AZURE_SUBSCRIPTION_ID" "$DEV_SUBSCRIPTION_ID"
  create_or_update_variable "dev" "CIDR_RANGE" "$DEV_CIDR_RANGE"
  create_or_update_variable "dev" "DEV_CIDR_RANGE" "$DEV_CIDR_RANGE"
  create_or_update_variable "dev" "AIFACTORY_CIDR_XX" "$DEV_CIDR_RANGE"
  create_or_update_variable "dev" "DEV_NETWORK_ENV" "$DEV_NETWORK_ENV"
  create_or_update_variable "dev" "NETWORK_ENV" "$DEV_NETWORK_ENV"
  if [[ "$overwrite_azure_credential" == "y" ]]; then
    create_or_update_secret "dev" "AZURE_CREDENTIALS" "replace_with_dev_sp_credentials"
  fi
fi

if [[ " ${selected_environments[*]} " == *" stage "* ]]; then
  create_or_update_variable "stage" "AZURE_LOCATION" "$AIFACTORY_LOCATION"
  create_or_update_variable "stage" "AZURE_SUBSCRIPTION_ID" "$STAGE_SUBSCRIPTION_ID"
  create_or_update_variable "stage" "CIDR_RANGE" "$STAGE_CIDR_RANGE"
  create_or_update_variable "stage" "STAGE_CIDR_RANGE" "$STAGE_CIDR_RANGE"
  create_or_update_variable "stage" "AIFACTORY_CIDR_XX" "$STAGE_CIDR_RANGE"
  create_or_update_variable "stage" "STAGE_NETWORK_ENV" "$STAGE_NETWORK_ENV"
  create_or_update_variable "stage" "NETWORK_ENV" "$STAGE_NETWORK_ENV"
  if [[ "$overwrite_azure_credential" == "y" ]]; then
    create_or_update_secret "stage" "AZURE_CREDENTIALS" "replace_with_stage_sp_credentials"
  fi
fi

if [[ " ${selected_environments[*]} " == *" prod "* ]]; then
  create_or_update_variable "prod" "AZURE_LOCATION" "$AIFACTORY_LOCATION"
  create_or_update_variable "prod" "AZURE_SUBSCRIPTION_ID" "$PROD_SUBSCRIPTION_ID"
  create_or_update_variable "prod" "CIDR_RANGE" "$PROD_CIDR_RANGE"
  create_or_update_variable "prod" "PROD_CIDR_RANGE" "$PROD_CIDR_RANGE"
  create_or_update_variable "prod" "AIFACTORY_CIDR_XX" "$PROD_CIDR_RANGE"
  create_or_update_variable "prod" "PROD_NETWORK_ENV" "$PROD_NETWORK_ENV"
  create_or_update_variable "prod" "NETWORK_ENV" "$PROD_NETWORK_ENV"
  if [[ "$overwrite_azure_credential" == "y" ]]; then
    create_or_update_secret "prod" "AZURE_CREDENTIALS" "replace_with_prod_sp_credentials"
  fi
fi