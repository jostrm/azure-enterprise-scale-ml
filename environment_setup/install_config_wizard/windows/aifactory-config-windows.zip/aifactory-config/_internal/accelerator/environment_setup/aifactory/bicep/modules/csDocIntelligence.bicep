param csSKU string = 'S0'
param location string
param name string
param kind string = 'FormRecognizer'
param publicNetworkAccess bool = true
param vnetRules array = []
param ipRules array = []
param pendCogSerName string
param vnetName string
param subnetName string
param restore bool
param keyvaultName string
param vnetResourceGroupName string
param enablePublicAccessWithPerimeter bool = false
param disableLocalAuth bool = false

var nameCleaned = toLower(replace(name, '-', ''))

@description('Expiry of every secret and key this template creates, in Unix epoch seconds. Default: one year after the deployment runs (keyVaultDefaults.json secretExpiresAfter).')
param keyVaultSecretExpiry int = dateTimeToEpoch(dateTimeAdd(utcNow(), 'P1Y'))

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vnetName
  scope: resourceGroup(vnetResourceGroupName)
}

resource subnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  name: subnetName
  parent: vnet
}
var rules = [for rule in vnetRules: {
  id: rule
  ignoreMissingVnetServiceEndpoint: true
}]

resource csAccountDocInt 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: name
  location: location
  kind: kind
  identity: {
    type: 'SystemAssigned'
  }
  sku: {
    name: csSKU
  }
  properties: {
    customSubDomainName: nameCleaned
    publicNetworkAccess: publicNetworkAccess||enablePublicAccessWithPerimeter? 'Enabled': 'Disabled'
    restore: restore
    restrictOutboundNetworkAccess: publicNetworkAccess? false:true
    disableLocalAuth: disableLocalAuth
    networkAcls: !enablePublicAccessWithPerimeter ? {
      //bypass:'AzureServices'
      defaultAction:'Deny'
      virtualNetworkRules: rules
      ipRules: ipRules
    }:null
  }
  
}

resource pendCognitiveServices 'Microsoft.Network/privateEndpoints@2023-04-01' = if(!enablePublicAccessWithPerimeter){
  location: location
  name: '${nameCleaned}-pend'
  properties: {
    subnet: {
      id: subnet.id
    }
    customNetworkInterfaceName: '${nameCleaned}-pend-nic'
    privateLinkServiceConnections: [
      {
        name: '${nameCleaned}-pend'
        properties: {
          privateLinkServiceId: csAccountDocInt.id
          groupIds: [
            'account'
          ]
          privateLinkServiceConnectionState: {
            status: 'Approved'
            description: 'Auto-Approved'
            actionsRequired: 'None'
          }
        }
      }
    ]
  }
}
resource keyVaultDocInt 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyvaultName
  scope: resourceGroup()
}

@description('Key Vault: Azure AI Document Intelligence Endpoint in vault as S')
resource kValueDocInt2 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: keyVaultDocInt
  name: 'aifactory-proj-aidocintelligence-api-endpoint'
  properties: {
    value:csAccountDocInt.properties.endpoint
    contentType: 'text/plain'
    attributes: {
      enabled: true
      exp: keyVaultSecretExpiry
    }
  }
}


output name string = csAccountDocInt.name
output resourceId string = csAccountDocInt.id
output principalId string = csAccountDocInt.identity.principalId 
output endpoint string = csAccountDocInt.properties.endpoint
output host string = split(csAccountDocInt.properties.endpoint, '/')[2]

output dnsConfig array = [
  {
    name: !enablePublicAccessWithPerimeter? pendCognitiveServices.name: ''
    type: 'cognitiveservices'
    id:csAccountDocInt.id
    groupid:'account'
  }
]
