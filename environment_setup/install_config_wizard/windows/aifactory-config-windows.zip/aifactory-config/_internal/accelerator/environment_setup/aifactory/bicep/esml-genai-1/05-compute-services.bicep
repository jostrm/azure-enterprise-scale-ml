targetScope = 'subscription'

// ================================================================
// COMPUTE SERVICES DEPLOYMENT - Phase 5 Implementation
// This file deploys compute services including:
// - Azure Web Apps
// - Azure Functions
// - Container Apps Environment
// - Container Apps (API & Web)
// - Managed Identity for Container Apps
// - Subnet delegations for compute services
// ================================================================
// CMK: Is not supported for these services. But storage, and keyvault for App services packages uses CMK, from other bicep.
// ============================================================================
// SKU for services
// ============================================================================
param aseSkuWorkers int = 1 // Number of workers for ASE v3
param aseSku string = 'IsolatedV2' // I family for ASE v3
@allowed([
  'I1v2'  // Isolated v2 for ASEv3
  'I2v2'
  'I3v2'
  'I4v2'
  'I5v2'
  'I6v2'
])
param aseSkuCode string = 'I1v2' // I family for ASE v3
param webappSKUAce object = {
  name: aseSkuCode
  tier: aseSku
  size: aseSkuCode
  family: 'Iv2'
  capacity: aseSkuWorkers
}

// Function App configuration
param functionSKU object = {
  name: 'EP1'
  tier: 'ElasticPremium'
  family: 'EP'
  capacity: 1
}
// Web App configuration
param webappSKU object = {
  name: 'P1v3'
  tier: 'PremiumV3'
  family: 'Pv3'
  capacity: 1
}

// Per-environment Web App / Function plan SKU (name) and tier passed from the pipeline (Dev vs Stage/Prod).
// Empty = fall back to the template default object above. test(=Stage) uses the *StageProd value.
@description('Web App plan SKU name for dev. Empty = webappSKU.name default.')
param skuWebAppDev string = ''
@description('Web App plan SKU name for stage/prod. Empty = webappSKU.name default.')
param skuWebAppStageProd string = ''
@description('Web App plan SKU tier for dev. Empty = webappSKU.tier default.')
param skuTierWebAppDev string = ''
@description('Web App plan SKU tier for stage/prod. Empty = webappSKU.tier default.')
param skuTierWebAppStageProd string = ''
@description('Function plan SKU name for dev. Empty = functionSKU.name default.')
param skuFunctionDev string = ''
@description('Function plan SKU name for stage/prod. Empty = functionSKU.name default.')
param skuFunctionStageProd string = ''
@description('Function plan SKU tier for dev. Empty = functionSKU.tier default.')
param skuTierFunctionDev string = ''
@description('Function plan SKU tier for stage/prod. Empty = functionSKU.tier default.')
param skuTierFunctionStageProd string = ''

// ============== AKS SKUs ==============
@description('Specifies the SKU name for the AKS cluster')
@allowed([
  'Base'
  'Standard'
])
param aksSkuName string = 'Base'

@description('Specifies the SKU tier for the AKS cluster')
@allowed([
  'Free'
  'Standard'
  'Premium'
])
param aksSkuTier string = 'Standard'
param aksLoadBalancerSku string = 'standard' // 'basic' or 'standard'
param aksEnablePrivateCluster bool = true
param aksManagedOutboundIPs int = 1
@description('Specifies the outbound (egress) routing method for the AKS cluster')
@allowed([
  'loadBalancer'
  'userDefinedRouting'
  'managedNATGateway'
  'userAssignedNATGateway'
])
param aksOutboundType string = 'loadBalancer'
param aksPrivateDNSZone string = 'system' // 'none', 'system' or resource ID

// AKS compute configuration
param aksServiceCidr string = '10.0.0.0/16'
param aksDnsServiceIP string = '10.0.0.10'
param aks_dev_sku_override string = ''
param aks_test_prod_sku_override string = ''
param aks_version_override string = ''
param aks_dev_nodes_override int = -1
param aks_test_prod_nodes_override int = -1

// Per-environment AKS node SKU (vmSize) and SKU tier passed from the pipeline (Dev vs Stage/Prod)
@description('AKS node vmSize for dev. Empty = template default. Takes precedence over aks_dev_sku_override.')
param skuAksDev string = ''
@description('AKS node vmSize for stage/prod (test/prod). Empty = template default. Takes precedence over aks_test_prod_sku_override.')
param skuAksStageProd string = ''
@description('AKS SKU tier for dev. Empty = fall back to aksSkuTier.')
param skuTierAksDev string = ''
@description('AKS SKU tier for stage/prod (test/prod). Empty = fall back to aksSkuTier.')
param skuTierAksStageProd string = ''

@description('Diagnostic setting level for monitoring and logging')
@allowed(['gold', 'silver', 'bronze'])
param diagnosticSettingLevel string = 'gold'

@description('Enable Customer Managed Keys (CMK) encryption')
param cmk bool = false

@description('Name of the Customer Managed Key in Key Vault')
param cmkKeyName string = ''

// ============== PARAMETERS ==============
@description('Environment: dev, test, prod')
@allowed(['dev', 'test', 'prod'])
param env string

@description('Project number (e.g., "005")')
param projectNumber string

@description('Location for all resources')
param location string

@description('Location suffix (e.g., "weu", "swc")')
param locationSuffix string

@description('Common resource suffix (e.g., "-001")')
param commonResourceSuffix string

@description('Project-specific resource suffix')
param resourceSuffix string

// Exists flags from Azure Devops
param applicationInsightExists bool = false
param containerAppsEnvExists bool = false
param containerAppAExists bool = false
param containerAppWExists bool = false
param functionAppExists bool = false
param webAppExists bool = false
param funcAppServicePlanExists bool = false
param webAppServicePlanExists bool = false
param bingExists bool = false
param aksExists bool = false

param aiFoundryV2Exists bool = false
param enableAIFoundry bool = false
param disableAgentNetworkInjection bool = true

param enableAppInsightsDashboard bool = true
param enableBingSearch bool = false

// Enable flags from parameter files
@description('Enable Container Apps deployment')
param enableContainerApps bool = false

@description('Enable Azure Function deployment')
param enableFunction bool = false

@description('Enable Azure Web App deployment')
param enableWebApp bool = false

@description('Enable standalone AKS deployment')
param enableAKS bool = false
@description('Defender for Cloud: encryption at host on the AKS node pools of a new cluster. Needs the subscription feature Microsoft.Compute/EncryptionAtHost.')
param enableEncryptionAtHost bool = true

param enableAzureOpenAI bool = false
param enableAISearch bool = false
param enableAIServices bool = false
param addAISearch bool = false

// Security and networking
param enablePublicGenAIAccess bool = false
param enablePublicAccessWithPerimeter bool = false
param centralDnsZoneByPolicyInHub bool = false

// ============================================================================
// PS-Networking: Needs to be here, even if not used, since .JSON file
// ============================================================================
@description('Required subnet IDs from subnet calculator')
param genaiSubnetId string
param aksSubnetId string
param acaSubnetId string
@description('Optional subnets from subnet calculator')
param aca2SubnetId string = ''
param aks2SubnetId string = ''
@description('Optional dedicated App Service/Function VNet integration subnet (delegated to Microsoft.Web/serverFarms at creation)')
param webappSubnetId string = ''
param logicappSubnetId string = ''
@description('if projectype is not genai-1, but instead all')
param dbxPubSubnetName string = ''
param dbxPrivSubnetName string = ''

// Networking parameters for calculation
param vnetNameBase string
param vnetResourceGroup_param string = ''
param vnetNameFull_param string = ''
param network_env string = ''

// Private DNS configuration
param privDnsSubscription_param string = ''
param privDnsResourceGroup_param string = ''
@description('Own access hub, added scale set: ARM id (/subscriptions/<sub>/resourceGroups/<rg>) of the resource group holding the bootstrap-managed private DNS zones. Empty for the bootstrap scale set and every other topology.')
param own_hub_private_dns_resource_group_id string = ''

// Resource group configuration
param commonResourceGroup_param string = ''

// Function App configuration
param functionAlwaysOn bool = true
@allowed([
  'dotnet'
  'node'
  'python'
  'java'
])
param functionRuntime string = 'python' //'node', 'dotnet', 'java', 'python'
@allowed([
  '3.7'
  '3.8'
  '3.9'
  '3.10'
  '3.11'
  '3.12'
  // Node.js versions
  '18-lts'
  '20-lts'
  // Java LTS versions
  '8'
  '11'
  '17'
  '21'
  // .NET versions
  'v4.8'
  'v6.0'
  'v7.0'
  'v8.0'
])
param functionVersion string = '3.11'

// Web App configuration
param webappAlwaysOn bool = true
@allowed([
  'dotnet'
  'node'
  'python'
  'java'
])
param webAppRuntime string = 'python'  // Set to 'python' for Python apps
@allowed([
  '3.7'
  '3.8'
  '3.9'
  '3.10'
  '3.11'
  '3.12'
  // Node.js versions
  '18-lts'
  '20-lts'
  // Java LTS versions
  '8'
  '11'
  '17'
  '21'
  // .NET versions
  'v4.8'
  'v6.0'
  'v7.0'
  'v8.0'
])
param webAppRuntimeVersion string = '3.11'  // Specify the Python version

// ASE (App Service Environment) settings
param byoASEv3 bool = false
param byoAseFullResourceId string = ''
param byoAseAppServicePlanResourceId string = ''

// Container Apps settings
@allowed(['Consumption', 'D4', 'D8'])
param skuContainerAppsDev string = 'Consumption'
@allowed(['Consumption', 'D4', 'D8'])
param skuContainerAppsStageProd string = 'Consumption'
@description('Reapply Container Apps configuration when the resources already exist. Defaults to the legacy skip-existing behavior.')
param updateExistingContainerApps bool = false
param wlMinCountServerless int = 0
param wlMinCountDedicated int = 1
param wlMaxCount int = 100
param containerMemory string = '2.0Gi' // 0.5Gi, 1.0Gi, 2.0Gi, 4.0Gi, 8.0Gi
param wlProfileDedicatedName string = 'D4' // 'D4', 'D8', 'D16', 'D32', 'D64', 'E4', 'E8'
param wlProfileGPUConsumptionName string = 'Consumption-GPU-NC24-A100'
param acaAppWorkloadProfileName string = 'consumption'
param containerCpuCoreCount int = 1

// Container App images
param aca_a_registry_image string = ''
param aca_w_registry_image string = ''
param aca_default_image string = 'mcr.microsoft.com/azuredocs/containerapps-helloworld:latest'

// Custom domains for Container Apps
param acaCustomDomainsArray array = []

// Redundancy mode
param appRedundancyMode string = 'None'

// OpenAI API settings
param openAiApiVersion string = '2024-06-01'

// Tags
param tagsProject object = {}
param tags object = {}

// IP Rules
param IPwhiteList string = ''

// Dependencies and naming
param aifactorySuffixRG string
param commonRGNamePrefix string

// Missing parameters required for naming convention module
param aifactorySalt10char string = ''
param randomValue string
param technicalAdminsObjectID string = ''
param technicalAdminsEmail string = ''
param subscriptionIdDevTestProd string = subscription().subscriptionId

// Common ACR usage
param useCommonACR bool = true

// Common names for referencing other resources
param projectPrefix string = 'esml-'
param projectSuffix string = '-rg'
@description('Common resource name identifier. Default is "esml-common"')
param commonResourceName string = 'esml-common'

// ============== VARIABLES ==============
var aseIdNormalized = (!byoASEv3 || empty(byoAseFullResourceId))
  ? ''
  : (startsWith(byoAseFullResourceId, '/subscriptions/') || startsWith(byoAseFullResourceId, '/providers/'))
    ? byoAseFullResourceId
    : '/${byoAseFullResourceId}'

// Calculated variables
var projectName = 'prj${projectNumber}'
var commonResourceGroup = !empty(commonResourceGroup_param) ? commonResourceGroup_param : '${commonRGNamePrefix}${commonResourceName}-${locationSuffix}-${env}${aifactorySuffixRG}'
var targetResourceGroup = '${commonRGNamePrefix}${projectPrefix}${replace(projectName, 'prj', 'project')}-${locationSuffix}-${env}${aifactorySuffixRG}${projectSuffix}'

// Networking calculations
var vnetNameFull = !empty(vnetNameFull_param) ? replace(vnetNameFull_param, '<network_env>', network_env) : '${vnetNameBase}-${locationSuffix}-${env}${commonResourceSuffix}'
var vnetResourceGroupName = !empty(vnetResourceGroup_param)? replace(vnetResourceGroup_param, '<network_env>', network_env) : commonResourceGroup

// Private DNS calculations
// Own access hub, added scale set: zones live in the bootstrap's DNS resource group, not in this scale set's.
// A literal '$(own_hub_private_dns_resource_group_id)' (ADO, variable not defined) is not an id and is ignored.
var ownHubPrivateDns = !centralDnsZoneByPolicyInHub && startsWith(toLower(own_hub_private_dns_resource_group_id), '/subscriptions/')
var ownHubPrivateDnsParts = split('${own_hub_private_dns_resource_group_id}////', '/')
var privDnsResourceGroupName = ownHubPrivateDns ? ownHubPrivateDnsParts[4] : ((!empty(privDnsResourceGroup_param) && centralDnsZoneByPolicyInHub) ? privDnsResourceGroup_param : vnetResourceGroupName)
var privDnsSubscription = ownHubPrivateDns ? ownHubPrivateDnsParts[2] : ((!empty(privDnsSubscription_param) && centralDnsZoneByPolicyInHub) ? privDnsSubscription_param : subscriptionIdDevTestProd)

// Random salt for unique naming - using uniqueString for deterministic salt
var randomSalt = substring(uniqueString(subscription().subscriptionId, targetResourceGroup), 0, 5)

// ============================================================================
// AI Factory - naming convention (imported from shared module)
// ============================================================================
module namingConvention '../modules/common/CmnAIfactoryNaming.bicep' = {
  name: take('05-naming-${targetResourceGroup}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    env: env
    projectNumber: projectNumber
    locationSuffix: locationSuffix
    commonResourceSuffix: commonResourceSuffix
    resourceSuffix: resourceSuffix
    aifactorySalt10char: aifactorySalt10char
    randomValue: randomValue
    aifactorySuffixRG: aifactorySuffixRG
    commonRGNamePrefix: commonRGNamePrefix
    technicalAdminsObjectID: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsObjectID
    technicalAdminsEmail: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsEmail
    commonResourceGroupName: commonResourceGroup
    subscriptionIdDevTestProd: subscriptionIdDevTestProd
    acaSubnetId: acaSubnetId
    aksSubnetId:aksSubnetId
    genaiSubnetId:genaiSubnetId
    aca2SubnetId: aca2SubnetId
    aks2SubnetId: aks2SubnetId
    webappSubnetId: webappSubnetId
  }
}

// Import specific names needed for compute services deployment
var webAppName = namingConvention.outputs.webAppName
var functionAppName = namingConvention.outputs.functionAppName
var containerAppsEnvName = namingConvention.outputs.containerAppsEnvName
var containerAppAName = namingConvention.outputs.containerAppAName
var containerAppWName = namingConvention.outputs.containerAppWName
var miACAName = namingConvention.outputs.miACAName
var miPrjName = namingConvention.outputs.miPrjName
var storageAccount1001Name = namingConvention.outputs.storageAccount1001Name
var storageAccount2001Name = namingConvention.outputs.storageAccount2001Name
var acrProjectName = namingConvention.outputs.acrProjectName
var acrCommonName = namingConvention.outputs.acrCommonName
var safeNameAISearchOrg = enableAISearch? namingConvention.outputs.safeNameAISearch: ''
var aoaiName = enableAzureOpenAI? namingConvention.outputs.aoaiName: ''
var aiServicesName = enableAIServices? namingConvention.outputs.aiServicesName: ''
var bingName = namingConvention.outputs.bingName
var applicationInsightName = namingConvention.outputs.applicationInsightName
var laWorkspaceName = namingConvention.outputs.laWorkspaceName
var keyvaultName = namingConvention.outputs.keyvaultName

// AI Search name construction
var cleanRandomValue = take(namingConvention.outputs.randomSalt,2)

var safeNameAISearchBase = (enableAISearch && !empty(safeNameAISearchOrg))
  ? take(safeNameAISearchOrg, max(length(safeNameAISearchOrg) - 3, 0))
  : ''

var safeNameAISearchSuffix = (enableAISearch && !empty(safeNameAISearchOrg))
  ? substring(
      safeNameAISearchOrg,
      max(length(safeNameAISearchOrg) - 3, 0),
      min(3, length(safeNameAISearchOrg))
    )
  : ''

var aiSearchName = (enableAISearch && !empty(safeNameAISearchOrg))
  ? take(
      addAISearch
        ? '${safeNameAISearchBase}${cleanRandomValue}${safeNameAISearchSuffix}'
        : safeNameAISearchOrg,
      60
    )
  : ''

// AI Foundry Hub
var aifV1HubName = namingConvention.outputs.aifV1HubName
var aifV1ProjectName = namingConvention.outputs.aifV1ProjectName

// AI Foundry V2
var aifV2ProjectName = namingConvention.outputs.aifV2Name
var aifV2Name = namingConvention.outputs.aifV2PrjName

// Computed variables using naming convention outputs
var deploymentProjSpecificUniqueSuffix = '${projectName}${env}${randomSalt}'

// Subnet names from naming convention
var genaiSubnetName = namingConvention.outputs.genaiSubnetName
var aksSubnetName = namingConvention.outputs.aksSubnetName
var acaSubnetName = namingConvention.outputs.acaSubnetName
var aca2SubnetName = namingConvention.outputs.aca2SubnetName
var aks2SubnetName = namingConvention.outputs.aks2SubnetName
var webappSubnetName = namingConvention.outputs.webappSubnetName
var defaultSubnet = namingConvention.outputs.defaultSubnet

// AKS naming from naming convention
var aksClusterName = namingConvention.outputs.aksClusterName
var aksNodeResourceGroupName = 'aks-${targetResourceGroup}' // AKS node resource group name follows the pattern 'aks-<project-rg-name>'

// AKS default compute sizes and versions
var aksDefaultVersion = '1.33.2'
var aks_dev_defaults = [
  'Standard_B4ms'
  'Standard_A4m_v2'
  'Standard_D3_v2'
]
var aks_testProd_defaults = [
  'Standard_DS13-2_v2'
  'Standard_A8m_v2'
]

// Resolved AKS compute parameters
// Precedence: per-env pipeline SKU (skuAksDev/skuAksStageProd) > legacy override > template default
var aks_dev_sku_param = !empty(skuAksDev) ? skuAksDev : (!empty(aks_dev_sku_override) ? aks_dev_sku_override : aks_dev_defaults[0])
var aks_test_prod_sku_param = !empty(skuAksStageProd) ? skuAksStageProd : (!empty(aks_test_prod_sku_override) ? aks_test_prod_sku_override : aks_testProd_defaults[0])
// Resolved AKS SKU tier per environment (fall back to aksSkuTier when per-env not provided)
var aksSkuTierResolved = env == 'dev' ? (!empty(skuTierAksDev) ? skuTierAksDev : aksSkuTier) : (!empty(skuTierAksStageProd) ? skuTierAksStageProd : aksSkuTier)

// Resolved per-env Web App / Function plan SKU objects.
// Override name + tier from the pipeline; keep family + capacity from the template default object.
var webAppSkuNameResolved = env == 'dev' ? (!empty(skuWebAppDev) ? skuWebAppDev : webappSKU.name) : (!empty(skuWebAppStageProd) ? skuWebAppStageProd : webappSKU.name)
var webAppSkuTierResolved = env == 'dev' ? (!empty(skuTierWebAppDev) ? skuTierWebAppDev : webappSKU.tier) : (!empty(skuTierWebAppStageProd) ? skuTierWebAppStageProd : webappSKU.tier)
var webappSKUResolved = union(webappSKU, {
  name: webAppSkuNameResolved
  tier: webAppSkuTierResolved
})
var functionSkuNameResolved = env == 'dev' ? (!empty(skuFunctionDev) ? skuFunctionDev : functionSKU.name) : (!empty(skuFunctionStageProd) ? skuFunctionStageProd : functionSKU.name)
var functionSkuTierResolved = env == 'dev' ? (!empty(skuTierFunctionDev) ? skuTierFunctionDev : functionSKU.tier) : (!empty(skuTierFunctionStageProd) ? skuTierFunctionStageProd : functionSKU.tier)
var functionSKUResolved = union(functionSKU, {
  name: functionSkuNameResolved
  tier: functionSkuTierResolved
})
var aks_version_param = !empty(aks_version_override) ? aks_version_override : aksDefaultVersion
var aks_dev_nodes_param = aks_dev_nodes_override != -1 ? aks_dev_nodes_override : 1
var aks_test_prod_nodes_param = aks_test_prod_nodes_override != -1 ? aks_test_prod_nodes_override : 3

// AKS subnet selection: prefer aksSubnetId, fall back to aks2SubnetId
var aksSubnetIdResolved = !empty(aksSubnetId) ? aksSubnetId : aks2SubnetId

// VNet integration subnet for WebApp/Function.
// Preferred: the dedicated 'webapp' subnet (snt-<proj>-webapp), pre-delegated to Microsoft.Web/serverFarms at creation (31-network.bicep).
// Legacy fallback (no dedicated subnet provisioned yet): use aksSubnetName ONLY when AKS is NOT enabled
// (AKS requires its subnet undelegated), otherwise acaSubnetName. The runtime subnetDelegationServerFarm
// module below applies the serverFarms delegation only in the legacy fallback case.
var vnetIntegrationSubnetName = !empty(webappSubnetName) ? webappSubnetName : ((!enableAKS && !empty(aksSubnetName)) ? aksSubnetName : acaSubnetName)

// IP Rules processing
var ipWhitelist_array = !empty(IPwhiteList) ? split(IPwhiteList, ',') : []

// Safe domain construction to avoid InvalidDomainName errors
var safeLocation = toLower(location)

// Create location-specific domains for all regions - Azure Container Apps and MCR are widely available
var acaLocationEndpoint = '${safeLocation}.ext.azurecontainerapps.dev'
var mcrLocationEndpoint = '${safeLocation}.data.mcr.microsoft.com'

// Raw FQDN array with potential empty strings
var fqdnRaw = [
  // Private link FQDNs for networking
  'privatelink.blob.${environment().suffixes.storage}'
  'privatelink.cognitiveservices.azure.com'
  'privatelink.documents.azure.com'
  'privatelink.file.${environment().suffixes.storage}'
  'privatelink.openai.azure.com'
  'privatelink.search.windows.net'
  'privatelink.services.ai.azure.com'
  
  // Public FQDNs for specific Azure services
  // Storage Account 1 - Blob, File, Queue endpoints
  '${namingConvention.outputs.storageAccount1001Name}.blob.${environment().suffixes.storage}'
  '${namingConvention.outputs.storageAccount1001Name}.file.${environment().suffixes.storage}'
  '${namingConvention.outputs.storageAccount1001Name}.queue.${environment().suffixes.storage}'
  
  // Storage Account 2 - Blob, File, Queue endpoints
  '${namingConvention.outputs.storageAccount2001Name}.blob.${environment().suffixes.storage}'
  '${namingConvention.outputs.storageAccount2001Name}.file.${environment().suffixes.storage}'
  '${namingConvention.outputs.storageAccount2001Name}.queue.${environment().suffixes.storage}'
  
  // AI Search endpoint (conditionally included)
  enableAISearch ? '${aiSearchName}.search.windows.net' : ''
  
  // Key Vault endpoint
  '${namingConvention.outputs.keyvaultName}${environment().suffixes.keyvaultDns}'
  
  // Cosmos DB endpoint (conditionally included)
  //enableCosmosDB ? '${namingConvention.outputs.cosmosDBName}.documents.azure.com' : ''
  
  // AI Services endpoint
  '${aifV2Name}.cognitiveservices.azure.com'
  '${aifV2Name}.openai.azure.com'
  
  // #### Azure Container Apps (ACA) required FQDNs for AI agents ####
  
  // All scenarios - Microsoft Container Registry (MCR)
  'mcr.microsoft.com'
  // '*.data.mcr.microsoft.com' - replaced with regional endpoints
  mcrLocationEndpoint // Safe location-based endpoint
  // Aspire Dashboard 
  acaLocationEndpoint // Safe location-based ACA endpoint

  // Not inACA documented but required for various functionalities, Microsoft Graph API
  'graph.microsoft.com'

   // *.identity.azure.net
  'login.identity.azure.net'
  '${tenant().tenantId}.identity.azure.net'
  'sts.identity.azure.net'

  // '*.login.microsoft.com' - replaced with environment-specific endpoints
  /* Examples:    
  'login.microsoft.com'
  'account.login.microsoft.com'
  'portal.login.microsoft.com'
  'oauth.login.microsoft.com'
  'secure.login.microsoft.com'
  'sso.login.microsoft.com'
  'device.login.microsoft.com'
  */
  replace(environment().authentication.loginEndpoint, 'https://', '')
  'account.${replace(environment().authentication.loginEndpoint, 'https://', '')}'
  'portal.${replace(environment().authentication.loginEndpoint, 'https://', '')}'
  'oauth.${replace(environment().authentication.loginEndpoint, 'https://', '')}'
  'secure.${replace(environment().authentication.loginEndpoint, 'https://', '')}'
  'sso.${replace(environment().authentication.loginEndpoint, 'https://', '')}'
  'device.${replace(environment().authentication.loginEndpoint, 'https://', '')}'

  // Docker Hub Registry (if needed)
  'hub.docker.com'
  'registry-1.docker.io'
  'production.cloudflare.docker.com'
]

// Filter out empty strings and remove duplicates to ensure valid FQDN list for Azure validation
var fqdnFiltered = filter(fqdnRaw, fqdnEntry => !empty(fqdnEntry))
var fqdn = reduce(fqdnFiltered, [], (current, next) => contains(current, next) ? current : union(current, [next]))

// ============================================================================
// SPECIAL - Get PRINICPAL ID, only if created in this module, else ignore.
// ============================================================================
#disable-next-line BCP318
var var_webAppPrincipalId = enableWebApp && !webAppExists? webapp.outputs.principalId: ''
#disable-next-line BCP318
var var_functionPrincipalId= enableFunction && !functionAppExists? function.outputs.principalId: ''

var allowedOrigins = [
  'https://portal.azure.com'
  'https://ms.portal.azure.com'
  'https://mlworkspace.azure.ai'
  'https://ml.azure.com'
  'https://ai.azure.com'
  'https://mlworkspacecanary.azure.ai'
  'https://mlworkspace.azureml-test.net'
  'https://42.${location}.instances.azureml.ms'
  'https://457c18fd-a6d7-4461-999a-be092e9d1ec0.workspace.${location}.api.azureml.ms'
]

// DNS configurations for private endpoints (simplified)
// var var_webapp_dnsConfig = [
//   {
//     name: webAppName
//     type: 'Microsoft.Web/sites'
//     groupIds: ['sites']
//     resourceId: '${subscription().subscriptionId}/resourceGroups/${targetResourceGroup}/providers/Microsoft.Web/sites/${webAppName}'
//   }
// ]

#disable-next-line BCP318
var var_webapp_dnsConfig = enableWebApp && !webAppExists? webapp.outputs.dnsConfig: []

// var var_containerAppsEnv_dnsConfig = [
//   {
//     name: containerAppsEnvName
//     type: 'Microsoft.App/managedEnvironments'
//     groupIds: ['managedEnvironments']
//     resourceId: '${subscription().subscriptionId}/resourceGroups/${targetResourceGroup}/providers/Microsoft.App/managedEnvironments/${containerAppsEnvName}'
//   }
// ]

// var var_function_dnsConfig = [
//   {
//     name: functionAppName
//     type: 'Microsoft.Web/sites'
//     groupIds: ['sites']
//     resourceId: '${subscription().subscriptionId}/resourceGroups/${targetResourceGroup}/providers/Microsoft.Web/sites/${functionAppName}'
//   }
// ]

#disable-next-line BCP318
var var_function_dnsConfig = enableFunction && !functionAppExists? function.outputs.dnsConfig: []

resource commonResourceGroupRef 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: commonResourceGroup
  scope: subscription(subscriptionIdDevTestProd)
}
// ============================================================================
// SPECIAL -Needs static name in existing
// ============================================================================
var cmnName_Static = 'cmn'
var laWorkspaceName_Static = 'la-${cmnName_Static}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${commonResourceSuffix}'
resource logAnalyticsWorkspaceOpInsight 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: laWorkspaceName_Static
  scope:commonResourceGroupRef
}

resource existingTargetRG 'Microsoft.Resources/resourceGroups@2025-04-01' existing = {
  name: targetResourceGroup
  scope: subscription(subscriptionIdDevTestProd)
}

// ============== Private DNS Zones ==============
module CmnZones '../modules/common/CmnPrivateDnsZones.bicep' = {
  name: take('05-getPrivDnsZ-${targetResourceGroup}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    location: location
    privDnsResourceGroupName: privDnsResourceGroupName
    privDnsSubscription: privDnsSubscription
  }
}
var privateLinksDnsZones = CmnZones.outputs.privateLinksDnsZones

// Log Analytics workspace reference for diagnostics
resource logAnalyticsWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: laWorkspaceName
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
}

// ============== SUBNET DELEGATIONS ==============

// Subnet delegation for Web Apps and Function Apps
// When a dedicated 'webapp' subnet is provisioned (webappSubnetId not empty), it is ALREADY delegated to
// Microsoft.Web/serverFarms at subnet-creation time (31-network.bicep), so this runtime delegation is skipped.
// Legacy fallback only: delegate the actual VNet-integration subnet (vnetIntegrationSubnetName), never the
// AKS subnet when AKS is enabled. AKS requires an undelegated subnet, so vnetIntegrationSubnetName resolves
// to acaSubnetName when enableAKS is true. Condition uses start-known params only.
module subnetDelegationServerFarm '../modules/subnetDelegation.bicep' = if((!functionAppExists && !webAppExists) && (enableWebApp || enableFunction) && !byoASEv3 && empty(webappSubnetId) && (enableAKS ? !empty(acaSubnetId) : !empty(aksSubnetId))) {
  name: take('05-snetDelegSF1${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(vnetResourceGroupName)
  params: {
    vnetName: vnetNameFull
    subnetName: vnetIntegrationSubnetName // delegate the WebApp/Function integration subnet (never the AKS subnet when AKS is enabled)
    location: location
    vnetResourceGroupName: vnetResourceGroupName
    delegations: [
      {
        name: 'webapp-delegation'
        properties: {
          serviceName: 'Microsoft.Web/serverFarms'
        }
      }
    ]
  }
}

// Container Apps delegates its subnet in the shared service module. This path is only for Foundry agent network injection.
// Only runs when a dedicated ACA subnet exists (acaSubnetId or aca2SubnetId).
// Never delegates the genai subnet — private endpoints need it undelegated.
var acaDelegationSubnetName = !empty(acaSubnetName) ? acaSubnetName : aca2SubnetName
module subnetDelegationAca '../modules/subnetDelegation.bicep' = if ((!aiFoundryV2Exists && !disableAgentNetworkInjection) && (!empty(acaSubnetId) || !empty(aca2SubnetId))) {
  name: take('05-snetDelegACA${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(vnetResourceGroupName)
  params: {
    vnetName: vnetNameFull
    subnetName: acaDelegationSubnetName
    location: location
    vnetResourceGroupName: vnetResourceGroupName
    delegations: [
      {
        name: 'aca-delegation'
        properties: {
          serviceName: 'Microsoft.App/environments'
        }
      }
    ]
  }
  dependsOn: [
    subnetDelegationServerFarm // Serialize VNet subnet writes — concurrent modifications cause AnotherOperationInProgress
  ]
}

// ============== App insights Dashboard with AppInsights of type WEB  ==============

module appinsights '../modules/appinsights.bicep' = if(!applicationInsightExists && enableAppInsightsDashboard) {
  scope: resourceGroup(subscriptionIdDevTestProd,targetResourceGroup)
  name: take('05-AppInsights4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: namingConvention.outputs.applicationInsightName2
    location: location
    tags: tagsProject
    logAnalyticsWorkspaceId: logAnalyticsWorkspaceOpInsight.id
    dashboardName: namingConvention.outputs.dashboardInsightsName
  }
  dependsOn: [
    existingTargetRG
  ]
}
// ============== AZURE WEB APP ==============

module webapp '../modules/webapp.bicep' = if(!webAppExists && enableWebApp) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-WebApp4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: webAppName
    location: location
    tags: tagsProject
    sku: byoASEv3 ? webappSKUAce : webappSKUResolved
    alwaysOn: webappAlwaysOn
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetNamePend: defaultSubnet
    subnetIntegrationName: vnetIntegrationSubnetName // prefer aksSubnetName (/28+), falls back to acaSubnetName when AKS disabled
    enablePublicGenAIAccess: enablePublicGenAIAccess
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    applicationInsightsName: applicationInsightName
    logAnalyticsWorkspaceName: laWorkspaceName
    logAnalyticsWorkspaceRG: commonResourceGroup
    runtime: webAppRuntime
    redundancyMode: appRedundancyMode
    byoASEv3: byoASEv3
    byoAseFullResourceId: aseIdNormalized
    byoAseAppServicePlanRID: byoAseAppServicePlanResourceId
    runtimeVersion: webAppRuntimeVersion
    ipRules: ipWhitelist_array
    // Assign UAMI to Web App
    userAssignedIdentities: {
      '${resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.ManagedIdentity/userAssignedIdentities', miPrjName)}': {}
    }
    appSettings: [
      {
        name: 'AZURE_OPENAI_ENDPOINT'
        value: 'https://${aoaiName}.openai.azure.com/'
      }
      {
        name: 'AZURE_AISERVICES_ENDPOINT'
        value: 'https://${aiServicesName}.cognitiveservices.azure.com/'
      }
      {
        name: 'AZURE_SEARCH_ENDPOINT'
        value: 'https://${aiSearchName}.search.windows.net'
      }
      {
        name: 'WEBSITE_VNET_ROUTE_ALL'
        value: '1'
      }
    ]
  }
  dependsOn: [
    existingTargetRG
    subnetDelegationServerFarm
    subnetDelegationAca // Subnet PUTs can lock sibling subnets in the same VNet.
  ]
}

module privateDnsWebapp '../modules/privateDns.bicep' = if(!webAppExists && !centralDnsZoneByPolicyInHub && enableWebApp && !enablePublicAccessWithPerimeter && !byoASEv3) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-privDnsWeb${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    dnsConfig: var_webapp_dnsConfig
    privateLinksDnsZones: privateLinksDnsZones
  }
  dependsOn: [
    existingTargetRG
    webapp
  ]
}

// Add RBAC for WebApp MSI to access other resources (simplified)
module rbacForWebAppMSI '../modules/webappRbac.bicep' = if(!webAppExists && enableWebApp) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-rbacForWebApp${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name // Using different storage account
    aiSearchName: enableAISearch ? aiSearchName : ''
    webAppPrincipalId: var_webAppPrincipalId // Using computed variable for principal ID
    openAIName: enableAzureOpenAI ? aoaiName : ''
    aiServicesName: enableAIServices ? aiServicesName : ''
  }
  dependsOn: [
    webapp
  ]
}

// ============== AZURE FUNCTION ==============

module function '../modules/function.bicep' = if(!functionAppExists && enableFunction) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-Function4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: functionAppName
    location: location
    tags: tagsProject
    sku: byoASEv3 ? webappSKUAce : functionSKUResolved
    alwaysOn: functionAlwaysOn
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetNamePend: defaultSubnet
    subnetIntegrationName: vnetIntegrationSubnetName // prefer aksSubnetName (/28+), falls back to genaiSubnetName when AKS disabled
    storageAccountName: storageAccount1001Name
    enablePublicGenAIAccess: enablePublicGenAIAccess
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    applicationInsightsName: applicationInsightName
    logAnalyticsWorkspaceName: laWorkspaceName
    logAnalyticsWorkspaceRG: commonResourceGroup
    redundancyMode: appRedundancyMode
    byoASEv3: byoASEv3
    byoAseFullResourceId: aseIdNormalized
    byoAseAppServicePlanRID: byoAseAppServicePlanResourceId
    ipRules: ipWhitelist_array
    // Assign UAMI to Function App
    userAssignedIdentities: {
      '${resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.ManagedIdentity/userAssignedIdentities', miPrjName)}': {}
    }
    appSettings: [
      {
        name: 'AZURE_OPENAI_ENDPOINT'
        value: 'https://${aoaiName}.openai.azure.com/'
      }
      {
        name: 'AZURE_AISERVICES_ENDPOINT'
        value: 'https://${aiServicesName}.cognitiveservices.azure.com/'
      }
      {
        name: 'AZURE_SEARCH_ENDPOINT'
        value: 'https://${aiSearchName}.search.windows.net'
      }
    ]
    runtime: functionRuntime
    runtimeVersion: functionVersion
  }
  dependsOn: [
    existingTargetRG
    subnetDelegationServerFarm
    subnetDelegationAca
    webapp // App Service integrations share the delegated subnet.
  ]
}

// Add DNS zone configuration for the Azure Function private endpoint
module privateDnsFunction '../modules/privateDns.bicep' = if(!functionAppExists && !centralDnsZoneByPolicyInHub && enableFunction && !enablePublicAccessWithPerimeter && !byoASEv3) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-privDnsFunc${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    dnsConfig: var_function_dnsConfig
    privateLinksDnsZones: privateLinksDnsZones
  }
  dependsOn: [
    existingTargetRG
    function
  ]
}

// Add RBAC for Function App MSI to access other resources (simplified)
module rbacForFunctionMSI '../modules/functionRbac.bicep' = if(!functionAppExists && enableFunction) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-rbacForFunction${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    storageAccountName2: storageAccount2001Name // Using different storage account
    aiSearchName: enableAISearch ? aiSearchName : ''
    functionPrincipalId: var_functionPrincipalId // Using computed variable for principal ID
    openAIName: enableAzureOpenAI ? aoaiName : ''
    aiServicesName: enableAIServices ? aiServicesName : ''
  }
  dependsOn: [
    function
  ]
}

// ============== CONTAINER APPS ENVIRONMENT ==============

module containerApps '../modules/services/containerAppsDeployment.bicep' = if(enableContainerApps) {
  name: take('05-container-apps-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    context: {
      subscriptionId: subscriptionIdDevTestProd
      targetResourceGroup: targetResourceGroup
      commonResourceGroup: commonResourceGroup
      projectName: projectName
      vnetName: vnetNameFull
      vnetResourceGroupName: vnetResourceGroupName
      privateLinksDnsZones: privateLinksDnsZones
      names: {
        containerAppsEnvName: containerAppsEnvName
        containerAppAName: containerAppAName
        containerAppWName: containerAppWName
        miPrjName: miPrjName
        miACAName: miACAName
        defaultSubnet: defaultSubnet
        acaSubnetName: acaSubnetName
        aca2SubnetName: aca2SubnetName
        laWorkspaceName: laWorkspaceName
        applicationInsightName: applicationInsightName
        keyvaultName: keyvaultName
        acrCommonName: acrCommonName
        acrProjectName: acrProjectName
        aiServicesName: namingConvention.outputs.aiServicesName
        bingName: bingName
        aifV1ProjectName: aifV1ProjectName
      }
    }
    deploymentSuffix: deploymentProjSpecificUniqueSuffix
    location: location
    locationSuffix: locationSuffix
    env: env
    resourceSuffix: resourceSuffix
    tagsProject: tagsProject
    workloadProfileType: env == 'dev' ? skuContainerAppsDev : skuContainerAppsStageProd
    containerAppsEnvExists: containerAppsEnvExists
    containerAppAExists: containerAppAExists
    containerAppWExists: containerAppWExists
    updateExistingContainerApps: updateExistingContainerApps
    delegateSubnet: !empty(acaSubnetId) || !empty(aca2SubnetId)
    enablePublicGenAIAccess: enablePublicGenAIAccess
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    centralDnsZoneByPolicyInHub: centralDnsZoneByPolicyInHub
    wlMinCountServerless: wlMinCountServerless
    wlMinCountDedicated: wlMinCountDedicated
    wlMaxCount: wlMaxCount
    wlProfileDedicatedName: wlProfileDedicatedName
    wlProfileGPUConsumptionName: wlProfileGPUConsumptionName
    acaAppWorkloadProfileName: acaAppWorkloadProfileName
    containerCpuCoreCount: containerCpuCoreCount
    containerMemory: containerMemory
    aca_a_registry_image: aca_a_registry_image
    aca_w_registry_image: aca_w_registry_image
    aca_default_image: aca_default_image
    acaCustomDomainsArray: acaCustomDomainsArray
    IPwhiteList: IPwhiteList
    useCommonACR: useCommonACR
    enableAISearch: enableAISearch
    aiSearchName: aiSearchName
    enableAIServices: enableAIServices
    enableBingSearch: enableBingSearch
    openAiApiVersion: openAiApiVersion
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    existingTargetRG
    subnetDelegationServerFarm
    subnetDelegationAca
    webapp
    function // Finish App Service VNet integration before ACA mutates the VNet.
  ]
}

// ============================================================================
// Stable suffix for the existing common Log Analytics workspace.
// ============================================================================
#disable-next-line BCP318
var uniqueInAIFenv_Static = substring(uniqueString(commonResourceGroupRef.id), 0, 5)
// ============== AZURE KUBERNETES SERVICE (AKS) ==============

// AKS CMK: Disk Encryption Set Configuration
var aksDesKeyName = 'aks-des-key-${randomSalt}'
var aksDesName = 'aks-des-${projectNumber}-${locationSuffix}-${env}-${randomSalt}${resourceSuffix}'

module aksDesKey '../modules/keyVaultKey.bicep' = if (cmk && !empty(cmkKeyName) && !aksExists && !empty(aksSubnetIdResolved) && enableAKS) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-AKS-DES-Key-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultName: keyvaultName
    keyName: aksDesKeyName
    kty: 'RSA'
    keySize: 2048
    keyOps: [
      'encrypt'
      'decrypt'
      'wrapKey'
      'unwrapKey'
    ]
  }
}

module aksDiskEncryptionSet '../modules/diskEncryptionSet.bicep' = if (cmk && !empty(cmkKeyName) && !aksExists && !empty(aksSubnetIdResolved) && enableAKS) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-AKS-DES-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    desName: aksDesName
    location: location
    keyVaultId: resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.KeyVault/vaults', keyvaultName)
    keyUrl: aksDesKey!.outputs.keyUriWithVersion
    tags: tagsProject
  }
  dependsOn: [
    aksDesKey
  ]
}

module aksDesKvRbac '../modules/kvRbacSingleAssignment.bicep' = if (cmk && !empty(cmkKeyName) && !aksExists && !empty(aksSubnetIdResolved) && enableAKS) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-AKS-DES-RBAC-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultName: keyvaultName
    principalId: aksDiskEncryptionSet!.outputs.desPrincipalId
    keyVaultRoleId: 'e147488a-f6f5-4113-8e2d-b22465e65bf6' // Key Vault Crypto Service Encryption User
    principalType: 'ServicePrincipal'
    assignmentName: 'aks-des-kv-${randomSalt}'
    roleDescription: 'Allows Disk Encryption Set to access Key Vault for AKS disk encryption'
  }
  dependsOn: [
    aksDiskEncryptionSet
  ]
}

module aksDev '../modules/aksCluster.bicep' = if(env == 'dev' && !aksExists && !empty(aksSubnetIdResolved) && enableAKS) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-AKS-Dev-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: aksClusterName
    tags: tagsProject
    location: location
    skuName: aksSkuName
    skuTier: aksSkuTierResolved
    aksExists: aksExists
    kubernetesVersion: aks_version_param
    dnsPrefix: '${aksClusterName}-dns'
    enableRbac: true
    nodeResourceGroup: aksNodeResourceGroupName
    aksDnsServiceIP: aksDnsServiceIP
    aksServiceCidr: aksServiceCidr
    outboundType: aksOutboundType
    privateDNSZone: aksPrivateDNSZone
    cmk: cmk
    diskEncryptionSetID: cmk && !empty(cmkKeyName) ? aksDiskEncryptionSet!.outputs.desId : ''
    // Assign UAMI to AKS cluster
    userAssignedIdentities: {
      '${resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.ManagedIdentity/userAssignedIdentities', miPrjName)}': {}
    }
    agentPoolProfiles: [
      {
        name: toLower('agentpool')
        count: aks_dev_nodes_param
        vmSize: aks_dev_sku_param
        osType: 'Linux'
        osSKU: 'Ubuntu'
        mode: 'System'
        vnetSubnetID: aksSubnetIdResolved
        type: 'VirtualMachineScaleSets'
        maxPods: 30
        orchestratorVersion: aks_version_param
        osDiskSizeGB: 128
      }
    ]
    enablePrivateCluster: aksEnablePrivateCluster
    managedOutboundIPs: aksManagedOutboundIPs
    loadBalancerSku: aksLoadBalancerSku
    enableEncryptionAtHost: enableEncryptionAtHost
    logAnalyticsWorkspaceResourceId: logAnalyticsWorkspace.id
  }
  dependsOn: [
    existingTargetRG
    ...(cmk && !empty(cmkKeyName) ? [aksDesKvRbac] : [])
  ]
}

module aksTestProd '../modules/aksCluster.bicep' = if((env == 'test' || env == 'prod') && !aksExists && !empty(aksSubnetIdResolved) && enableAKS) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-AKS-TestProd-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: aksClusterName
    tags: tagsProject
    location: location
    skuName: aksSkuName
    skuTier: aksSkuTierResolved
    aksExists: aksExists
    kubernetesVersion: aks_version_param
    dnsPrefix: '${aksClusterName}-dns'
    enableRbac: true
    nodeResourceGroup: aksNodeResourceGroupName
    aksDnsServiceIP: aksDnsServiceIP
    aksServiceCidr: aksServiceCidr
    outboundType: aksOutboundType
    privateDNSZone: aksPrivateDNSZone
    cmk: cmk
    diskEncryptionSetID: cmk && !empty(cmkKeyName) ? aksDiskEncryptionSet!.outputs.desId : ''
    // Assign UAMI to AKS cluster
    userAssignedIdentities: {
      '${resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.ManagedIdentity/userAssignedIdentities', miPrjName)}': {}
    }
    agentPoolProfiles: [
      {
        name: 'agentpool'
        count: aks_test_prod_nodes_param
        vmSize: aks_test_prod_sku_param
        osType: 'Linux'
        osSKU: 'Ubuntu'
        mode: 'System'
        vnetSubnetID: aksSubnetIdResolved
        type: 'VirtualMachineScaleSets'
        maxPods: 30
        orchestratorVersion: aks_version_param
      }
    ]
    enablePrivateCluster: aksEnablePrivateCluster
    managedOutboundIPs: aksManagedOutboundIPs
    loadBalancerSku: aksLoadBalancerSku
    enableEncryptionAtHost: enableEncryptionAtHost
    logAnalyticsWorkspaceResourceId: logAnalyticsWorkspace.id
  }
  dependsOn: [
    existingTargetRG
    ...(cmk && !empty(cmkKeyName) ? [aksDesKvRbac] : [])
  ]
}

// ============== DIAGNOSTIC SETTINGS ==============

// Web App Diagnostic Settings
module webAppDiagnostics '../modules/diagnostics/webAppsDiagnostics.bicep' = if (!webAppExists && enableWebApp) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-diagWebApp-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    webAppName: webAppName
    logAnalyticsWorkspaceId: logAnalyticsWorkspace.id
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    webapp
  ]
}

// Function App Diagnostic Settings
module functionAppDiagnostics '../modules/diagnostics/functionAppsDiagnostics.bicep' = if (!functionAppExists && enableFunction) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('05-diagFunctionApp-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    functionAppName: functionAppName
    logAnalyticsWorkspaceId: logAnalyticsWorkspace.id
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    function
  ]
}

// ============== OUTPUTS - Simplified ==============
// Note: Outputs simplified to avoid conditional module reference issues
// Resource information should be retrieved through Azure CLI queries after deployment

@description('Web App deployment status')
output webAppDeployed bool = (!webAppExists && enableWebApp)

@description('Function App deployment status')
output functionAppDeployed bool = (!functionAppExists && enableFunction)

@description('Container Apps Environment deployment status')
output containerAppsEnvDeployed bool = ((!containerAppsEnvExists || updateExistingContainerApps) && enableContainerApps)

@description('Container App API deployment status')
output containerAppADeployed bool = ((!containerAppAExists || updateExistingContainerApps) && enableContainerApps)

@description('Container App Web deployment status')
output containerAppWDeployed bool = ((!containerAppWExists || updateExistingContainerApps) && enableContainerApps)

@description('ACR RBAC verification status for Container Apps')
output acrRbacVerified bool = enableContainerApps

@description('ACR RBAC verification timestamp')
output acrRbacVerificationCompleted string = enableContainerApps ? 'RBAC verification included in deployment' : 'RBAC verification not required'

@description('AKS deployment status')
output aksDeployed bool = (!aksExists && enableAKS)

@description('AKS cluster name')
output aksClusterNameOutput string = enableAKS ? aksClusterName : ''
