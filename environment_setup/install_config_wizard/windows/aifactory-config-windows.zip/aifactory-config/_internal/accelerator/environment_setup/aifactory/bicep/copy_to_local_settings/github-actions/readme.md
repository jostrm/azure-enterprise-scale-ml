# Github orchestration (.yaml): Bicep

>[!NOTE]
> If you want to learn how to configure the AI Factory in `standalone mode` versus `Hub-connected centralized private DNS zones` with `BYOVnet`- [ setup starting page](../../../../../documentation/v2/20-29/24-end-2-end-setup.md)
>

## Note: see [prerequisites](../../../../../documentation/v2/10-19/12-prerequisites-setup.md)

### Prerequisite setup tools:  on your laptop (for both option A) Azure Devops and B) Github):
- **Git Bash**: https://git-scm.com/downloads e.g. GNU bash, version 5.2.37 or above
    - **Purpose**: The install script runs in bash terminal (Git bash)
    - **Note Mac/Linux**: It has been seen that Ubuntu bash (sames that comes with Mac OS), additional libraries will be needed to be installed
    - **Version**: 5.2.37
    ```bash
    bash --version
    ```` 
### Prerequisite setup tools: on your laptop (for Option B - Github)
- **Github CLI**: https://cli.github.com/
    - **Purpose**: The .env file will push those values as Github secrets and variables, and create Github environments Dev, Stage, Production
    - **Version**: 2.71.0 or above
    ```bash
        gh --version
    ```` 

### Prerequisite: GIT enable long paths

```
git config --system core.longpaths true
```

## START

### Automated first scale set

After adding this repository as the `azure-enterprise-scale-ml` submodule and
running `00-start.sh`, a DEV-first setup can be prepared and deployed with:

```bash
bash ./GHA-create-new-aifactory-scaleset.sh
```

The launcher prompts for topology, access mode, subscription, region, CIDR,
naming, deployment identity, seeding Key Vault, team group, and GitHub
repository. It prefers a user-assigned managed identity federated to the GitHub
`dev` environment, while retaining `AZURE_CREDENTIALS` as the explicit
service-principal fallback. It commits the workflows, runs `infra-common.yml`,
verifies the common resource group, and then runs `infra-project.yml`. Use
`--dry-run` to review the plan or `--prepare-only` to stop before deployment.

### Last-run region reports (GitHub Actions and Azure DevOps)

The common, project networking/services, and Foundry templates publish
`aifactory-region-reports-*` artifacts even when a started job fails. Download the
JSON files from the pipeline run and import them into the AI Factory Admin UX.
Artifacts are **not** automatically synchronized to a local folder, including on
self-hosted runners. GitHub retains these artifacts for 14 days; Azure DevOps uses
the run's retention settings.

Update the central submodule **and re-copy the pipeline templates** for future
runs to include these hooks. Existing yellow repositories/copies and historical
runs are not modified. The existing Azure DevOps bootstrap copy includes the shared
`esml-infra-common/jobs/region-report-steps.yaml` template.

In the project job the region reports come before the AI Factory Agent steps: the chat agent
(`70-factory-chat-agent`), the AI Factory MCP and AI Gateway (`71-aifactory-mcp-ai-gateway`) and live voice
(`72-aifactory-agent-live-voice`) run last, in that order (GitHub Actions only removes the run-specific reviewed
configuration after them). The reports therefore describe the infrastructure result; an agent step failure shows
in the run itself, not in the report.

Each JSON file uses schema version 1 with `region`, `subscription_id`, `tenant_id`,
`environment` (`dev`, `stage`, `prod`, or empty), `source: pipeline_artifact`,
`run_id`, `run_url`, an actual UTC `observed_at`, and `observations`. Each observation
has `check_id`, `kind`, `service`, nullable `sku`, `status`, and a sanitized `message`.
ADO's `test` environment is normalized to `stage`.

- Preflight FAIL findings remain failed in the report even with `--warn-only`.
  `PREFLIGHT_REPORT_DIR` opts standalone preflight into reporting; supply
  `tenantId`/`TENANT_ID` (or `AIFACTORY_REPORT_TENANT_ID`) plus the normal target
  subscription, environment, and location arguments. All existing exit codes
  are preserved. `--skip` reports unknown, never a successful capacity check.
- Search reports use the service ID `microsoft.search/searchservices`.
  `search_sku_availability` records whether the tested SKU is listed in the regional
  usage catalogue: discovery evidence, **not a live allocation probe**.
  Malformed/transient quota responses are unknown, not unavailable capacity.
  `search_sku_quota` headroom and catalogue success never clear a
  `search_sku_capacity` allocation failure or prove another Search tier is available.
  Only an explicit pass for the same check, service, SKU and target can clear its
  earlier failure; overall job success does not create SKU capacity passes.
- `pipeline-job:<job>` reports only that job's failed/passed/unknown result.
  A successful job does not clear a different job or prove service/SKU capacity.
  Cancellation, skipping, partial success, and unavailable statuses are unknown.
- Final reporting does not fetch logs or call Azure/pipeline APIs. The default
  failure reason is “Pipeline job failed; see linked run logs.” No raw logs,
  passwords, configuration values, or remediation command dumps are included.

For an **already captured, single tested Search command** error, the optional
`region_report.py pipeline --command-error-file <file>` accepts a local envelope
such as `{"service":"microsoft.search/searchservices","sku":"basic","error":{"code":"SkuNotAvailable"}}`.
Only recognized capacity/allocation codes create a capacity observation; generic
deployment errors, quota errors, unrelated services, and untested SKUs do not.
The standard hooks do not manufacture this envelope or infer it from a full job
log. Do not pass unrelated multi-service deployment errors as Search errors.

Reporting requires Python and a successful helper checkout. Invalid/missing
region, subscription, tenant, or environment metadata produces a warning and no
malformed JSON, without changing the deployment exit status. A job that never
starts, loses its runner, or cannot check out the helpers may have no artifact.

1) Add or Update the submodule to your repo (to get the bootstrap files)

    ADD, if you are the first developer to checkin the code. Run from your repo root location:
    ```
    git submodule add https://github.com/jostrm/azure-enterprise-scale-ml
    ```
    UPDATE, if you are not the 1st developer to checkin the code to your repo, e.g. if you cloned the repo.
    ```bash
    git submodule update --init --recursive --remote
    ```

    Then in both cases (ADD or UPDATE) choose A or B, where we recommend Option A:
    
    **Option A)** To get `stable version` (recommended), set at specific `RELEASE branch`: 
    ```
    git submodule foreach 'git checkout "release/v1.24" && git pull origin "release/v1.24"'
    ```

    **Option B)**
    To get latest features/fixes, unstable, set at `MAIN branch`: 
    ``` 
    git submodule foreach 'git checkout main && git pull origin main'
    ```
    This will add a folder in your repo at root (a GIT submodule) called `azure-enterprise-scale-ml` that contains accelerator code (bootstrap scripts, templates)
    
2) Run the start script `./azure-enterprise-scale-ml/00-start.sh`,  this will create some bootstrap-scripts at your repo root.

    ```
   bash ./azure-enterprise-scale-ml/00-start.sh
    ```
3) Run the file created at your root called: `01-aif-copy-aifactory-templates.sh`, this will create a folder at your root called `aifactory-templates` with templates for GHA workflows, and parameters.
    ```
   bash ./01-aif-copy-aifactory-templates.sh
    ```
4) Rename the newly created folder  `aifactory-templates` to  `aifactory` (protects you to overwrite your configuration if running the script again)
    - Note: Is is under the `aifactory` folder, you will configure your variables, and the possibility to leverage BYOBicep when editing the GH workflow templates.
5) Run the file created at your root called: `02-GH-bootstrap-files.sh`, this will create an .env file at your root.
    - Note: If you want to refresh the pipeline templates, but not overwrite the .env file, you may run `03-GH-bootstrap-files-no-env-overwrite.sh`
     ```
   bash ./02-GH-bootstrap-files.sh
    ```

OUTPUT: The file structure should now look something like below (except parameters folder, that is deprecated, should not be visible): 

![](../../../../../documentation/v2/20-29/images/24-end-2-end-setup-repo-GH-byorepo.png)

## Continue with steps:6-10:

6) Authenticate to Github CLI, with a user that is Administrator (Can create Environments, variables, secrets, Github Action workflows)
   ```sh
    gh auth login
   ```

### Service Principal Setup
The service principal (e.g., `esml-common-bicep-sp`) needs proper Azure permissions:
- Must have **Owner** role on the subscription (not "User Access Administrator" with conditions)
- RBAC conditions may block deployments — assign role **without conditions**

<!--
5) Authenticate to  Azure and Github
You need to login via `Azure CLI` and `Github CLI`, but recommendation is to also test login via `Powershell`. 
- NB! Recommendation is to use a service principal when logging in, such as `esml-commmon-bicep-sp`, see your ``. You may also use your user id (for Github this is the usual case).
- The Service Principal should have OWNER permission to all 3 subscriptions (Dev, Test, Prod), such as the `esml-common-bicep-sp` service principal.
- Test the login for all 3 subscriptions using `az cli` and `powershell` as below: 

   a) Log in to `Azure CLI with a service principal`, to a specific tenant

   ```sh
    # Define the variables
    clientId="your-client-id"
    clientSecret="your-client-secret"
    tenantId="your-tenant-id"
    subscriptionId="your-subscription-id"
    
    az login --service-principal -u $clientId -p $clientSecret --tenant $tenantId
    az account set --subscription $subscriptionId
   ```

-->

<!--7) Edit the [base parameters](../../../../aifactory/parameters/). All files 12 files such as [10-esml-globals-1.json](../../../../aifactory/parameters/10-esml-globals-1.json) -->
7) Edit the [.env] variables at your root.
    - Choose naming convention: prefix, suffixes
    - Choose which services to enable or disable
    - BYOVNet, BYOSubnet, BYOAce, enableAIGateway
    - GITHUB_NEW_REPO: Use format `owner/repo-name` (not just repo name)
    - etc
    - **Replace `<todo>` placeholders**: The `.env.template` file contains `<todo>` placeholders that must be replaced with actual values
        - `<todo>` means **mandatory** and must be replaced
        - Examples: `GITHUB_USERNAME`, `TENANT_ID`, `DEV_SUBSCRIPTION_ID`, `AIFACTORY_SEEDING_KEYVAULT_NAME`
        - Validation: Before running step 8, search your `.env` file for `<todo>` - there should be **zero** matches

8) Run the file created at your root called: `10-GH-create-or-update-github-variables.sh`, that will copy values from .env to your Github repo as Environment variables, and secrets.
    - NB! The below will use Github CLI (gh), if the command does not work, please see PREREQUISITES.
    ```
   bash ./10-GH-create-or-update-github-variables.sh
    ```

    - Select `y`in the prompt `Do you want to use overwrite AZURE_CREDENTIALS with dummy value?` the first time you run the script.
    - Then, set the AZURE_CREDENTIALS manually using Github web portal for each Environment. The format should be: 
        ```json
        {
            "clientId": "<AppId of service principal that is OWNER, such as esml-common-bicep-sp>",
            "clientSecret": "Secret of service principal that is OWNER, such as esml-common-bicep-sp",
            "subscriptionId": "<subscriptionID>",
            "tenantId": "<TenantId>"
        }
        ```

    - OUTPUT: The environment in Github should now look something like below (~21 variables in each environment: Dev,Stage, Prod), though the exact count varies based on which services are enabled and optional fields populated.
    - ![](../../../../../documentation/v2/20-29/images/24-end-2-end-setup-repo-GH-env-vars.png)

9) Run the Github action workflows for `infra-common.yml`
10) Set the variable in your .env file called `aifactory_salt` if deploying projects

This is optional for common infrastructure only, but required if running step 11 (project deployments). The `aifactory_salt` is a 5-character deterministic salt from your common deployment that ensures unique resource naming across projects.

```
# Extract from your common resource group (5 characters exactly, alphanumeric)
# The aifactory_salt can be read from common resource group names such as Azure Datafactory
# Example: the 'a4c2b' in "adf-cmn-weu-dev-a4c2b-001" or in Container registry: "pend-kv-cmndev-a4c2b-001-to-vnt-esmlcmn"
# Set AIFACTORY_SALT in your .env file with this 5-character value
```

Then run the script to update GitHub variables:

    bash ./10-GH-create-or-update-github-variables.sh

For more details on all available variables and their purposes, see the comments section in `variables.yaml`.

Proceed to step 11 to deploy projects.

11) Run the workflow `infra-project.yml`

## Workflow: AIFactory Common 
Start with setting up a common AIFactory environment, example, the DEV environment
- [infra-common.yml](./infra-common.yml)

## Workflow: AIFactory projects
Then you can import and run the pipelines to setup 1-M projects. There are 2 AIFactory project types supported as of now: 
- [infra-project.yml](./infra-project.yml)

### Manual inputs and subnet authentication

For an ordinary manual run, select the target `environment` and leave
`deployment_id`, `project_number`, and `config_hash` empty. GitHub accepts these
optional empty strings; no Azure DevOps-style `manual` sentinel is needed.
`config_file` still defaults to `aifactory/variables.json`. Clear it to use only
the existing GitHub Environment variables/secrets without a JSON override; the
reusable phase workflow also accepts an empty configuration path. Custom runner
labels may remain empty to retain the existing runner defaults.

Reviewed deployments require the complete UUID/project/hash contract,
`aifactory/.reviewed-project-config.json`, and the run-specific protected
configuration secret. Partial reviewed inputs, missing secrets, changed hashes,
and mismatched target identities fail preflight rather than selecting legacy
mode. JSON-first identity selection is a separate mode: do not combine
`json_identity_auth: true` with reviewed deployment inputs.

The subnet PowerShell step uses the Azure CLI context established by
`azure/login@v2`, with an explicit target subscription. It does not enable an Az
PowerShell login session or load Az.Accounts/Az.Network for subnet reads. The
current allocator performs subnet arithmetic without PowerShell gallery modules.
Update the submodule and re-copy **both** `infra-project.yml` and
`infra-project-phase.yml` into the consumer's `.github/workflows` directory;
updating the submodule alone does not update existing workflow copies.

## Canonical JSON configuration

`infra-project.yml` loads the canonical
`aifactory/variables.json` file by
default. It contains one `dev` object sourced from the Azure DevOps
`variables.yaml` defaults. The object is the shared baseline for Dev, Stage,
and Prod; add an optional `stage_prod` object only when Stage/Prod need
different non-secret values.

Do not store credentials, service-connection settings, or GitHub secrets in
these files. GitHub Environments continue to provide the deployment identity
and secrets; JSON is for non-secret AI Factory deployment configuration.

When running with JSON-first identity selection, set
`json_identity_auth: true` and leave `config_secret` empty. The checked-out
`variables.json` must contain `AZURE_CLIENT_ID`, `tenantId`, and the exact
Dev/Stage/Prod subscription IDs. The workflow logs in as **Azure login with
OpenID Connect (OIDC)** using those JSON selectors and GitHub's short-lived
OIDC token; it does not use GitHub Environment variables or Azure credential
secrets for target identity selection.

For common infrastructure, run `infra-common.yml` with
`use_json_config_override: true` and `config_file` set to the checked-in
`variables.json`. Each scale set needs its own user-assigned managed identity,
an OIDC federated credential for the `dev`, `stage`, and `prod` GitHub
Environments, and the required scoped roles across that scale set's three
subscriptions. Concurrent workflows can then share one GitHub repository
without sharing a target subscription or deployment identity.

The dashboard link keeps its configuration key `aifactory-dash-01` in JSON.
The override reader explicitly maps it to the shell-safe runtime variable
`AIFACTORY_DASHBOARD_URL` for GitHub Actions and Azure DevOps. Empty values and
URL fragments are preserved. Other invalid variable names are still rejected;
conflicting values supplied under both names fail instead of overwriting one.


> [!TIP]
>  A quicker & easier way? You can use the AIFactory Github Template repository to get a bootstrapped repo quickly (as a mirror repo, or "bring your own repo"). [AIFactory Template Repo](https://github.com/jostrm/azure-enterprise-scale-ml-usage), ready to run. All files copied already. Just configure and run.
>