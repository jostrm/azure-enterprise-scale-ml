@description('Specifies the name of the NSG, network security group')
param name string

@description('Specifies the location where the  network security group should be deployed. Defaults to resourceGroup.location')
param location string

@description('Specifies the tags that should be applied to the network security group')
param tags object

//@description('To lock INBOUND rule to only allow RDP anbd SSH ports from Azure Bastion  via private IP')
//param bastionIpRange string

resource genAINsg 'Microsoft.Network/networkSecurityGroups@2020-06-01' = {
  name: name
  location: location
  tags: tags
  properties: {
    securityRules: [
      // --- Inbound ---
      {
        name: 'Allow_Internet_443'
        properties: {
          description: 'External clients to APIM gateway (External VNet mode). Required for public callers to reach APIM on 443.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: 'Internet'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 1000
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'Allow_AzureLB_HealthProbe'
        properties: {
          description: 'APIM internal load balancer health probe (required for External/Internal VNet APIM).'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '6390'
          sourceAddressPrefix: 'AzureLoadBalancer'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 1020
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'Allow_APIM_Management'
        properties: {
          description: 'APIM control-plane traffic from ApiManagement service tag on port 3443 (required for External/Internal VNet APIM).'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '3443'
          sourceAddressPrefix: 'ApiManagement'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 1030
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      { //!
        name: 'AML_CI_44224'
        properties: {
          description: 'Required for Azure Machine Learning'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '44224'
          sourceAddressPrefix: 'AzureMachineLearning'
          destinationAddressPrefix: '*'
          access: 'Allow'
          priority: 1050
          direction: 'Inbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      { //!
        name: 'AML_Port_29876-29877'
        properties: {
            description: 'Required for Azure Machine Learning batch compute nodes'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRange: '29876-29877'
            sourceAddressPrefix: 'BatchNodeManagement'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 1040
            direction: 'Inbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
        }
      }
      /*
      {
        name: 'Bastion_GetSessionInformation'
        properties: {
            description: 'Bastion will reach to the VM (DSVM / jump server) over private IP. RDP/SSH ports 3389/22. NB! Change the IP range if not working'
            protocol: '*'
            sourcePortRange: '*'
            sourceAddressPrefix: bastionIpRange
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 1300
            direction: 'Inbound'
            sourcePortRanges: []
            destinationPortRanges: [
              '22'
              '3389'
            ]
            sourceAddressPrefixes: []
            destinationAddressPrefixes: []
        }
      }
        */
      // --- Outbound --- 
      {
        name: 'AzureDevOps_Allow_1'
        properties: {
            description: 'Required for communication to Azure Devops. Needed to checkin code'
            protocol: '*'
            sourcePortRange: '*'
            destinationPortRange: '*'
            sourceAddressPrefix: '*'
            access: 'Allow'
            priority: 100
            direction: 'Outbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: [
              '13.107.6.0/24'
              '13.107.9.0/24'
              '13.107.42.0/24'
              '13.107.43.0/24'
            ]
        }
      }
      {
        name: 'AADLoginForWindows_Allow3services'
        properties: {
            description: 'To enable Azure AD authentication for Windows VMs.'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRange: '443'
            sourceAddressPrefix: '*'
            destinationAddressPrefix: '*'
            access: 'Allow'
            priority: 110
            direction: 'Outbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: [] // https://enterpriseregistration.windows.net - For device registration. http://169.254.169.254 - Azure Instance Metadata Service endpoint. 
            // https://login.microsoftonline.com - For authentication flows.  https://pas.windows.net - For Azure RBAC flows.
        }
      }
      {
        name: 'AADLoginForWindows_AllowServiceMeta'
        properties: {
            description: 'To enable Azure AD authentication for Windows VMs.'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRange: '80'
            sourceAddressPrefix: '*'
            destinationAddressPrefix: '169.254.169.254'
            access: 'Allow'
            priority: 120
            direction: 'Outbound'
            sourcePortRanges: []
            destinationPortRanges: []
            sourceAddressPrefixes: []
            destinationAddressPrefixes: [] // https://enterpriseregistration.windows.net - For device registration. http://169.254.169.254 - Azure Instance Metadata Service endpoint. 
            // https://login.microsoftonline.com - For authentication flows.  https://pas.windows.net - For Azure RBAC flows.
        }
      }
      {// !! 
        name: 'AzureActiveDirectory'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureActiveDirectory'
          access: 'Allow'
          priority: 130
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'AzureMachineLearningOutbound'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureMachineLearning'
          access: 'Allow'
          priority: 140
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'AzureResourceManager'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureResourceManager'
          access: 'Allow'
          priority: 150
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'AzureStorageAccount'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'Storage.${location}'
          access: 'Allow'
          priority: 160
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'AzureFrontDoor'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureFrontDoor.FrontEnd'
          access: 'Allow'
          priority: 170
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'AzureContainerRegistry'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureContainerRegistry.${location}'
          access: 'Allow'
          priority: 180
          direction: 'Outbound'
        }
      }
      {// !!
        name: 'MicrosoftContainerRegistry'
        properties: {
          description: 'AML !!'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'MicrosoftContainerRegistry'
          access: 'Allow'
          priority: 200
          direction: 'Outbound'
        }
      }
      {
        name: 'AKS_private_loadbalancer_call_from_DSVM_in_vNet'
        properties: {
            description: 'Required for communication from private DSVM to call private AKS cluster endpoints. Needed for Azure ML inferencing.'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRange: '80'
            sourceAddressPrefix: 'VirtualNetwork'
            access: 'Allow'
            priority: 220
            direction: 'Outbound'
            destinationAddressPrefix: 'VirtualNetwork'
        }
      }
      {
        name: 'AzureMachineLearning_2023_sdkv2_1'
        properties: {
            description: 'Required for 2023 Mars update, to support Azure ML SDK v2'
            protocol: 'Udp'
            sourcePortRange: '*'
            destinationPortRange: '5831'
            sourceAddressPrefix: '*'
            access: 'Allow'
            priority: 230
            direction: 'Outbound'
            destinationAddressPrefix: 'AzureMachineLearning'
        }
      }
      {
        name: 'AzureMachineLearning_2023_sdkv2_2'
        properties: {
            description: 'Required for 2023 Mars update, to support Azure ML SDK v2'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRange: '5831'
            sourceAddressPrefix: '*'
            access: 'Allow'
            priority: 1320
            direction: 'Outbound'
            destinationAddressPrefix: 'BatchNodeManagement.${location}'
        }
      }
      {
        name: 'AzureMachineLearning_2023_sdkv2_3'
        properties: {
            description: 'Required for 2023 Mars update, to support Azure ML SDK v2'
            protocol: 'Tcp'
            sourcePortRange: '*'
            destinationPortRanges: [
              '8787'
              '18881'
            ]
            sourceAddressPrefix: '*'
            access: 'Allow'
            priority: 250
            direction: 'Outbound'
            destinationAddressPrefix: 'AzureMachineLearning'
        }
      }
      // --- UDR / Azure Firewall: explicit outbound rules to avoid NSG blocking when traffic is routed via UDR ---
      {
        name: 'AzureCosmosDB_Outbound'
        properties: {
          description: 'Required when UDR routes through Azure Firewall. Allows outbound to Azure Cosmos DB service tag.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureCosmosDB'
          access: 'Allow'
          priority: 260
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'AzureCognitiveSearch_Outbound'
        properties: {
          description: 'Required when UDR routes through Azure Firewall. Allows outbound to Azure AI Search (Cognitive Search) service tag.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureCognitiveSearch'
          access: 'Allow'
          priority: 270
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'AzureMonitor_Outbound'
        properties: {
          description: 'UDR/Firewall: Allow outbound to Azure Monitor (Log Analytics, Application Insights, diagnostics).'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'AzureMonitor'
          access: 'Allow'
          priority: 280
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'PowerBI_Fabric_Outbound'
        properties: {
          description: 'UDR/Firewall: Allow outbound to Microsoft Fabric / Power BI (REST API, OneLake, Data Agent).'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'PowerBI'
          access: 'Allow'
          priority: 290
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
      {
        name: 'CognitiveServicesManagement_Outbound'
        properties: {
          description: 'UDR/Firewall: Allow outbound to Cognitive Services mgmt (AI Foundry, OpenAI, Speech, Vision, Doc Intel).'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: 'CognitiveServicesManagement'
          access: 'Allow'
          priority: 300
          direction: 'Outbound'
          sourcePortRanges: []
          destinationPortRanges: []
          sourceAddressPrefixes: []
          destinationAddressPrefixes: []
        }
      }
    ]
  }
}

output nsgId string = genAINsg.id
