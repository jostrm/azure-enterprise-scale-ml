targetScope = 'subscription'  // Just to avoid sending a static RG. Instead: ESML dynamic via naming convention and parameters
@allowed([
  'dev'
  'test'
  'prod'
])
@description('Specifies the name of the environment. This name is reflected in resource group and sub-resources')
param env string
@description('Specifies the short location notation. This name is reflected in resource group and sub-resources')
param locationSuffix string
param commonResourceSuffix string
@description('Deployment location')
param location string
@description('tags')
param tags object
@description('AI Factory suffix. If you have multiple instances')
param aifactorySuffixRG string =''
@description('Specifies the virtual network name')
param vnetNameBase string
@description('CIDR for common vNet ')
param common_vnet_cidr string
param common_pbi_subnet_name string = 'snt-common-pbi-gw'
@description('CIDR for common Power BI subnet for gateway')
param common_pbi_subnet_cidr string
@description('common subnet')
param common_subnet_name string
@description('CIDR for common subnet')
param common_subnet_cidr string
@description('common Bastion host subnet for RDP access over private IP. Must remain AzureBastionSubnet per platform requirements')
@allowed([
  'AzureBastionSubnet'
])
param common_bastion_subnet_name string = 'AzureBastionSubnet'
@description('common Bastion host subnet CIDR')
param common_bastion_subnet_cidr string
@description('common scoring subnet CIDR')
param common_subnet_scoring_cidr string
@description('CIDR range. xx.YY.x.x/16')
param cidr_range string
@description('Resource group prefix. If "rg-msft-word" then "rg-msft-word-{commonResourceName}-weu-dev-001"')
param commonRGNamePrefix string = ''
@description('Optional:Whitelist IP addresses from project members to see keyvault, and to connect via Bastion')
param IPwhiteList string = ''
@description('ESML can run standalone/demo mode, this is deafault mode, meaning default FALSE value, which creates private DnsZones,DnsZoneGroups, and vNetLinks. You can change this, to use your HUB DnzZones instead.')
param centralDnsZoneByPolicyInHub bool = false // DONE: jå
param vnetResourceGroup_param string = ''
param vnetNameFull_param string = ''
param commonResourceGroup_param string = ''
param datalakeName_param string = ''
param kvNameFromCOMMON_param string = ''
param useCommonACR bool = true
param BYO_subnets bool = false
param network_env string =''
param subnetCommon string = ''
param subnetCommonScoring string = ''
param subnetCommonPowerbiGw string = ''
param subnetProjGenAI string = ''
param subnetProjAKS string = ''
param subnetProjDatabricksPublic string = ''
param subnetProjDatabricksPrivate string = ''
param subnetProjACA string = ''
param DOCS_byovnet_example string = ''
param DOCS_byosnet_common_example string = ''
param DOCS_byosnet_project_example string = ''
param deployAIGatewayNetworking bool = false // If true, deploys the AI Gateway networking also
param deployOnlyAIGatewayNetworking bool = false
param ai_gateway_apim_cidr string = ''
param ai_gateway_app_cidr string = ''
param byoASEv3 bool = false
param byoAseFullResourceId string = ''
param byoAseAppServicePlanResourceId string = ''
@description('Common resource name identifier. Default is "esml-common"')
param commonResourceName string = 'esml-common'
@allowed(['legacy', 'preserve-v1'])
@description('preserve-v1 requires the reviewed common_network_preservation helper, a fresh complete inventory and the shared hub lease. Legacy deployments are unchanged.')
param commonNetworkProfile string = 'legacy'
@description('Add-only plan produced by common_network_preservation.plan_common_network; never reuse a stale plan.')
param preservationPlan object = {
  createVnet: false
  addressPrefixes: []
  createSubnets: []
  createNetworkSecurityGroups: []
}

var subscriptionIdDevTestProd = subscription().subscriptionId
var common_vnet_cidr_v = replace(common_vnet_cidr,'XX',cidr_range)
var common_subnet_cidr_v = replace(common_subnet_cidr,'XX',cidr_range)
var common_pbi_subnet_cidr_v = replace(common_pbi_subnet_cidr,'XX',cidr_range)
var common_bastion_subnet_cidr_v = replace(common_bastion_subnet_cidr,'XX',cidr_range)
var common_subnet_scoring_cidr_v = replace(common_subnet_scoring_cidr,'XX',cidr_range)
var ai_gateway_apim_cidr_v = deployAIGatewayNetworking? replace(ai_gateway_apim_cidr,'XX',cidr_range): ''
var ai_gateway_app_cidr_v = deployAIGatewayNetworking? replace(ai_gateway_app_cidr,'XX',cidr_range):''

var commonResourceGroupName = '${commonRGNamePrefix}${commonResourceName}-${locationSuffix}-${env}${aifactorySuffixRG}' // {commonResourceName}-weu-dev-002 // DEPENDENCIES - should exist

var vnetResourceGroupName = !empty(vnetResourceGroup_param) ? replace(vnetResourceGroup_param, '<network_env>', network_env) : commonResourceGroupName
var vnetNameFull = !empty(vnetNameFull_param) ? vnetNameFull_param : '${vnetNameBase}-${locationSuffix}-${env}${commonResourceSuffix}'  // {vnetNameBase}-weu-dev-001 @

var vNetRGsalt = substring(uniqueString(vnetResourceGroup.id), 0, 5)
var commmonRGsalt = substring(uniqueString(commonResourceGroupName), 0, 5)
var uniqueDetermenistic = '${commmonRGsalt}${vNetRGsalt}'

resource vnetResourceGroup 'Microsoft.Resources/resourceGroups@2020-10-01' existing = {
  name: vnetResourceGroupName
  scope:subscription(subscriptionIdDevTestProd)
}

module nsgCommon '../modules-common/nsgCommon.bicep' = if (commonNetworkProfile == 'legacy' || contains(preservationPlan.createNetworkSecurityGroups, 'nsg-${common_subnet_name}')) {
  name: 'nsg-${common_subnet_name}-depl${uniqueDetermenistic}'
  scope: vnetResourceGroup
  params: {
    name: 'nsg-${common_subnet_name}'
    enableFlowLogs: commonNetworkProfile == 'legacy'
    tags: tags
    location:location
    bastionIpRange: common_bastion_subnet_cidr_v
  }
}

module nsgCommonScoring '../modules-common/nsgCommonScoring.bicep' = if (commonNetworkProfile == 'legacy' || contains(preservationPlan.createNetworkSecurityGroups, 'nsg-${common_subnet_name}-scoring')) {
  name: 'nsg-${common_subnet_name}-scoring-depl${uniqueDetermenistic}'
  scope: vnetResourceGroup
  params: {
    name: 'nsg-${common_subnet_name}-scoring'
    enableFlowLogs: commonNetworkProfile == 'legacy'
    tags: tags
    location:location
    bastionIpRange: common_bastion_subnet_cidr_v
  }
  dependsOn:[
    nsgCommon
  ]
}

var ipWhitelist_array_1 = array(split(replace(IPwhiteList, '\\s+', ''), ','))
var ipWhitelist_array = (empty(IPwhiteList) || IPwhiteList == 'null' || length(IPwhiteList) < 5) ? [] : union(ipWhitelist_array_1,[]) // remove dups

module nsgBastion '../modules-common/nsgBastion.bicep' = if(!empty(ipWhitelist_array) && (commonNetworkProfile == 'legacy' || contains(preservationPlan.createNetworkSecurityGroups, 'nsg-${common_bastion_subnet_name}'))){
  name: 'nsg-${common_bastion_subnet_name}-depl${uniqueDetermenistic}'
  scope: vnetResourceGroup
  params: {
    name: 'nsg-${common_bastion_subnet_name}'
    enableFlowLogs: commonNetworkProfile == 'legacy'
    tags: tags
    location:location
    IPwhiteList_Array: ipWhitelist_array
  }
  dependsOn:[
    nsgCommonScoring
  ]
}
module nsgBastionNoWhitelist '../modules-common/nsgBastionNoWhitelist.bicep' = if(empty(ipWhitelist_array) && (commonNetworkProfile == 'legacy' || contains(preservationPlan.createNetworkSecurityGroups, 'nsg-${common_bastion_subnet_name}'))){
  name: 'nsg-${common_bastion_subnet_name}-NoWLdepl${uniqueDetermenistic}'
  scope: vnetResourceGroup
  params: {
    name: 'nsg-${common_bastion_subnet_name}'
    enableFlowLogs: commonNetworkProfile == 'legacy'
    tags: tags
    location:location
    IPwhiteList_Array: ipWhitelist_array
  }
  dependsOn:[
    nsgCommonScoring
  ]
}

module nsgPBI  '../modules-common/nsgPowerBI.bicep'= if (commonNetworkProfile == 'legacy' || contains(preservationPlan.createNetworkSecurityGroups, 'nsg-${common_pbi_subnet_name}')) {
  scope: vnetResourceGroup
  name: 'nsg-${common_pbi_subnet_name}-depl${uniqueDetermenistic}'
  params: {
    name: 'nsg-${common_pbi_subnet_name}'
    enableFlowLogs: commonNetworkProfile == 'legacy'
    tags: tags
    location:location
  }
  // Make sure the PBI NSG waits for whichever bastion NSG path is active
  dependsOn: !empty(ipWhitelist_array)
    ? [ nsgBastion ]
    : [ nsgBastionNoWhitelist ]
}
var byoVnet = !empty(vnetNameFull_param)
module vNetCommon '../modules-common/vNetCommon.bicep' = if(commonNetworkProfile == 'legacy' && !BYO_subnets) {
  scope: vnetResourceGroup
  name: '${vnetNameFull}depl${uniqueDetermenistic}'
  params: {
    location: location
    common_pbi_subnet_cidr: common_pbi_subnet_cidr_v
    common_pbi_subnet_name: common_pbi_subnet_name
    common_subnet_cidr: common_subnet_cidr_v
    common_subnet_scoring_cidr:common_subnet_scoring_cidr_v
    common_subnet_name: common_subnet_name
    common_vnet_cidr: common_vnet_cidr_v
    common_bastion_subnet_name: common_bastion_subnet_name
    common_bastion_subnet_cidr: common_bastion_subnet_cidr_v
    tags: tags
    vnetNameFull: vnetNameFull
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
    deployOnlyAIGatewayNetworking:deployOnlyAIGatewayNetworking
    byoSubnet: BYO_subnets
    byoVnet: byoVnet
  }
  dependsOn: [
    nsgCommon
    nsgBastion
    nsgPBI
    nsgCommonScoring
  ]
}

module vNetCommonPreserve '../modules-common/vNetCommonPreserve.bicep' = if (commonNetworkProfile == 'preserve-v1') {
  scope: vnetResourceGroup
  name: '${vnetNameFull}-preserve-${uniqueDetermenistic}'
  params: {
    location: location
    tags: tags
    vnetNameFull: vnetNameFull
    plan: preservationPlan
  }
  dependsOn: [
    nsgCommon
    nsgCommonScoring
    nsgBastion
    nsgBastionNoWhitelist
    nsgPBI
  ]
}

//var aiGwNetworkingName = 'ai-gateway-${locationSuffix}-${env}-${commonResourceSuffix}'
var aiGwNetworkingName = 'ai-gateway'
module aiGatewayNetworking '../ai-gateway/14-add-networking-aigw.bicep' = if(commonNetworkProfile == 'legacy' && deployAIGatewayNetworking){
  name: 'ai-gateway-networking-${uniqueDetermenistic}'
  scope: vnetResourceGroup
  params: {
    name: aiGwNetworkingName
    location: location
    tags: tags
    aifactorySuffixRG: aifactorySuffixRG
    commonResourceSuffix: commonResourceSuffix
    commonRGNamePrefix: commonRGNamePrefix
    env: env
    locationSuffix: locationSuffix
    subscriptionIdDevTestProd: subscriptionIdDevTestProd
    vnetName: vnetNameFull
    vnetNameBase: vnetNameBase
    network_env: network_env
    vnetNameFull_param: vnetNameFull_param
    vnetResourceGroup_param: vnetResourceGroup_param
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
    CIDRApim: ai_gateway_apim_cidr_v
    CIDRFunctionApp: ai_gateway_app_cidr_v  
  }
  dependsOn: empty(vnetNameFull_param) ? [
    vNetCommon
  ] : []
}
