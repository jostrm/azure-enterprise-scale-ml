@description('Specifies the objectId of the person that ordered the resources')
param userId string =''

@description('Specifies the email address of the person that ordered the resources')
param userEmail string
param useAdGroups bool = false
@description('Contributor role ID for RBAC assignments. Default is the built-in Contributor role.')
param contributorRoleId string = 'b24988ac-6180-42a0-ab88-20f7382dd24c'

@description('This is the built-in Contributor role. See https://docs.microsoft.com/azure/role-based-access-control/built-in-roles#contributor')
resource contributorRoleDefinition 'Microsoft.Authorization/roleDefinitions@2018-01-01-preview' existing = {
  scope: subscription()
  name: contributorRoleId
}

@description('Additional optional Object ID of more people to access Resource group')
param additionalUserIds array
@description('Additional optional email adress of more people to access the Resource group')
param additionalUserEmails array

var main_principal_2_array = array(userId)
//var all_principals = union(main_principal_2_array,additionalUserIds)

var main_email_2_array = array(userEmail)
var all_emails = union(main_email_2_array,additionalUserEmails)

resource contributorRole2userOrGroup 'Microsoft.Authorization/roleAssignments@2020-04-01-preview' = [for i in range(0, length(additionalUserIds)):if(!empty(additionalUserIds)){
  name: guid('${additionalUserIds[i]}-contributor-${resourceGroup().id}')
  properties: {
    roleDefinitionId: contributorRoleDefinition.id
    principalId: additionalUserIds[i]
    principalType:useAdGroups? 'Group':'User'
    // Fewer emails than object IDs is allowed: name the object ID instead of failing with an index out of bounds.
    description: 'Contributor to user ${i < length(additionalUserEmails) ? additionalUserEmails[i] : additionalUserIds[i]} to get Contributor on resource group: ${resourceGroup().name}'
  }
}]

resource contributorRole2user 'Microsoft.Authorization/roleAssignments@2020-04-01-preview' = [for i in range(0, length(main_principal_2_array)): if(useAdGroups==false && !empty(userId)){
  name: guid('${main_principal_2_array[i]}-contributor-${resourceGroup().id}')
  properties: {
    roleDefinitionId: contributorRoleDefinition.id
    principalId: main_principal_2_array[i]
    principalType:useAdGroups? 'Group':'User'
    description: 'Contributor to user ${main_email_2_array[i]} to get Contributor on resource group: ${resourceGroup().name}'
  }
}]

