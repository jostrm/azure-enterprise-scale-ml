param privDnsSubscription string
param privDnsResourceGroup string
param vNetName string
param vNetResourceGroup string
param location string
param allGlobal bool = true
param privateLinksDnsZones array

var locationGlobal = 'global' // Using default Microsoft Private DNS, they are registered in global. (you can change this, but need to register, see ref01)

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vNetName
  scope: resourceGroup(vNetResourceGroup)
}

resource privateDnsZones 'Microsoft.Network/privateDnsZones@2024-06-01' = [for (zone, index) in privateLinksDnsZones: if(zone.exists == false) {
  name: zone.name
  location: (zone.name == '${location}.data.privatelink.azurecr.io' && allGlobal == false) ? location : locationGlobal
  properties: {}
}]

// A project-only upgrade can reuse a common zone but still need its VNet link.
resource privateDnsZoneVnetLink 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2024-06-01' = [for (zone, index) in privateLinksDnsZones: if(zone.exists == false || (zone.?ensureLink ?? false)) {
  dependsOn: [
    privateDnsZones[index]
  ]
  // IMPORTANT: Use the same deterministic link-name strategy as createPrivateDnsZones.bicep.
  // If different deployments use different link names for the same zone+VNet, Azure will throw:
  // "Private zone '...' is already linked to the virtual network '...'."
  name: '${zone.name}/${uniqueString(resourceId('Microsoft.Network/privateDnsZones', zone.name))}'
  location: (zone.name == '${location}.data.privatelink.azurecr.io' && allGlobal == false) ? location : locationGlobal
  properties: {
    registrationEnabled: false // Is auto-registration of virtual machine records in the virtual network in the Private DNS zone enabled?
    resolutionPolicy: 'NxDomainRedirect' // The resolution policy for the private DNS zone. Possible values include: 'Default', 'NxDomainRedirect'
    virtualNetwork: {
      id: vnet.id
    }
  }
}]
