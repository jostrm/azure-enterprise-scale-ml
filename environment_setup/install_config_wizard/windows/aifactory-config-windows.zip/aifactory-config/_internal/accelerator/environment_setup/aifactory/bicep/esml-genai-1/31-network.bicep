@description('Specifies cidr notation for genai subnet')
param genaiSubnetCidr string
@description('Specifies cidr notation for aks subnet')
param aksSubnetCidr string
param aks2SubnetCidr string = ''
@description('Optional. Resource ID of the route table for AKS2 subnet. Used for User Defined Routing (UDR) with private AKS.')
param aks2RouteTableId string = ''
@description('Specifies the outbound (egress) routing method for AKS2 cluster')
@allowed([
  'loadBalancer'
  'userDefinedRouting'
])
param aksOutboundType string = 'loadBalancer'
@description('Optional. Azure Firewall private IP address for default route when using userDefinedRouting. Required if aksOutboundType is userDefinedRouting and aks2RouteTableId is empty.')
param azureFirewallPrivateIp string = ''
@description('Specifies cidr notation for Azure Container Apps subnet')
param acaSubnetCidr string = ''
param aca2SubnetCidr string = ''
@description('Specifies cidr notation for the dedicated App Service / Function VNet integration subnet (delegated to Microsoft.Web/serverFarms)')
param webappSubnetCidr string = ''
@description('Dedicated Logic Apps Standard outbound subnet CIDR; managed allocation uses /26.')
param logicappSubnetCidr string = ''
param enableLogicApps bool = false
@allowed(['Standard', 'Consumption'])
param logicAppType string = 'Standard'
param enablePublicAccessWithPerimeter bool = false
@description('Specifies cidr notation for databricks subnets')
param dbxPrivSubnetCidr string = ''
param dbxPubSubnetCidr string = ''

@allowed([
  'dev'
  'test'
  'prod'
])
@description('Specifies the name of the environment [dev,test,prod]. This name is reflected in resource group and sub-resources')
param env string
@description('Specifies the short location notation, such as "weu". This name is reflected in resource group and sub-resources')
param locationSuffix string
@description('Specifies virtual network name')
param vnetNameBase string
@description('Specifies the project number, such as a string "005". This is used to generate the projectName to embed in resources such as "prj005"')
param projectNumber string
var projectName = 'prj${projectNumber}'
@description('Deployment location')
param location string
param commonResourceSuffix string
@description('Meta. Needed from ADO. To be grep from ADO in the az deployement call')
param vnetResourceGroup string 
@description('If BYO vNet is overriden, in parameter file: 10-esml-globals-override.json')
param vnetResourceGroup_param string = ''
@description('If BYO vNet is overriden, in parameter file: 10-esml-globals-override.json')
param vnetNameFull_param string = ''
@description('If Common resource group name is overriden, in parameter file: 10-esml-globals-override.json')
param commonResourceGroup_param string = ''
param datalakeName_param string = ''
param kvNameFromCOMMON_param string = ''
param useCommonACR bool = true
param BYO_subnets bool = false
param network_env string =''
param subnetCommon string = ''
param subnetCommonScoring string = ''
param subnetCommonPowerbiGw string = ''
param subnetProjGenAI string = ''
param subnetProjAKS string = ''
param subnetProjAKS2 string = ''
param subnetProjDatabricksPublic string = ''
param subnetProjDatabricksPrivate string = ''
param subnetProjACA string = ''
param subnetProjACA2 string = ''
param subnetProjWebapp string = ''
param subnetProjLogicapp string = ''

// Subnet existence flags
@description('Specifies whether GenAI subnet already exists')
param sntGenaiExists bool = false
@description('Specifies whether ACA subnet already exists')
param sntAcaExists bool = false
@description('Specifies whether ACA002 subnet already exists')
param sntAca002Exists bool = false
@description('Specifies whether the dedicated App Service / Function VNet integration subnet already exists')
param sntWebappExists bool = false
param sntLogicappExists bool = false
@description('Specifies whether AKS subnet already exists')
param sntAksExists bool = false
@description('Specifies whether AKS002 subnet already exists')
param sntAks002Exists bool = false
@description('Specifies whether Databricks Private subnet already exists')
param sntDatabricksPrivExists bool = false
@description('Specifies whether Databricks Public subnet already exists')
param sntDatabricksPubExists bool = false

param DOCS_byovnet_example string = ''
param DOCS_byosnet_common_example string = ''
param DOCS_byosnet_project_example string = ''
param byoASEv3 bool = false
param byoAseFullResourceId string = ''
param byoAseAppServicePlanResourceId string = ''

// To get TAGS from file: 10-esml-globals-1.json
param tags object = {}
param aifactorySuffixRG string = '' // dummy
param commonRGNamePrefix string = '' // dummy

var vnetNameFull = !empty(vnetNameFull_param) ? vnetNameFull_param  : '${vnetNameBase}-${locationSuffix}-${env}${commonResourceSuffix}'
var vnetResourceGroupScope = !empty(vnetResourceGroup_param) ? vnetResourceGroup_param : vnetResourceGroup
var needsLogicAppSubnet = enableLogicApps && logicAppType == 'Standard' && !byoASEv3 && !enablePublicAccessWithPerimeter
var createLogicAppSubnet = needsLogicAppSubnet && !BYO_subnets && !sntLogicappExists && !empty(logicappSubnetCidr)
var logicappSubnetNameOrId = BYO_subnets ? replace(replace(subnetProjLogicapp, '<xxx>', projectNumber), '<network_env>', network_env) : 'snt-${projectName}-logicapp'

var vNetSalt = substring(uniqueString(resourceGroup().id), 0, 5)
var deploymentProjSpecificUniqueSuffix = '${projectName}${vNetSalt}${locationSuffix}-${env}${commonResourceSuffix}'

@description('ESML can run standalone/demo mode, this is deafault mode, meaning default FALSE value, which creates private DnsZones,DnsZoneGroups, and vNetLinks. You can change this, to use your HUB DnzZones instead.')
param centralDnsZoneByPolicyInHub bool = false 

var aksSubnetSettings =   {
  cidr: aksSubnetCidr
  name: 'aks'
  delegations: []
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
  ]
}
var aks2SubnetSettings =  {
  cidr: aks2SubnetCidr
  name: 'aks'
  delegations: []
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
  ]
}

// Create default route table for AKS2 if userDefinedRouting is used and no route table ID is provided
resource aks2DefaultRouteTable 'Microsoft.Network/routeTables@2023-05-01' = if (!empty(aks2SubnetCidr) && aksOutboundType == 'userDefinedRouting' && empty(aks2RouteTableId)) {
  name: 'rt-${projectName}-aks2-${locationSuffix}-${env}'
  location: location
  tags: tags
  properties: {
    routes: [
      {
        name: 'default-route-to-azfw'
        properties: {
          addressPrefix: '0.0.0.0/0'
          nextHopType: 'VirtualAppliance'
          nextHopIpAddress: azureFirewallPrivateIp
        }
      }
    ]
    disableBgpRoutePropagation: false
  }
}

// Determine which route table ID to use
var aks2RouteTableIdToUse = !empty(aks2RouteTableId) ? aks2RouteTableId : (aksOutboundType == 'userDefinedRouting' && !empty(aks2SubnetCidr) ? aks2DefaultRouteTable.id : '')

module nsgAKS '../modules/aksNsg.bicep' = if(!sntAksExists){
  name: take('aksNsgAKS-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'aks-nsg-${projectName}-${locationSuffix}-${env}' // AKS-NSG-PRJ001-EUS2-DEV in 'aks-nsg-prj001-eus2-dev'
    location: location
    tags:tags
  }
}
module nsgAKS2 '../modules/aksNsg.bicep' = if (!empty(aks2SubnetCidr) && !sntAks002Exists) {
  name: take('aks2Nsg-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'aks2-nsg-${projectName}-${locationSuffix}-${env}' // AKS-NSG-PRJ001-EUS2-DEV in 'aks-nsg-prj001-eus2-dev'
    location: location
    tags:tags
  }
}


module aksSnt '../modules/subnetWithNsg.bicep' = if(!sntAksExists){
  name: take('aks-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-aks'
    virtualNetworkName: vnetNameFull
    addressPrefix: aksSubnetSettings.cidr
    location: location
    serviceEndpoints: aksSubnetSettings.serviceEndpoints
    delegations: aksSubnetSettings.delegations
    nsgId: nsgAKS!.outputs.nsgId
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }
  dependsOn: [
    ...(!sntAksExists ? [nsgAKS] : [])
  ]
}
module aks2Snt '../modules/subnetWithNsg.bicep' = if (!empty(aks2SubnetCidr) && !sntAks002Exists) {
  name: take('aks2-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-aks-002'
    virtualNetworkName: vnetNameFull
    addressPrefix: aks2SubnetSettings.cidr
    location: location
    serviceEndpoints: aks2SubnetSettings.serviceEndpoints
    delegations: aks2SubnetSettings.delegations
    nsgId: !empty(aks2SubnetCidr) ? nsgAKS2!.outputs.nsgId : ''
    routeTableId: aks2RouteTableIdToUse // Use provided route table or auto-created one for UDR
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }
  dependsOn: [
    ...(!sntAks002Exists && !empty(aks2SubnetCidr) ? [nsgAKS2] : [])
    ...(!sntAcaExists ? [acaSnt] : [])
    ...(!sntGenaiExists ? [genaiSnt] : [])    
    ...(!sntAksExists ? [aksSnt] : [])
    ...(aksOutboundType == 'userDefinedRouting' && empty(aks2RouteTableId) && !empty(aks2SubnetCidr) ? [aks2DefaultRouteTable] : [])
  ]
}

// GenAI

var genaiSubnetSettings =   {
  cidr: genaiSubnetCidr
  name: 'genaiSubnetSettings'
  delegations: []
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
  ]
}

module nsgGenAI '../modules/nsgGenAI.bicep' = if(!sntGenaiExists){
  name: take('nsgGenAI-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'genai-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags:tags
  }
}

module genaiSnt '../modules/subnetWithNsg.bicep' = if(!sntGenaiExists){
  name: take('genai-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-genai'
    virtualNetworkName: vnetNameFull
    addressPrefix: genaiSubnetSettings.cidr
    location: location
    serviceEndpoints: genaiSubnetSettings.serviceEndpoints
    delegations: genaiSubnetSettings.delegations
    nsgId: nsgGenAI!.outputs.nsgId
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }
  dependsOn: [
    ...(!sntGenaiExists ? [nsgGenAI] : [])
    ...(!sntAksExists ? [aksSnt] : [])
  ]
}

// Azure Container Apps
var acaSubnetSettings =   {
  cidr: acaSubnetCidr
  name: 'acaSubnetSettings'
  delegations: []
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
    'Microsoft.ContainerRegistry'
    'Microsoft.AzureCosmosDB'
    'Microsoft.Web'
  ]
}
var aca2SubnetSettings =   {
  cidr: aca2SubnetCidr
  name: 'aca2SubnetSettings'
  // REQUIRED for AI Foundry agent network injection (auto-provisioned ACA env behind the agent service).
  // Set at subnet-creation time so task '69a-Validate-Subnet-For-NetworkInjection' in job-2 does not have
  // to mutate the subnet on the fly. The bicep 09-ai-foundry-2025-v4.bicep keeps a conditional
  // subnetDelegationAca safety-net (idempotent) for upgrade scenarios where this snt-...-aca-002 subnet
  // was created before this delegation was added.
  delegations: [
    'Microsoft.App/environments'
  ]
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
    'Microsoft.ContainerRegistry'
    'Microsoft.AzureCosmosDB'
    'Microsoft.Web'
  ]
}

module nsgAca '../modules/nsgGenAI.bicep' = if(!sntAcaExists){
  name: take('nsgAca-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'aca-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags:tags
  }
}
module nsg2Aca '../modules/nsgGenAI.bicep' = if (!empty(aca2SubnetCidr) && !sntAca002Exists) {
  name: take('nsgAca2-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'aca2-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags:tags
  }
}
module acaSnt '../modules/subnetWithNsg.bicep' = if(!sntAcaExists){
  name: take('acaSnet-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-aca'
    virtualNetworkName: vnetNameFull
    addressPrefix: acaSubnetSettings.cidr
    location: location
    serviceEndpoints: acaSubnetSettings.serviceEndpoints
    delegations: []
    nsgId: nsgAca!.outputs.nsgId
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }
  dependsOn: [
    ...(!sntAcaExists ? [nsgAca] : [])
    ...(!sntGenaiExists ? [genaiSnt] : [])
    ...(!sntAksExists ? [aksSnt] : [])
  ]
}
module acaSnt2 '../modules/subnetWithNsg.bicep' = if (!empty(aca2SubnetCidr) && !sntAca002Exists) {
  name: take('acaSnet2-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-aca-002'
    virtualNetworkName: vnetNameFull
    addressPrefix: aca2SubnetSettings.cidr
    location: location
    serviceEndpoints: aca2SubnetSettings.serviceEndpoints
    delegations: aca2SubnetSettings.delegations
    nsgId: !empty(aca2SubnetCidr) ? nsg2Aca!.outputs.nsgId : ''
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
    allowDefaultOutboundAccess: true
  }
  dependsOn: [
    ...(!sntAca002Exists && !empty(aca2SubnetCidr) ? [nsg2Aca] : [])
    ...(!sntAcaExists ? [acaSnt] : [])
    ...(!sntGenaiExists ? [genaiSnt] : [])
    ...(!sntAksExists ? [aksSnt] : [])
    ...(!sntAks002Exists && !empty(aks2SubnetCidr) ? [aks2Snt] : [])
  ]
}

// Dedicated App Service / Function VNet integration subnet.
// Regional VNet integration requires a subnet delegated to Microsoft.Web/serverFarms, and a subnet
// can hold only ONE delegation. Using a dedicated subnet (instead of borrowing the AKS or ACA subnet)
// avoids delegation collisions with AKS (no delegation) and Container Apps (Microsoft.App/environments).
// The delegation is baked in at subnet-creation time so step 65 (05-compute-services.bicep) does not
// have to mutate the subnet on the fly before App Service/Function VNet integration.
var webappSubnetSettings = {
  cidr: webappSubnetCidr
  name: 'webappSubnetSettings'
  delegations: [
    'Microsoft.Web/serverFarms'
  ]
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
    'Microsoft.CognitiveServices'
    'Microsoft.ContainerRegistry'
    'Microsoft.AzureCosmosDB'
    'Microsoft.Web'
  ]
}

module nsgWebapp '../modules/nsgGenAI.bicep' = if (!empty(webappSubnetCidr) && !sntWebappExists) {
  name: take('nsgWebapp-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'webapp-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags:tags
  }
}

module webappSnt '../modules/subnetWithNsg.bicep' = if (!empty(webappSubnetCidr) && !sntWebappExists) {
  name: take('webappSnet-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-webapp'
    virtualNetworkName: vnetNameFull
    addressPrefix: webappSubnetSettings.cidr
    location: location
    serviceEndpoints: webappSubnetSettings.serviceEndpoints
    delegations: webappSubnetSettings.delegations
    nsgId: !empty(webappSubnetCidr) ? nsgWebapp!.outputs.nsgId : ''
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }
  dependsOn: [
    ...(!sntWebappExists && !empty(webappSubnetCidr) ? [nsgWebapp] : [])
    ...(!sntAca002Exists && !empty(aca2SubnetCidr) ? [acaSnt2] : [])
    ...(!sntAcaExists ? [acaSnt] : [])
    ...(!sntGenaiExists ? [genaiSnt] : [])
    ...(!sntAksExists ? [aksSnt] : [])
    ...(!sntAks002Exists && !empty(aks2SubnetCidr) ? [aks2Snt] : [])
  ]
}

// Subnet settings
var dataBricksPrivateSubnetSettings = {
  cidr: dbxPrivSubnetCidr
  name: 'dbxpriv'
  delegations: [
    'Microsoft.Databricks/workspaces'
  ]
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
  ]
}

var dataBricksPublicSubnetSettings =   {
  cidr: dbxPubSubnetCidr
  name: 'dbxpub'
  delegations: [
    'Microsoft.Databricks/workspaces'
  ]
  serviceEndpoints: [
    'Microsoft.KeyVault'
    'Microsoft.Storage'
  ]
}

module nsgDbx '../modules/databricksNsg.bicep' = if(!empty(dbxPubSubnetCidr) && !sntDatabricksPubExists){
  name: take('dbxNsg-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'dbx-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags:tags
  }
}

module dbxPubSnt '../modules/subnetWithNsg.bicep' = if(!empty(dbxPubSubnetCidr) && !sntDatabricksPubExists){
  name: take('dbxpub-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-dbxpub'
    virtualNetworkName: vnetNameFull
    addressPrefix: dataBricksPublicSubnetSettings.cidr
    location: location
    serviceEndpoints: dataBricksPublicSubnetSettings.serviceEndpoints
    delegations: dataBricksPublicSubnetSettings.delegations
    nsgId: nsgDbx!.outputs.nsgId
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }

  dependsOn: [
    ...(!sntDatabricksPubExists && !empty(dbxPubSubnetCidr) ? [nsgDbx] : [])
    ...(!sntAks002Exists ? [aks2Snt] : [])
    ...(!sntAcaExists || !sntAca002Exists ? [acaSnt2] : [])
    ...(!sntWebappExists && !empty(webappSubnetCidr) ? [webappSnt] : [])
    aksSnt
    genaiSnt
    acaSnt
  ]
}

module dbxPrivSnt '../modules/subnetWithNsg.bicep' = if(!empty(dbxPrivSubnetCidr) && !sntDatabricksPrivExists){
  name: take('dbxpriv-${deploymentProjSpecificUniqueSuffix}',64) // Max 64 chars
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-dbxpriv'
    virtualNetworkName: vnetNameFull
    addressPrefix: dataBricksPrivateSubnetSettings.cidr
    location: location
    serviceEndpoints: dataBricksPrivateSubnetSettings.serviceEndpoints
    delegations: dataBricksPrivateSubnetSettings.delegations
    nsgId: nsgDbx!.outputs.nsgId
    centralDnsZoneByPolicyInHub:centralDnsZoneByPolicyInHub
  }

  // Make sure that no overlapping processes are created
  // On some cases AzureRm will return an error if parallel
  // subnet creation processes are started
  dependsOn: [
    ...(!sntDatabricksPrivExists && !empty(dbxPrivSubnetCidr) ? [nsgDbx] : [])
    ...(!sntDatabricksPubExists && !empty(dbxPubSubnetCidr) ? [dbxPubSnt] : [])
    aksSnt
    genaiSnt
    acaSnt
    aks2Snt
    acaSnt2
    webappSnt
  ]
}

module nsgLogicapp '../modules/nsgGenAI.bicep' = if (createLogicAppSubnet) {
  name: take('nsgLogicapp-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'logicapp-nsg-${projectName}-${locationSuffix}-${env}'
    location: location
    tags: tags
  }
}

module logicappSnt '../modules/subnetWithNsg.bicep' = if (createLogicAppSubnet) {
  name: take('logicappSnet-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(vnetResourceGroupScope)
  params: {
    name: 'snt-${projectName}-logicapp'
    virtualNetworkName: vnetNameFull
    addressPrefix: logicappSubnetCidr
    location: location
    delegations: ['Microsoft.Web/serverFarms']
    serviceEndpoints: ['Microsoft.KeyVault', 'Microsoft.Storage']
    nsgId: nsgLogicapp!.outputs.nsgId
    centralDnsZoneByPolicyInHub: centralDnsZoneByPolicyInHub
  }
  // Keep edges to every writer: optional intermediate modules may be skipped.
  dependsOn: [
    aksSnt
    genaiSnt
    acaSnt
    aks2Snt
    acaSnt2
    webappSnt
    dbxPubSnt
    dbxPrivSnt
  ]
}
// The following outputs are used for network_parameters.json
// that is generated by generateNetworkParameters.ps1 script

output aksSubnetId string = !sntAksExists ? aksSnt!.outputs.subnetId : resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, !empty(subnetProjAKS) ? replace(subnetProjAKS, '<xxx>', projectNumber) : 'snt-${projectName}-aks')
output aks2SubnetId string = (!sntAks002Exists && !empty(aks2SubnetCidr)) ? aks2Snt!.outputs.subnetId : (sntAks002Exists ? resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, !empty(subnetProjAKS2) ? replace(subnetProjAKS2, '<xxx>', projectNumber) : 'snt-${projectName}-aks-002') : '')
output genaiSubnetId string = !sntGenaiExists ? genaiSnt!.outputs.subnetId : resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, !empty(subnetProjGenAI) ? replace(subnetProjGenAI, '<xxx>', projectNumber) : 'snt-${projectName}-genai')
output acaSubnetId string = !sntAcaExists ? acaSnt!.outputs.subnetId : resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, !empty(subnetProjACA) ? replace(subnetProjACA, '<xxx>', projectNumber) : 'snt-${projectName}-aca')
output aca2SubnetId string = (!sntAca002Exists && !empty(aca2SubnetCidr)) ? acaSnt2!.outputs.subnetId : (sntAca002Exists ? resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull,!empty(subnetProjACA2) ? replace(subnetProjACA2, '<xxx>', projectNumber) :  'snt-${projectName}-aca-002') : '')
output webappSubnetId string = (!sntWebappExists && !empty(webappSubnetCidr)) ? webappSnt!.outputs.subnetId : (sntWebappExists ? resourceId(subscription().subscriptionId, vnetResourceGroup, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, !empty(subnetProjWebapp) ? replace(subnetProjWebapp, '<xxx>', projectNumber) : 'snt-${projectName}-webapp') : '')
output logicappSubnetId string = !needsLogicAppSubnet ? '' : (createLogicAppSubnet ? logicappSnt!.outputs.subnetId : ((sntLogicappExists || BYO_subnets) && !empty(logicappSubnetNameOrId)
  ? (BYO_subnets && startsWith(toLower(logicappSubnetNameOrId), '/subscriptions/')
    ? logicappSubnetNameOrId
    : resourceId(subscription().subscriptionId, vnetResourceGroupScope, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, logicappSubnetNameOrId))
  : fail('Private Logic Apps Standard requires a dedicated /26 subnet allocation or explicit BYO subnet. Rerun networking.')))
output dbxPubSubnetName string = empty(dbxPubSubnetCidr) ? '' : (!empty(subnetProjDatabricksPublic) ? replace(subnetProjDatabricksPublic, '<xxx>', projectNumber) : 'snt-${projectName}-dbxpub')
output dbxPrivSubnetName string = empty(dbxPrivSubnetCidr) ? '' : (!empty(subnetProjDatabricksPrivate) ? replace(subnetProjDatabricksPrivate, '<xxx>', projectNumber) : 'snt-${projectName}-dbxpriv')
output aks2RouteTableId string = aks2RouteTableIdToUse
