targetScope = 'subscription'

// ================================================================
// CORE INFRASTRUCTURE DEPLOYMENT - Phase 2 Implementation
// This file deploys core infrastructure components including:
// - Storage Accounts (for AI/ML workloads)
// - Key Vault
// - Container Registry
// - Application Insights
// - Private Virtual Machine
// - Bing Search (if enabled)
// ================================================================

// SKU for services
// ============================================================================
// Per-environment Storage Account SKU: 'dev' uses the Dev SKU, 'test'(Stage) and 'prod' use the StageProd SKU.
@allowed(['Standard_LRS', 'Standard_GRS', 'Standard_RAGRS', 'Standard_ZRS', 'Premium_LRS', 'Premium_ZRS', 'Standard_GZRS', 'Standard_RAGZRS'])
param skuStorageAccountDev string = 'Standard_LRS'
@allowed(['Standard_LRS', 'Standard_GRS', 'Standard_RAGRS', 'Standard_ZRS', 'Premium_LRS', 'Premium_ZRS', 'Standard_GZRS', 'Standard_RAGZRS'])
param skuStorageAccountStageProd string = 'Standard_LRS'
@allowed(['Premium', 'Standard', 'Basic']) 
param containerRegistrySkuName string = 'Premium' // NB! Basic and Standard ACR SKUs don't support private endpoints.
param bingSearchSKU string = 'S1'
param updateKeyvaultRbac bool = true
@description('Diagnostic setting level for monitoring and logging')
@allowed(['gold', 'silver', 'bronze'])
param diagnosticSettingLevel string = 'silver'

// CMK Parameters
param cmk bool = false
param cmkKeyName string = ''
param bingExists bool = false

// ============== PARAMETERS ==============
@description('Environment: dev, test, prod')
@allowed(['dev', 'test', 'prod'])
param env string

@description('Project number (e.g., "005")')
param projectNumber string

@description('Location for all resources')
param location string

@description('Location suffix (e.g., "weu", "swc")')
param locationSuffix string

@description('Common resource suffix (e.g., "-001")')
param commonResourceSuffix string

@description('Project-specific resource suffix')
param resourceSuffix string

// Resource exists flags from Azure DevOps
param keyvaultExists bool = false
param storageAccount1001Exists bool = false
param storageAccount2001Exists bool = false
param acrProjectExists bool = false
param applicationInsightExists bool = false
@description('Deploy workspace-based project Application Insights. Defaults to the existing advanced behavior.')
param enableApplicationInsights bool = true
param vmExists bool = false
param miACAExists bool = false
param miPrjExists bool = false

@description('Enable private VM deployment')
param enableProjectVM bool = false
@description('Common resource abbreviation for short names. Default is "cmn"')
param commonResourceShortName string = 'cmn'

// Security and networking
param enablePublicGenAIAccess bool = false
param enablePublicAccessWithPerimeter bool = false
param allowPublicAccessWhenBehindVnet bool = false
param enableLogicApps bool = false
param centralDnsZoneByPolicyInHub bool = false

// ============================================================================
// PS-Networking: Needs to be here, even if not used, since .JSON file
// ============================================================================
@description('Required subnet IDs from subnet calculator')
param genaiSubnetId string
param aksSubnetId string
param acaSubnetId string
@description('Optional subnets from subnet calculator')
param aca2SubnetId string = ''
param aks2SubnetId string = ''
@description('App Service / Function VNet integration subnet (delegated to Microsoft.Web/serverFarms)')
param webappSubnetId string = ''
param logicappSubnetId string = ''
@description('if projectype is not genai-1, but instead all')
param dbxPubSubnetName string = ''
param dbxPrivSubnetName string = ''

// Base parameters
param subnetCommon string = '' // Base parameter override (previous JSON)
param common_subnet_name string // Base parameter override (previous JSON)

// Users
param technicalAdminsObjectID string = ''
param technicalAdminsEmail string = ''

// Networking parameters for calculation
param vnetNameBase string
param vnetResourceGroup_param string = ''
param vnetNameFull_param string = ''
param network_env string = ''

// Private DNS configuration
param privDnsSubscription_param string = ''
param privDnsResourceGroup_param string = ''

// Resource group configuration
param commonResourceGroup_param string = ''

// Key Vault specific
param keyvaultSoftDeleteDays int = 90
// NOTE: When CMK is enabled, purge protection MUST be true (Azure requirement)
param keyvaultEnablePurgeProtection bool = true

// VM specific
param vmSKUSelectedArrayIndex int = 2
param vmSKU array = [
  'Standard_E2s_v3'
  'Standard_D4s_v3'
  'standard_D2as_v5'
]
param adminUsername string ='aifactoryadmin'
param adminPassword string
param hybridBenefit bool = false

// Container Registry
param useCommonACR bool = true
@description('When using an existing common ACR, false skips redeploying its registry settings and private endpoint. Project access assignments remain enabled.')
param updateCommonACR bool = true
param acr_adminUserEnabled bool = false
param acr_dedicated bool = true

// Tags
param tagsProject object = {}
param tags object = {}

// IP Rules
param IPwhiteList string = ''

// Dependencies and naming
param aifactorySuffixRG string
param commonRGNamePrefix string
param restore bool = true

// Technical contact for access policies
param technicalContactId string = '' // TODO-Remove, Replaced by personas

// Principal type configuration
param useAdGroups bool = true

// Seeding Key Vault parameters
param inputKeyvault string
param inputKeyvaultResourcegroup string
param inputKeyvaultSubscription string
param projectServicePrincipleOID_SeedingKeyvaultName string
param projectServicePrincipleAppID_SeedingKeyvaultName string
param projectServicePrincipleSecret_SeedingKeyvaultName string
param aifactorySalt10char string = ''
@description('Random value for deployment uniqueness')
param randomValue string
param projectPrefix string = 'esml-'
param projectSuffix string = '-rg'

// Sample Application parameters
@description('Enable deployment of sample applications')
param deploySampleApp bool = false

@description('Name of the authentication client secret in Key Vault')
param authClientSecretName string = 'aifactory-sample-app-1'

@description('Authentication client secret value for sample applications')
@secure()
param authClientSecret string = ''
@description('Common resource name identifier. Default is "esml-common"')
param commonResourceName string = 'esml-common'

// ============== VARIABLES ==============
var subscriptionIdDevTestProd = subscription().subscriptionId

// Per-environment Storage Account SKU resolution (test=Stage uses the StageProd SKU)
var storageAccountSkuName = env == 'dev' ? skuStorageAccountDev : skuStorageAccountStageProd

// Calculated variables
var projectName = 'prj${projectNumber}'
var commonResourceGroup = !empty(commonResourceGroup_param) ? commonResourceGroup_param : '${commonRGNamePrefix}${commonResourceName}-${locationSuffix}-${env}${aifactorySuffixRG}'
var targetResourceGroup = '${commonRGNamePrefix}${projectPrefix}${replace(projectName, 'prj', 'project')}-${locationSuffix}-${env}${aifactorySuffixRG}${projectSuffix}'

// Networking calculations
var vnetNameFull = !empty(vnetNameFull_param) ? replace(vnetNameFull_param, '<network_env>', network_env) : '${vnetNameBase}-${locationSuffix}-${env}${commonResourceSuffix}'
var vnetResourceGroupName = !empty(vnetResourceGroup_param)? replace(vnetResourceGroup_param, '<network_env>', network_env) : commonResourceGroup

// Private DNS calculations
var privDnsResourceGroupName = (!empty(privDnsResourceGroup_param) && centralDnsZoneByPolicyInHub) ? replace(privDnsResourceGroup_param, '<network_env>', network_env) : vnetResourceGroupName
var privDnsSubscription = (!empty(privDnsSubscription_param) && centralDnsZoneByPolicyInHub) ? privDnsSubscription_param : subscriptionIdDevTestProd
var deploymentProjSpecificUniqueSuffix = '${projectNumber}${env}${targetResourceGroup}'
var commonSubnetName = !empty(subnetCommon)?replace(subnetCommon, '<network_env>', network_env) : common_subnet_name

// ============================================================================
// AI Factory - naming convention (imported from shared module)
// ============================================================================
module namingConvention '../modules/common/CmnAIfactoryNaming.bicep' = {
  name: take('02-naming-${targetResourceGroup}', 64) // max 64 chars
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    env: env
    projectNumber: projectNumber
    locationSuffix: locationSuffix
    commonResourceSuffix: commonResourceSuffix
    resourceSuffix: resourceSuffix
    aifactorySalt10char: aifactorySalt10char
    randomValue: randomValue
    aifactorySuffixRG: aifactorySuffixRG
    commonRGNamePrefix: commonRGNamePrefix
    technicalAdminsObjectID: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsObjectID
    technicalAdminsEmail: (contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') ? '' : technicalAdminsEmail
    commonResourceGroupName: commonResourceGroup
    subscriptionIdDevTestProd: subscriptionIdDevTestProd
    genaiSubnetId: genaiSubnetId
    aksSubnetId: aksSubnetId
    acaSubnetId: acaSubnetId
    aca2SubnetId: aca2SubnetId
    aks2SubnetId: aks2SubnetId
  }
}

var miACAName = namingConvention.outputs.miACAName
var miPrjName = namingConvention.outputs.miPrjName
//var p011_genai_team_lead_email_array = namingConvention.outputs.p011_genai_team_lead_email_array
var p011_genai_team_lead_array = namingConvention.outputs.p011_genai_team_lead_array
var uniqueInAIFenv = namingConvention.outputs.uniqueInAIFenv
//var randomSalt = namingConvention.outputs.randomSalt
var defaultSubnet = namingConvention.outputs.defaultSubnet
//var aksSubnetName = namingConvention.outputs.aksSubnetName
//var acaSubnetName = namingConvention.outputs.acaSubnetName
//var genaiSubnetName = namingConvention.outputs.genaiSubnetName
var genaiName = namingConvention.outputs.genaiName

// Import specific names needed for core infrastructure deployment
var keyvaultName = namingConvention.outputs.keyvaultName
var storageAccount1001Name = namingConvention.outputs.storageAccount1001Name
//var storageAccount2001Name = namingConvention.outputs.storageAccount2001Name
var acrProjectName = namingConvention.outputs.acrProjectName
var applicationInsightName = namingConvention.outputs.applicationInsightName
var vmName = namingConvention.outputs.vmName
var bingName = namingConvention.outputs.bingName
var laWorkspaceName = namingConvention.outputs.laWorkspaceName
var kvNameCommon = namingConvention.outputs.kvNameCommon

// ============================================================================
// SPECIAL -Needs static name in existing
// ============================================================================
var bingName_Static = 'bing-${projectName}-${locationSuffix}-${env}-${uniqueInAIFenv_Static}${resourceSuffix}'

resource commonResourceGroupRef 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: commonResourceGroup
  scope: subscription(subscriptionIdDevTestProd)
}
#disable-next-line BCP318
var uniqueInAIFenv_Static = substring(uniqueString(commonResourceGroupRef.id), 0, 5)

// ACR - Common
var acrCommonName_Static = replace('acrcommon${uniqueInAIFenv_Static}${locationSuffix}${commonResourceSuffix}${env}','-','')
resource acrCommon 'Microsoft.ContainerRegistry/registries@2025-04-01' existing = if (useCommonACR) {
  name: acrCommonName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
}

// KV - Common
var cmnName_Static = 'cmn'
var kvCommonName_Static = 'kv-${cmnName_Static}${env}-${uniqueInAIFenv_Static}${commonResourceSuffix}'
resource commonKv 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
  name: kvCommonName_Static
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
}

// ============================================================================
// SPECIAL - END
// ============================================================================

// IP Rules processing
var ipWhitelist_array = !empty(IPwhiteList) ? split(IPwhiteList, ',') : []
var processedIpRulesKv = [for ip in ipWhitelist_array: {
  action: 'Allow'
  value: trim(ip)
}]
var processedIpRulesSa = [for ip in ipWhitelist_array: {
  action: 'Allow'
  value: trim(ip)
}]

// Network references using proper resource references
resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  scope: resourceGroup(subscription().subscriptionId, vnetResourceGroupName)
  name: vnetNameFull
}

module CmnZones '../modules/common/CmnPrivateDnsZones.bicep' = {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-getPrivDnsZ-${targetResourceGroup}', 64)
  params: {
    location: location
    privDnsResourceGroupName: privDnsResourceGroupName
    privDnsSubscription: privDnsSubscription
  }
}
var privateLinksDnsZones = CmnZones.outputs.privateLinksDnsZones

// Get managed identity principal IDs using helper modules
module getProjectMIPrincipalId '../modules/get-managed-identity-info.bicep' = {
  name: take('02-getPrMI-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    managedIdentityName: miPrjName
  }
}

// Assumes the principals exists.
module getACAMIPrincipalId '../modules/get-managed-identity-info.bicep' = {
  name: take('02-getACAMI-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    managedIdentityName: miACAName
  }
}

// Array vars - use principal IDs from helper modules
var var_miPrj_PrincipalId = getProjectMIPrincipalId.outputs.principalId
var var_miAca_PrincipalId = getACAMIPrincipalId.outputs.principalId

var mi_array = array(var_miPrj_PrincipalId)
var mi_array2 = array(var_miAca_PrincipalId)
var mi_principals_only = union(mi_array, mi_array2)
//var var_all_principals = union(p011_genai_team_lead_array, mi_array, mi_array2)

resource existingTargetRG 'Microsoft.Resources/resourceGroups@2025-04-01' existing = {
  name: targetResourceGroup
  scope: subscription(subscriptionIdDevTestProd)
}

// Log Analytics workspace reference for diagnostics
resource logAnalyticsWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: laWorkspaceName
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
}

// ============== DNS CONFIGURATIONS ==============
// DNS configurations for private endpoints - using dynamic outputs from modules

// ============== APPLICATION INSIGHTS ==============

module applicationInsights '../modules/applicationInsightsRGmode.bicep' = if (enableApplicationInsights) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-AppInsightsSWC4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    name: applicationInsightName
    logWorkspaceName: laWorkspaceName
    logWorkspaceNameRG: commonResourceGroup
    tags: tagsProject
    location: location
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== CMK CONFIGURATION ==============
// CMK Requirements:
// - Key Vault must have enableSoftDelete=true and enablePurgeProtection=true
// - Key Vault firewall must allow trusted Microsoft services (bypass: AzureServices)
// - Only RSA and RSA-HSM keys of size 2048 are supported
// - Managed identities need Key Vault Crypto Service Encryption User role

// Validation: Ensure purge protection is enabled when CMK is used
// This validates the external/seeding Key Vault configuration
var _ = cmk && !keyvaultEnablePurgeProtection ? fail('DEPLOYMENT FAILED: When CMK is enabled (cmk=true), the seeding Key Vault MUST have purge protection enabled (keyvaultEnablePurgeProtection=true). This is an Azure requirement for customer-managed keys.') : null

// Create Key in the external Key Vault
module cmkKey '../modules/keyVaultKey.bicep' = if (cmk) {
  name: take('02-cmkKey-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(inputKeyvaultSubscription, inputKeyvaultResourcegroup)
  params: {
    keyVaultName: inputKeyvault
    keyName: cmkKeyName
    kty: 'RSA'
    keySize: 2048
  }
}

// Assign "Key Vault Crypto Service Encryption User" to the Project Managed Identity
module cmkRbac '../modules/kvRbacSingleAssignment.bicep' = if (cmk) {
  name: take('02-cmkRbac-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(inputKeyvaultSubscription, inputKeyvaultResourcegroup)
  params: {
    keyVaultName: inputKeyvault
    principalId: miPrjPrincipalId
    keyVaultRoleId: 'e147488a-f6f5-4113-8e2d-b22465e65bf6' // Key Vault Crypto Service Encryption User
    assignmentName: 'cmk-rbac-${storageAccount1001Name}'
    principalType: 'ServicePrincipal'
  }
}

var cmkIdentityId = resourceId(subscriptionIdDevTestProd, targetResourceGroup, 'Microsoft.ManagedIdentity/userAssignedIdentities', miPrjName)

// ============== STORAGE ACCOUNTS ==============

// External key vault reference for CMK
resource externalKvForCmk 'Microsoft.KeyVault/vaults@2024-11-01' existing = if (cmk && !empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription)) {
  name: inputKeyvault
  scope: resourceGroup(inputKeyvaultSubscription, inputKeyvaultResourcegroup)
}

// CMK Key Vault URI - using existing resource reference instead of reference() function
var cmkKeyVaultUri = (cmk && !empty(inputKeyvault)) ? externalKvForCmk!.properties.vaultUri : ''

#disable-next-line BCP318
var var_sacc_dnsConfig = !storageAccount1001Exists? sacc.outputs.dnsConfig: []


// Main storage account for ML/AI workloads
module sacc '../modules/storageAccount.bicep' = if(!storageAccount1001Exists) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-AMLGenAISto1${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    skuName: storageAccountSkuName
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetName: defaultSubnet
    location: location
    enablePublicGenAIAccess: enablePublicGenAIAccess
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    allowPublicAccessWhenBehindVnet: allowPublicAccessWhenBehindVnet
    enableLogicApps: enableLogicApps
    blobPrivateEndpointName: '${storageAccount1001Name}-blob-pend'
    filePrivateEndpointName: '${storageAccount1001Name}-file-pend'
    queuePrivateEndpointName: '${storageAccount1001Name}-queue-pend'
    tablePrivateEndpointName: '${storageAccount1001Name}-table-pend'
    tags: union(tagsProject, {
      Environment: env
      Project: projectNumber
    })
    containers: [
      {
        name: 'default'
      }
    ]
    files: [
      {
        name: 'default'
      }
    ]
    vnetRules: [
      ...( !empty(genaiSubnetId) ? [genaiSubnetId] : [] )
      ...( !empty(aksSubnetId) ? [aksSubnetId] : [] )
    ]
    ipRules: empty(processedIpRulesSa) ? [] : processedIpRulesSa
    cmk: cmk
    cmkIdentityId: cmk ? cmkIdentityId : ''
    cmkKeyName: cmk ? cmkKeyName : ''
    cmkKeyVaultUri: cmkKeyVaultUri
    corsRules: [
      {
        allowedOrigins: [
          '*'
        ]
        allowedMethods: [
          'GET'
          'OPTIONS'
          'POST'
          'PUT'
        ]
        maxAgeInSeconds: 200
        exposedHeaders: [
          '*'
        ]
        allowedHeaders: [
          '*'
        ]
      }
    ]
  }
  dependsOn: [
    existingTargetRG
    ...(cmk ? [cmkKey] : [])
    ...(cmk ? [cmkRbac] : [])
  ]
}


#disable-next-line BCP318
var var_kv1_dnsConfig = !keyvaultExists? kv1.outputs.dnsConfig: []
#disable-next-line BCP318
var var_acr_dnsConfig = !acrProjectExists? acr.outputs.dnsConfig: []

// ============== KEY VAULT ==============
// Resource ID for Databricks public subnet (optional, only if name provided)
var databricksPublicSubnetResourceId = !empty(dbxPubSubnetName) ? resourceId(subscriptionIdDevTestProd, vnetResourceGroupName, 'Microsoft.Network/virtualNetworks/subnets', vnetNameFull, dbxPubSubnetName) : ''
module kv1 '../modules/kvRbacKeyVault.bicep' = if(!keyvaultExists) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-AMGenAILKeyV4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyvaultName: keyvaultName
    location: location
    tags: tagsProject
    enablePurgeProtection: keyvaultEnablePurgeProtection
    soft_delete_days: keyvaultSoftDeleteDays
    tenantIdentity: tenant().tenantId
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    enablePublicGenAIAccess:enablePublicGenAIAccess
    allowPublicAccessWhenBehindVnet: allowPublicAccessWhenBehindVnet
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetName: defaultSubnet
    privateEndpointName: '${keyvaultName}-pend'
    keyvaultNetworkPolicySubnets: [
      ...( !empty(genaiSubnetId) ? [genaiSubnetId] : [] )
      ...( !empty(aksSubnetId) ? [aksSubnetId] : [] )
      ...( !empty(dbxPubSubnetName) ? [databricksPublicSubnetResourceId] : [] )
    ]
    ipRules: empty(processedIpRulesKv) ? [] : processedIpRulesKv
    secrets: deploySampleApp ? [
      {
        name: authClientSecretName
        value: authClientSecret ?? ''
      }
    ] : []
  }
  dependsOn: [
    existingTargetRG
  ]
}

// ============== CONTAINER REGISTRY ==============
var processedIpRules = [for ip in ipWhitelist_array: {
  action: 'Allow'
  value: contains(ip, '/') ? ip : '${ip}/32'
}]



// Project-specific container registry (if not using common ACR)
module acr '../modules/containerRegistry.bicep' = if (!acrProjectExists && !useCommonACR) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-AMLGenaIContReg4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    containerRegistryName: acrProjectName
    skuName: containerRegistrySkuName
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetName: defaultSubnet
    privateEndpointName: 'pend-${projectName}${locationSuffix}-containerreg-to-vnt-mlcmn'
    tags: tagsProject
    location: location
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    allowPublicAccessWhenBehindVnet: allowPublicAccessWhenBehindVnet
    ipRules: processedIpRules
    existingIpRules: [] // Project-specific ACR has no existing rules initially
    adminUserEnabled: acr_adminUserEnabled
    dedicatedDataPoint: acr_dedicated
  }
  dependsOn: [
    existingTargetRG
  ]
}

// Get existing IP rules from common ACR if using common ACR
module getExistingAcrIpRules '../modules/get-acr-ip-rules.bicep' = if (useCommonACR) {
  name: take('02-getACRIpRules-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  params: {
    containerRegistryName: acrCommonName_Static
  }
}

#disable-next-line BCP318
var existingIpRules = useCommonACR ? getExistingAcrIpRules.outputs.ipRules : []

// Get existing ACR encryption configuration to preserve CMK if already enabled
module getExistingAcrEncryption '../modules/get-acr-encryption.bicep' = if (useCommonACR) {
  name: take('02-getACREnc-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  params: {
    containerRegistryName: acrCommonName_Static
  }
}

#disable-next-line BCP318
var acrHasExistingCmk = useCommonACR ? getExistingAcrEncryption.outputs.hasEncryption : false

// If ACR already has CMK enabled, we must preserve the existing CMK configuration during updates.
// Otherwise the update will try to enable encryption with empty Identity/KeyIdentifier and fail.
var effectiveAcrCmk = cmk || acrHasExistingCmk

// CMK Identity Variables - reference existing identity created in 11-rgCommon
var cmkIdentityName = 'id-cmn-cmk-${env}-${uniqueInAIFenv}${commonResourceSuffix}'
// Use exact format from working portal template with lowercase 'resourcegroups'
var cmkIdentityResourceId = '/subscriptions/${subscriptionIdDevTestProd}/resourcegroups/${toLower(commonResourceGroup)}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${cmkIdentityName}'

// If ACR already has a user-assigned identity (common when CMK is enabled), preserve that identity resourceId.
// Get the keys (resourceIds) from identity.userAssignedIdentities (object keyed by resourceId)
#disable-next-line BCP318
var existingAcrUserAssignedIdentityIds = (useCommonACR && acrHasExistingCmk && acrCommon != null && acrCommon!.identity != null && acrCommon!.identity!.userAssignedIdentities != null)
  ? map(items(acrCommon!.identity!.userAssignedIdentities!), entry => entry.key)
  : []
var preservedAcrCmkIdentityId = !empty(existingAcrUserAssignedIdentityIds) ? existingAcrUserAssignedIdentityIds[0] : cmkIdentityResourceId

// Use a helper module to get CMK identity properties instead of referencing directly
module getCmkIdentityInfo '../modules/get-managed-identity-info.bicep' = if(cmk) {
  name: take('02-getCmkMI-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  params: {
    managedIdentityName: cmkIdentityName
  }
}

var cmkIdentityIdString = effectiveAcrCmk ? preservedAcrCmkIdentityId : ''
var cmkIdentityClientId = cmk
  ? getCmkIdentityInfo!.outputs.clientId
  : (effectiveAcrCmk ? getExistingAcrEncryption!.outputs.keyVaultPropertiesIdentity : '')

// If we are preserving existing CMK, parse the key name + vaultUri from the existing keyIdentifier.
var existingAcrKeyIdentifier = effectiveAcrCmk ? getExistingAcrEncryption!.outputs.keyIdentifier : ''
var existingAcrKeyVaultUri = (!empty(existingAcrKeyIdentifier) && contains(existingAcrKeyIdentifier, '/keys/'))
  ? '${split(existingAcrKeyIdentifier, '/keys/')[0]}/'
  : ''
var existingAcrKeyName = (!empty(existingAcrKeyIdentifier) && contains(existingAcrKeyIdentifier, '/keys/'))
  ? split(split(existingAcrKeyIdentifier, '/keys/')[1], '/')[0]
  : ''

var effectiveAcrCmkKeyVaultUri = cmk ? cmkKeyVaultUri : (effectiveAcrCmk ? existingAcrKeyVaultUri : '')
var effectiveAcrCmkKeyName = cmk ? cmkKeyName : (effectiveAcrCmk ? existingAcrKeyName : '')

// Safety gate: never attempt to (re)apply ACR CMK unless all required values are present.
// This prevents ARM failures like:
// "InvalidEncryptionKeyVaultProperties ... Property Identity and KeyIdentifier must be set when encryption is enabled."
var canApplyAcrCmk = effectiveAcrCmk && !empty(cmkIdentityIdString) && !empty(cmkIdentityClientId) && !empty(effectiveAcrCmkKeyVaultUri) && !empty(effectiveAcrCmkKeyName)

// If the user explicitly asked for CMK but inputs are incomplete, fail fast with a clear message.
var _acrCmkGuard = cmk && !canApplyAcrCmk ? fail('DEPLOYMENT FAILED: ACR CMK was requested (cmk=true) but required CMK inputs are missing. Ensure the CMK identity exists and that cmkKeyVaultUri + cmkKeyName can be resolved (and that the deployment identity can read the existing ACR CMK settings when preserving).') : null

// Update since: "ACR sku cannot be retrieved because of internal error." when creating private endpoint.
// pend-acr-cmnsdc-containerreg-to-vnt-mlcmn
module acrCommonUpdate '../modules/containerRegistry.bicep' = if (useCommonACR && updateCommonACR) {
  scope: resourceGroup(subscriptionIdDevTestProd,commonResourceGroup)
  name: take('02-AMLGenaIContReg4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    containerRegistryName: acrCommonName_Static
    skuName: containerRegistrySkuName
    vnetName: vnetNameFull
    vnetResourceGroupName: vnetResourceGroupName
    subnetName: commonSubnetName // dynamic common subnet name
    privateEndpointName: 'pend-acr-${commonResourceShortName}${locationSuffix}-containerreg-to-${vnetNameBase}' // dynamic based on vnet name
    tags: tagsProject
    location: location
    enablePublicAccessWithPerimeter: enablePublicAccessWithPerimeter
    allowPublicAccessWhenBehindVnet: allowPublicAccessWhenBehindVnet
    ipRules: processedIpRules
    existingIpRules: existingIpRules
    adminUserEnabled: acr_adminUserEnabled
    dedicatedDataPoint: acr_dedicated
    // Preserve/apply CMK only when all required properties are present.
    // Otherwise, omit encryption from the request to avoid invalid CMK updates.
    cmk: canApplyAcrCmk
    cmkIdentityId: canApplyAcrCmk ? cmkIdentityIdString : ''
    cmkIdentityClientId: canApplyAcrCmk ? cmkIdentityClientId : ''
    cmkKeyName: canApplyAcrCmk ? effectiveAcrCmkKeyName : ''
    cmkKeyVaultUri: canApplyAcrCmk ? effectiveAcrCmkKeyVaultUri : ''

  }

  dependsOn: [
    acrCommon
    getExistingAcrEncryption
  ]
}
// Common container registry reference (if using common ACR)  
// Reference maintained for infrastructure awareness but not directly used in current deployment
// TODO: Add common ACR integration logic if needed for cross-project container sharing

// ============== MANAGED IDENTITY FOR CONTAINER APPS ==============

// Array vars - use principal IDs from helper modules
var miAcaPrincipalId = getACAMIPrincipalId.outputs.principalId!

module miRbacCmnACR '../modules/miRbac.bicep' = if(useCommonACR && !miACAExists) {
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  name: take('02-miRbacCmnACR-${deployment().name}-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    containerRegistryName: useCommonACR? acrCommonName_Static: acrProjectName
    principalId: miAcaPrincipalId
  }
}

var miPrjPrincipalId = getProjectMIPrincipalId.outputs.principalId!

module miPrjRbacCmnACR '../modules/miRbac.bicep' = if(useCommonACR && !miPrjExists) {
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  name: take('02-miPrjRbacCmnACR-${deployment().name}-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    containerRegistryName: useCommonACR? acrCommonName_Static: acrProjectName
    principalId: miPrjPrincipalId
  }
}

// ============== VIRTUAL MACHINE ==============

module vmPrivate '../modules/virtualMachinePrivate.bicep' = if(!vmExists && enableProjectVM == true) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-privVM4${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    adminUsername: adminUsername
    adminPassword: adminPassword
    hybridBenefit: hybridBenefit
    vmSize: vmSKU[vmSKUSelectedArrayIndex]
    location: location
    vmName: vmName
    subnetName: defaultSubnet
    vnetId: vnet.id
    tags: tagsProject
    keyvaultName: keyvaultName
  }
  dependsOn: [
    existingTargetRG
    kv1
  ]
}

// ============== BING SEARCH ==============

// ============== KEY VAULT SEEDING ==============

// External key vault for seeding secrets
resource externalKv 'Microsoft.KeyVault/vaults@2024-11-01' existing = if (!empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription)) {
  name: inputKeyvault
  scope: resourceGroup(inputKeyvaultSubscription, inputKeyvaultResourcegroup)
}

// Copy secrets from external key vault to project key vault
module addSecret '../modules/kvSecretsPrj.bicep' = if(!keyvaultExists && !empty(inputKeyvault)) {
  name: take('02-kvSecretsS2P${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    spAppIDValue: (!empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription) && !empty(projectServicePrincipleAppID_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleAppID_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleAppID_SeedingKeyvaultName), '<optional>')) ? externalKv!.getSecret(projectServicePrincipleAppID_SeedingKeyvaultName) : ''
    spOIDValue: (!empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription) && !empty(projectServicePrincipleOID_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<optional>')) ? externalKv!.getSecret(projectServicePrincipleOID_SeedingKeyvaultName) : ''
    spSecretValue: (!empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription) && !empty(projectServicePrincipleSecret_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleSecret_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleSecret_SeedingKeyvaultName), '<optional>')) ? externalKv!.getSecret(projectServicePrincipleSecret_SeedingKeyvaultName) : ''
    keyvaultName: keyvaultName
    keyvaultNameRG: targetResourceGroup
  }
  dependsOn: [
    existingTargetRG
    kv1
  ]
}

// ============== KEY VAULT RBAC ASSIGNMENTS ==============

// Key Vault role definitions
var keyVaultSecretsOfficerRoleId = 'b86a8fe4-44ce-4948-aee5-eccb2c155cd7' // Can get, list, set secrets
var keyVaultSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6' // Can get, list secrets
var keyVaultContributorRoleId = 'f25e0fa2-a7c8-4377-a976-54943a77a395' // Management operations

// Project key vault RBAC assignments for users and managed identities
// FIX: Removed dependency on deprecated technicalContactId parameter
// This ensures Container Apps and other services can access Key Vault
module kvPrjRbacAssignments '../modules/kvRbacAssignments.bicep' = if(!keyvaultExists || updateKeyvaultRbac) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-kvRbacPrj${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultName: keyvaultName
    userObjectIds: p011_genai_team_lead_array // Assign users (team leads)
    servicePrincipalIds: [] // Will be handled in 08-rbac-security.bicep to avoid circular dependencies
    managedIdentityIds: mi_principals_only // Both project and ACA managed identities - CRITICAL for Container Apps
    useAdGroups: useAdGroups
    keyVaultSecretsOfficerRoleId: keyVaultSecretsOfficerRoleId
    keyVaultSecretsUserRoleId: keyVaultSecretsUserRoleId
    keyVaultContributorRoleId: keyVaultContributorRoleId
  }
  dependsOn: [
    addSecret
    kv1
  ]
}

// Note: Common key vault still uses access policies (not changed per requirements)
// Common key vault access policy for technical contact
module kvCommonAccessPolicyGetList '../modules/kvCmnAccessPolicys.bicep' = if(!(contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') && !empty(technicalContactId)) {
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  name: take('02-kvSecretsGL${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultPermissions: {
      secrets: [
        'get'
        'list'
      ]
    }
    keyVaultResourceName: kvNameCommon
    policyName: 'add'
    principalId: technicalContactId
    additionalPrincipalIds: p011_genai_team_lead_array
  }
  dependsOn: [
    commonKv
  ]
}

// Service principal access to common key vault (keeping access policy model)
// SP removal support: skip entirely when the SP OID seeding secret name is empty or a placeholder (<todo>/<optional>).
module spCommonKeyvaultPolicyGetList '../modules/kvCmnAccessPolicys.bicep' = if (!(contains(tags, 'AIF-Persona-Access') && tags['AIF-Persona-Access'] == 'groups-v1') && !empty(inputKeyvault) && !empty(inputKeyvaultResourcegroup) && !empty(inputKeyvaultSubscription) && !empty(projectServicePrincipleOID_SeedingKeyvaultName) && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<todo>') && !contains(toLower(projectServicePrincipleOID_SeedingKeyvaultName), '<optional>')) {
  scope: resourceGroup(subscriptionIdDevTestProd, commonResourceGroup)
  name: take('02-spGetList${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultPermissions: {
      secrets: [
        'get'
      ]
    }
    keyVaultResourceName: commonKv.name
    policyName: 'add'
    principalId: externalKv!.getSecret(projectServicePrincipleOID_SeedingKeyvaultName)
    additionalPrincipalIds: []
  }
  dependsOn: [
    commonKv
  ]
}

// ============== PRIVATE DNS MODULES ==============

// Storage Account Private DNS
module privateDnsStorage '../modules/privateDns.bicep' = if(!storageAccount1001Exists && centralDnsZoneByPolicyInHub == false) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-corePrivDnsSA${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    dnsConfig: var_sacc_dnsConfig
    privateLinksDnsZones: privateLinksDnsZones
  }
  dependsOn: [
    CmnZones
    existingTargetRG
  ]
}

// Key Vault Private DNS
module privateDnsKeyVault '../modules/privateDns.bicep' = if(!keyvaultExists && centralDnsZoneByPolicyInHub == false) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-corePrivDnsKV${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    dnsConfig: var_kv1_dnsConfig
    privateLinksDnsZones: privateLinksDnsZones
  }
  dependsOn: [
    CmnZones
    existingTargetRG
  ]
}

// Container Registry Private DNS
module privateDnsContainerRegistry '../modules/privateDns.bicep' = if(!acrProjectExists && !centralDnsZoneByPolicyInHub && !useCommonACR) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-corePrivDnsACR${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    dnsConfig: var_acr_dnsConfig
    privateLinksDnsZones: privateLinksDnsZones
  }
  dependsOn: [
    CmnZones
    existingTargetRG
  ]
}

// ============== DIAGNOSTIC SETTINGS ==============

// Storage Account 1001 Diagnostic Settings
module storageAccount1001Diagnostics '../modules/diagnostics/storageAccountDiagnostics.bicep' = if (!storageAccount1001Exists) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-diagStorage1001-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    storageAccountName: storageAccount1001Name
    logAnalyticsWorkspaceId: logAnalyticsWorkspace.id
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    sacc
  ]
}

// Key Vault Diagnostic Settings
module keyVaultDiagnostics '../modules/diagnostics/keyVaultDiagnostics.bicep' = if (!keyvaultExists) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-diagKeyVault-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    keyVaultName: keyvaultName
    logAnalyticsWorkspaceId: logAnalyticsWorkspace.id
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    kv1
  ]
}

// Container Registry Diagnostic Settings
module containerRegistryDiagnostics '../modules/diagnostics/containerRegistryDiagnostics.bicep' = if (!acrProjectExists && !useCommonACR) {
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  name: take('02-diagACR-${deploymentProjSpecificUniqueSuffix}', 64)
  params: {
    containerRegistryName: acrProjectName
    logAnalyticsWorkspaceId: logAnalyticsWorkspace.id
    diagnosticSettingLevel: diagnosticSettingLevel
  }
  dependsOn: [
    acr
  ]
}

// ============================================================================
// AMPLS Integration in Foundation Deployment
// ============================================================================
@description('Enable Azure Monitor Private Link Scope deployment')
param enableAMPLS bool = false
@description('Hub monitoring subnet name')
param hubMonitoringSubnetName string = 'snet-monitoring'
@description('Existing Application Insights resource IDs already connected to AMPLS')
param existingAmplsApplicationInsightsIds array = []
@description('Existing Log Analytics Workspace resource IDs already connected to AMPLS')
param existingAmplsLogAnalyticsWorkspaceIds array = []

// Deploy AMPLS in hub/spoke architecture if enabled
module amplsIntegration '../modules/monitoring/amplsIntegration.bicep' = if (enableAMPLS) {
  name: take('11-ampls-${deploymentProjSpecificUniqueSuffix}', 64)
  scope: resourceGroup(subscriptionIdDevTestProd, targetResourceGroup)
  params: {
    env: env
    location: location
    locationSuffix: locationSuffix
    commonResourceSuffix: commonResourceSuffix
    tags: tags
    privDnsSubscription: privDnsSubscription
    privDnsResourceGroup: privDnsResourceGroupName
    hubVnetName: vnetNameFull
    hubVnetResourceGroup: vnetResourceGroupName
    monitoringSubnetName: hubMonitoringSubnetName
    existingLogAnalyticsWorkspaceIds: union(existingAmplsLogAnalyticsWorkspaceIds, [logAnalyticsWorkspace.id])
    existingApplicationInsightsIds: union(existingAmplsApplicationInsightsIds, enableApplicationInsights ? [applicationInsights!.outputs.ainsId] : [])
    ingestionAccessMode: 'PrivateOnly'
    queryAccessMode: 'PrivateOnly'
    deployToHubResourceGroup: true
  }
  dependsOn: [
    applicationInsights
    CmnZones
  ]
}

// Add AMPLS outputs to foundation outputs
@description('AMPLS deployment information (if enabled)')
output amplsInfo object = enableAMPLS ? {
  #disable-next-line BCP318
  ampls: amplsIntegration.outputs.amplsInfo
  #disable-next-line BCP318
  dataCollectionEndpoint: amplsIntegration.outputs.dceInfo
  #disable-next-line BCP318
  privateEndpoint: amplsIntegration.outputs.privateEndpointInfo
  #disable-next-line BCP318
  resourceGroup: amplsIntegration.outputs.amplsResourceGroup
  #disable-next-line BCP318
  subscription: amplsIntegration.outputs.amplsSubscription
  #disable-next-line BCP318
  integrationComplete: amplsIntegration.outputs.integrationComplete
} : {}

// ============== OUTPUTS - Simplified ==============
// Note: Outputs simplified to avoid conditional module reference issues
// Resource information should be retrieved through Azure CLI queries after deployment

@description('Key Vault deployment status')
output keyVaultDeployed bool = !keyvaultExists

@description('Storage Account 1001 deployment status')
output storageAccount1001Deployed bool = !storageAccount1001Exists

@description('Container Registry deployment status')
output containerRegistryDeployed bool = (!acrProjectExists && useCommonACR == false)

@description('Application Insights deployment status')
output applicationInsightsDeployed bool = enableApplicationInsights && !applicationInsightExists

@description('Virtual Machine deployment status')
output virtualMachineDeployed bool = (!vmExists && enableProjectVM)
