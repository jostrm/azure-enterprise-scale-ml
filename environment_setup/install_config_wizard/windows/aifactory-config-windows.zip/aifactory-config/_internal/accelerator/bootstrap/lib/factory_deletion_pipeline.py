"""Reviewed factory deletion through the existing scoped provider workers.

Loaded by factory_lifecycle with its own lifecycle context so pinned distributions
and offline consumers use the same validation, identities, leases and receipts.
"""

import copy
import json
import re
import time
from urllib.parse import quote, unquote, urlsplit


CONTRACT = "ordered-project-pipelines-v1"
HUB_CONTRACT = "factory-owned-access-hub-v1"
# Not doubled 2026-10-27 (pinned in test_time_budgets.py): x 15 s = 6 h, GitHub's 360-minute job maximum, and the
# longest reviewed teardown request, equal to factory_lifecycle.MANIFEST_MAX_LIFETIME_SECONDS.
PROVIDER_RUN_POLLS = 1440
TEARDOWN_REQUEST_MAX_LIFETIME_SECONDS = 3 * 3600  # = factory_lifecycle.MANIFEST_MAX_LIFETIME_SECONDS (tripled 2026-10-28)
DELETE_FLAGS = ("enableDeleteForDisabledResources", "deleteAllServicesForProject",
                "deleteKeyvaultAlso", "deleteAllForProject")
# Reusable VPN/hub/connectivity platform types. Only a factory's own bootstrap-built VPN gateway,
# Bastion and DNS private resolver may be deleted, and only with bootstrap proof; site links,
# vWAN and ExpressRoute constructs always stay protected.
PROTECTED_TYPES = {
    "microsoft.network/virtualnetworkgateways", "microsoft.network/vpngateways",
    "microsoft.network/vpnsites", "microsoft.network/virtualhubs",
    "microsoft.network/virtualwans", "microsoft.network/bastionhosts",
    "microsoft.network/expressroutecircuits", "microsoft.network/connections",
    "microsoft.network/p2svpngateways", "microsoft.network/vpnserverconfigurations",
    "microsoft.network/localnetworkgateways", "microsoft.network/dnsresolvers",
    "microsoft.network/dnsforwardingrulesets",
}
HUB_DELETABLE_TYPES = {"microsoft.network/virtualnetworkgateways", "microsoft.network/bastionhosts",
                       "microsoft.network/dnsresolvers", "microsoft.network/dnsforwardingrulesets"}
# A hub-connected (external-mode) factory's VPN gateway lives in the shared hub. Its own groups may
# hold only a bootstrap-built Bastion Developer (it cannot traverse peering) or DNS resolver parts.
EXTERNAL_HUB_RETAINED_TYPES = {"microsoft.network/virtualnetworkgateways"}
# Child resources that attach a hub to a network; each must target only this factory's VNets.
HUB_LINK_TARGETS = {
    "microsoft.network/privatednszones/virtualnetworklinks": "virtualNetwork",
    "microsoft.network/dnsforwardingrulesets/virtualnetworklinks": "virtualNetwork",
    "microsoft.network/virtualnetworks/virtualnetworkpeerings": "remoteVirtualNetwork",
}
HUB_SOURCE = "access-hub-bootstrap-record"
# A hub-connected factory's bootstrap-recorded peerings and DNS links inside a shared hub.
SHARED_HUB_CONTRACT = "shared-hub-spoke-links-v1"
VNET_TYPE = "microsoft.network/virtualnetworks"
fl = None


def validate_flags(flags):
    fl.require(isinstance(flags, dict) and set(flags) == set(DELETE_FLAGS)
               and all(flags[name] is True for name in DELETE_FLAGS),
               "factory-delete-flags-must-all-be-true")


def phase(item):
    kind = item.get("type", "").lower()
    if fl.RG_ID.fullmatch(item["id"]):
        return 4
    if kind.endswith("/capabilityhosts"):
        return 0
    if kind in {"microsoft.search/searchservices/sharedprivatelinkresources",
                "microsoft.search/services/sharedprivatelinkresources"}:
        return 1
    if kind.startswith("microsoft.network/"):
        return 3
    return 2


# Children the platform maintains leave with their parent and are never sent a DELETE of their own, even where the
# provider lists one (aif-138 2026-11-02: ARM answered 400 to the registry's built-in _repositories_admin scope map).
# A type maps to the name prefix of its platform-maintained items ("" is every item).
PLATFORM_CHILDREN = {
    "microsoft.containerregistry/registries/scopemaps": "_repositories_",
    "microsoft.network/privateendpoints/privatelinkserviceproxies": "",
    "microsoft.network/virtualnetworks/taggedtrafficconsumers": "",
    # NSG rules leave with their NSG, after the subnets that reference it: ARM refuses a required Bastion rule's DELETE
    # (aif-138 2026-11-02 run15, NetworkSecurityGroupNotCompliantForAzureBastionSubnet), and one NSG delete replaces
    # dozens of rule deletes.
    "microsoft.network/networksecuritygroups/securityrules": "",
    # A VM's extensions and run commands leave with the VM: governance deallocates the runner VM nightly, and ARM answers
    # 409 to their own DELETE on a deallocated VM (aif-144 2026-11-05 delete_factory run17, AzurePolicyforLinux).
    "microsoft.compute/virtualmachines/extensions": "",
    "microsoft.compute/virtualmachines/runcommands": "",
    # A Log Analytics workspace's tables leave with the workspace: aif-144 (2026-11-04) froze 697 of them.
    "microsoft.operationalinsights/workspaces/tables": "",
}


def delete_condition(body):
    """If-Match on the live etag, only where that etag is stable (fl.resource_etag): a private endpoint's or NIC's
    rolls while the platform tears it down, and its delete then ends Failed with PreconditionFailed (aif-138
    2026-11-02 run16)."""
    etag = fl.resource_etag(body, {})
    return {"If-Match": etag} if etag else None


def manifest_bodies(bodies):
    """The bodies a frozen manifest holds: a listed-only child's fingerprint body. Its body_hash is unchanged (the
    fingerprint is idempotent) and a Log Analytics table drops its schema: aif-144 (2026-11-04 run5) froze 697 tables
    into a 9.30 MB manifest against the protected worker's 8 MB."""
    return {key: fl.fingerprint_body(body, fl.resource_type_from_id(key))
            if fl.resource_type_from_id(key) in fl.LISTED_ONLY_CHILDREN else body for key, body in bodies.items()}


def platform_child(item):
    prefix = PLATFORM_CHILDREN.get(str(item.get("type", "")).lower())
    return prefix is not None and item["id"].rsplit("/", 1)[-1].lower().startswith(prefix)


# A private endpoint may outlive the service it connects to: deleting the service only disconnects it, and the
# endpoint still leaves in the network phase (aif-138 2026-11-01: the common group's Key Vault, storage and ACR PEs).
OUTLIVING_TYPES = {"microsoft.network/privateendpoints", "microsoft.network/privateendpoints/privatelinkserviceproxies"}


def ordered_resources(rows):
    deleted = {row["id"].lower(): copy.deepcopy(row) for row in rows if row["delete"]}
    inherited = {}
    for row in deleted.values():
        parent = str(row.get("delete_via_parent", "")).lower()
        if parent in deleted:
            # A child deleted through its parent leaves with it, so the parent precedes what the child must.
            inherited.setdefault(parent, set()).update(
                value.lower() for value in row.get("depends_on", []) if value.lower() in deleted
                and not _overlaps(value.lower(), parent))
    for identifier, row in deleted.items():
        dependencies = {value.lower() for value in row.get("depends_on", []) if value.lower() in deleted}
        dependencies.update(inherited.get(identifier, ()))
        dependencies.update(parent for parent in deleted if identifier.startswith(parent + "/"))
        if str(row.get("type", "")).lower() in OUTLIVING_TYPES:
            dependencies = {value for value in dependencies if phase(deleted[value]) >= phase(row)}
        fl.require(all(phase(row) <= phase(deleted[value]) for value in dependencies),
                   "factory-delete-phase-dependency-conflict")
        row["depends_on"] = sorted(dependencies)
    ordered = []
    for step in range(5):
        ordered.extend(fl.deletion_order([row for row in deleted.values() if phase(row) == step]))
    return ordered


def marked_protected(body):
    tags = {str(k).lower(): str(v).lower() for k, v in (body.get("tags") or {}).items()}
    return (fl.project_resource_shared(body)
            or any(tags.get("aifactory." + name) == "true" for name in ("bootstrap", "platform", "protected", "reusable")))


def protected(body, explicit, hub=None):
    key, kind = body["id"].lower(), str(body.get("type", "")).lower()
    return (any(key == identifier or key.startswith(identifier + "/") for identifier in explicit)
            or marked_protected(body)
            or (kind == "microsoft.machinelearningservices/workspaces" and str(body.get("kind", "")).lower() == "hub")
            or (kind in PROTECTED_TYPES and not (kind in HUB_DELETABLE_TYPES and hub_covers(hub, key))))


def access_hub(document):
    """Catalog-built proof that bootstrap records, not names/tags, tie a hub to exactly this target."""
    hub = document.get("access_hub_ownership")
    if hub is None:
        return None
    target, scopes = document["target"], {scope.lower() for scope in document["locks"]["scopes"]}

    def ids(values, pattern):
        return (isinstance(values, list) and values and values == sorted(set(values))
                and all(isinstance(value, str) and value == value.lower() and pattern.fullmatch(value)
                        for value in values))

    fl.require(isinstance(hub, dict) and hub.get("contract") == HUB_CONTRACT
               and all(hub.get(key) == target[key] for key in ("factory_id", "scaleset_id", "subscription_id"))
               and hub.get("mode") in ("integrated", "external")
               and ids(hub.get("resource_group_ids"), fl.RG_ID) and set(hub["resource_group_ids"]) <= scopes
               and ids(hub.get("resource_ids"), fl.NESTED_ID)
               and all(fl.arm_scope(value) in hub["resource_group_ids"] for value in hub["resource_ids"])
               and ids(hub.get("factory_resource_groups"), fl.RG_ID) and scopes <= set(hub["factory_resource_groups"])
               and isinstance(hub.get("evidence"), dict) and fl.guid(hub["evidence"].get("workflow_id"))
               and fl.hash_value(hub["evidence"].get("record_hash"))
               and (hub["mode"] == "integrated" or not any(
                   fl.resource_type_from_id(value) in EXTERNAL_HUB_RETAINED_TYPES for value in hub["resource_ids"])),
               "factory-delete-access-hub-proof-invalid")
    return hub


def hub_covers(hub, key):
    return bool(hub) and any(key == root or key.startswith(root + "/") for root in hub["resource_ids"])


def verify_access_hub_network(hub, bodies, links=None):
    """Deleting a factory-owned hub must not cut DNS, peering or site links of anything else.

    The one exception is the factory side of a peering pair whose hub side the shared-hub
    link proof records: the hub VNet that this factory's bootstrap peered back to it.
    """
    if not hub:
        return
    allowed = set(hub["factory_resource_groups"])
    pairs = {(row["id"].rsplit("/virtualnetworkpeerings/", 1)[0], row["remote_virtual_network_id"])
             for row in (links or {}).get("links", []) if row["type"] == PEERING_TYPE}
    for key, body in bodies.items():
        if fl.RG_ID.fullmatch(key) or fl.arm_scope(key) not in hub["resource_group_ids"]:
            continue
        kind = fl.resource_type_from_id(key)
        fl.require(kind != "microsoft.network/connections", "factory-delete-access-hub-external-connection")
        if kind in HUB_LINK_TARGETS:
            remote = ((body.get("properties") or {}).get(HUB_LINK_TARGETS[kind]) or {}).get("id")
            fl.require(isinstance(remote, str) and fl.RG_ID.match(remote)
                       and (fl.arm_scope(remote.lower()) in allowed
                            or kind == PEERING_TYPE and (remote.lower(), key.rsplit("/virtualnetworkpeerings/", 1)[0])
                            in pairs), "factory-delete-access-hub-foreign-link")


def shared_hub_links(document):
    """Catalog-built proof that consumed bootstrap records created these links inside a shared hub.

    Each link sits in a protected connectivity hub group outside every deletion scope and
    targets a VNet inside this manifest's writable scopes; nothing else in the hub qualifies.
    """
    proof = document.get("shared_hub_links")
    if proof is None:
        return None
    target, locks = document["target"], document["locks"]
    scopes = {scope.lower() for scope in locks["scopes"]}
    closure = scopes | {scope.lower() for scope in locks["common_dependencies"]}
    explicit = {value.lower() for value in document.get("protected_resource_ids", []) if isinstance(value, str)}
    links = proof.get("links") if isinstance(proof, dict) else None
    fl.require(isinstance(proof, dict) and proof.get("contract") == SHARED_HUB_CONTRACT
               and all(proof.get(key) == target[key] for key in ("factory_id", "scaleset_id", "subscription_id"))
               and _sorted_ids(proof.get("hub_resource_group_ids"), fl.RG_ID)
               and set(proof["hub_resource_group_ids"]) <= explicit
               and not any(_overlaps(group, scope) for group in proof["hub_resource_group_ids"] for scope in closure)
               and isinstance(links, list) and links and all(isinstance(row, dict) for row in links)
               and [row.get("id") for row in links] == _sorted_unique([row.get("id") for row in links])
               and all(set(row) == {"id", "type", "remote_virtual_network_id"}
                       and _sorted_ids([row["id"]], fl.NESTED_ID) and row["type"] in HUB_LINK_TARGETS
                       and row["type"] == fl.resource_type_from_id(row["id"])
                       and fl.arm_scope(row["id"]) in proof["hub_resource_group_ids"]
                       and _sorted_ids([row["remote_virtual_network_id"]], fl.NESTED_ID)
                       and fl.resource_type_from_id(row["remote_virtual_network_id"]) == VNET_TYPE
                       and fl.arm_scope(row["remote_virtual_network_id"]) in scopes for row in links)
               and isinstance(proof.get("evidence"), dict) and fl.guid(proof["evidence"].get("workflow_id"))
               and fl.hash_value(proof["evidence"].get("record_hash")),
               "factory-delete-shared-hub-links-proof-invalid")
    return proof


def _sorted_unique(values):
    return sorted(set(values)) if all(isinstance(value, str) for value in values) else None


def _vnets(entries, deleted_only=False):
    return {key for key, row in entries.items() if not fl.RG_ID.fullmatch(key)
            and fl.resource_type_from_id(key) == VNET_TYPE and (row["delete"] or not deleted_only)}


def freeze_shared_hub_links(cloud, proof, entries):
    """Recorded hub links to a VNet this manifest deletes; links nobody can prove stay, reported."""
    deleted, vnets = _vnets(entries, deleted_only=True), _vnets(entries)
    recorded = {row["id"]: row for row in proof["links"]}
    live, _ = _hub_inventory(cloud, proof["hub_resource_group_ids"], "factory-delete-hub-inventory-incomplete")
    removable, retained = [], []
    for row in live:
        expected = recorded.get(row["id"].lower())
        remote = row["remote_virtual_network_id"]
        if expected is None:
            if remote in vnets:
                retained.append(row["id"])
            continue
        # A recorded link that now points elsewhere, or at a VNet this cohort keeps, is ambiguous.
        fl.require(remote == expected["remote_virtual_network_id"], "factory-delete-hub-link-changed")
        fl.require(remote in deleted or remote not in vnets, "factory-delete-hub-link-remote-retained")
        if remote in deleted:
            removable.append(row)
        else:
            retained.append(row["id"])  # Its VNet was already gone before this cohort: not ours to cut.
    return sorted(removable, key=lambda row: row["id"].lower()), sorted(retained, key=str.lower)


def validate_shared_hub_links(data, proof, entries):
    if not proof:
        fl.require("hub_links" not in data and "retained_hub_links" not in data,
                   "factory-delete-shared-hub-links-unproven")
        return
    recorded = {row["id"]: row for row in proof["links"]}
    links, retained = data.get("hub_links"), data.get("retained_hub_links")
    fl.require(isinstance(links, list) and all(isinstance(row, dict) and isinstance(row.get("id"), str) for row in links)
               and isinstance(retained, list) and all(isinstance(value, str) for value in retained)
               and [row["id"].lower() for row in links] == _sorted_unique([row["id"].lower() for row in links])
               and [value.lower() for value in retained] == _sorted_unique([value.lower() for value in retained])
               and not {row["id"].lower() for row in links} & {value.lower() for value in retained},
               "factory-delete-hub-links-invalid")
    for row in links:
        expected = recorded.get(row["id"].lower())
        fl.require(expected is not None and set(row) == {"id", "type", "api_version", "remote_virtual_network_id", "side"}
                   and row["side"] == "hub" and row["type"] == expected["type"]
                   and row["api_version"] == HUB_LINK_COLLECTIONS[row["type"].rsplit("/", 1)[0]][1]
                   and row["remote_virtual_network_id"] == expected["remote_virtual_network_id"]
                   and entries.get(row["remote_virtual_network_id"], {}).get("delete") is True,
                   "factory-delete-hub-links-invalid")
    fl.require(all(fl.RG_ID.match(value) and fl.arm_scope(value.lower()) in proof["hub_resource_group_ids"]
                   for value in retained), "factory-delete-hub-links-invalid")


def require_unique_hub_links(documents):
    links = [row["id"].lower() for document in documents for row in document["deletion"].get("hub_links", [])]
    fl.require(len(set(links)) == len(links), "factory-delete-hub-link-overlap")


def unlink_shared_hub(cloud, locks, document, receipt, persist, sleep=time.sleep):
    """Last step: remove the recorded hub-side links only once their spoke VNet is verifiably gone."""
    _unlink_hub_links(cloud, locks, document, receipt, persist, document["deletion"]["hub_links"],
                      "factory-delete-hub-link", sleep)


def _unlink_hub_links(cloud, locks, document, receipt, persist, links, code, sleep):
    """Delete each reviewed hub-side link whose spoke VNet this run verifiably deleted (shared by the shared hub and
    the own hub); a link Azure already cleared counts as removed."""
    data = document["deletion"]
    removed = {value.lower() for value in receipt.setdefault("deleted_hub_links", [])}
    deleted = {value.lower() for value in receipt["deleted_resources"]}
    versions = {row["id"].lower(): row["api_version"] for row in data["resources"]}
    for link in links:
        if link["id"].lower() in removed:
            continue
        remote = link["remote_virtual_network_id"]
        fl.require(remote in deleted, code + "-before-spoke")
        locks.authorize(document)
        locks.assert_held()
        cloud.verify_identity()
        status, _, _ = cloud.arm("GET", remote, versions[remote], allowed=(200, 404))
        fl.require(status == 404, code + "-spoke-present")
        status, _, body = cloud.arm("GET", link["id"], link["api_version"], allowed=(200, 404))
        if status != 404:
            # Azure usually clears a deleted VNet's DNS links itself; a hub peering stays Disconnected.
            fl.require(_remote(body) == remote, code + "-changed")
            verify_link_permissions(cloud, [link])
            locks.authorize(document)
            receipt.update(mutation_started=True, pending_resource=link["id"])
            persist()
            cloud.arm("DELETE", link["id"], link["api_version"], allowed=(200, 202, 204, 404),
                      headers=delete_condition(body))
            fl.wait_absent(cloud, locks, link["id"], link["api_version"], sleep)
            receipt.pop("pending_resource", None)
        receipt["deleted_hub_links"].append(link["id"])
        removed.add(link["id"].lower())
        persist()
    receipt["hub_unlink_complete"] = True
    persist()


# An added scale set of a Standalone-with-own-hub factory joins the bootstrap scale set's hub (purple 75887c83, aif-154
# 2026-11-08): its common VNet peers to the hub VNet and its private endpoints' zone groups name the hub group's zones.
# Deleting only that scale set (ESAF Scenario 5) must neither treat those references as unknown dependencies nor leave
# the hub side's peering to the deleted VNet behind. Only these (source kind -> referenced kind) pairs are attachments.
OWN_HUB_CONTRACT = "own-hub-spoke-attachments-v1"
ZONE_GROUP_TYPE = "microsoft.network/privateendpoints/privatednszonegroups"
ZONE_TYPE = "microsoft.network/privatednszones"
# Gateway transit (useRemoteGateways): Azure lists the hub's VPN gateway in the spoke peering's remoteGateways, in the
# peering and in the VNet's embedded copy (aif-154 video 06 Scenario 5, 2026-11-09). The gateway stays with the hub.
GATEWAY_TYPE = "microsoft.network/virtualnetworkgateways"
OWN_HUB_ATTACHMENTS = {VNET_TYPE: {VNET_TYPE, GATEWAY_TYPE},
                       VNET_TYPE + "/virtualnetworkpeerings": {VNET_TYPE, GATEWAY_TYPE},
                       ZONE_GROUP_TYPE: {ZONE_TYPE}}


def own_hub_group(body, target):
    """Live proof that a group outside the deletion belongs to a sibling scale set of the same factory: its enrollment
    tags name this factory and another scale set, and it is neither a project group nor marked shared."""
    tags = (body or {}).get("tags") or {}
    fl.require(isinstance(tags, dict), "malformed-project-ownership-tags")
    tags = {str(key).lower(): str(value) for key, value in tags.items()}
    scale = tags.get(fl.TAG_KEYS["scaleset_id"])
    return (tags.get(fl.TAG_KEYS["factory_id"]) == target["factory_id"] and bool(scale)
            and scale != target["scaleset_id"] and not tags.get(fl.TAG_KEYS["project_id"])
            and not fl.project_resource_shared(body))


def _own_hub_candidates(document, resources):
    """Referenced id -> referencing ids, for every reference outside the deletion's lock scopes of an attachment kind."""
    ids = {row["id"].lower() for row in resources}
    external = {value.lower() for value in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    found = {}
    for row in resources:
        kinds = OWN_HUB_ATTACHMENTS.get(str(row.get("type", "")).lower(), ())
        for value in row.get("depends_on", []):
            key = value.lower()
            if (key not in ids and fl.NESTED_ID.fullmatch(key) and fl.arm_scope(key) not in external
                    and fl.resource_type_from_id(key) in kinds):
                found.setdefault(key, set()).add(row["id"].lower())
    return found


def _spoke_vnets(resources):
    return {row["id"].lower() for row in resources
            if row.get("delete") is True and str(row.get("type", "")).lower() == VNET_TYPE}


def freeze_own_hub(cloud, document, resources):
    """The own-hub plan of a whole-group scale-set deletion, or None: proven sibling hub groups, the attachments the
    deleted resources name there, and the hub-side peerings and links that target a deleted VNet. A reference into a
    group no live tag proves stays out, so validation still refuses it (unknown-resource-dependency)."""
    found = _own_hub_candidates(document, resources)
    groups = []
    for group in sorted({fl.arm_scope(key) for key in found}):
        status, _, body = cloud.arm("GET", group, fl.RG_API, allowed=(200, 404))
        if status == 200 and own_hub_group(body, document["target"]):
            groups.append(group)
    attachments = sorted(key for key in found if fl.arm_scope(key) in groups)
    if not attachments:
        return None
    spokes = _spoke_vnets(resources)
    live, _ = _hub_inventory(cloud, groups, "own-hub-inventory-incomplete")
    links = sorted(({"id": row["id"].lower(), "type": row["type"], "api_version": row["api_version"],
                     "remote_virtual_network_id": row["remote_virtual_network_id"]}
                    for row in live if row["remote_virtual_network_id"] in spokes), key=lambda row: row["id"])
    # Azure clears a deleted VNet's zone links itself; the hub peering stays (Disconnected) and must be deleted.
    verify_link_permissions(cloud, [row for row in links if row["type"] == PEERING_TYPE])
    return {"contract": OWN_HUB_CONTRACT, "resource_group_ids": groups, "attachments": attachments, "links": links}


def validate_own_hub(document, resources):
    """Pure check of a frozen own-hub plan; returns allows(source_type, reference) for the dependency check."""
    hub = document["deletion"]["own_hub"]
    scopes = {value.lower() for value in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    found, spokes = _own_hub_candidates(document, resources), _spoke_vnets(resources)
    groups = hub.get("resource_group_ids") if isinstance(hub, dict) else None
    attachments = hub.get("attachments") if isinstance(hub, dict) else None
    links = hub.get("links") if isinstance(hub, dict) else None
    fl.require(isinstance(hub, dict) and set(hub) == {"contract", "resource_group_ids", "attachments", "links"}
               and hub["contract"] == OWN_HUB_CONTRACT and _sorted_ids(groups, fl.RG_ID)
               and not any(_overlaps(group, scope) for group in groups for scope in scopes)
               and _sorted_ids(attachments, fl.NESTED_ID) and set(attachments) <= set(found)
               and {fl.arm_scope(value) for value in attachments} == set(groups)
               and isinstance(links, list) and all(isinstance(row, dict) for row in links)
               and [row.get("id") for row in links] == _sorted_unique([row.get("id") for row in links])
               and all(set(row) == {"id", "type", "api_version", "remote_virtual_network_id"}
                       and _sorted_ids([row["id"]], fl.NESTED_ID) and row["type"] in HUB_LINK_TARGETS
                       and row["type"] == fl.resource_type_from_id(row["id"])
                       and row["api_version"] == HUB_LINK_COLLECTIONS[row["type"].rsplit("/", 1)[0]][1]
                       and fl.arm_scope(row["id"]) in groups and row["remote_virtual_network_id"] in spokes
                       for row in links),
               "own-hub-attachments-invalid")
    allowed = set(attachments)
    return lambda kind, value: (value.lower() in allowed
                                and fl.resource_type_from_id(value.lower()) in OWN_HUB_ATTACHMENTS.get(kind, ()))


def verify_own_hub(cloud, document):
    """Before the first DELETE: every hub group is still a sibling scale set's and the hub peerings stay deletable."""
    hub = document["deletion"]["own_hub"]
    for group in hub["resource_group_ids"]:
        status, _, body = cloud.arm("GET", group, fl.RG_API, allowed=(200, 404))
        fl.require(status == 200 and own_hub_group(body, document["target"]), "own-hub-group-ownership-changed")
    verify_link_permissions(cloud, [row for row in hub["links"] if row["type"] == PEERING_TYPE])


def unlink_own_hub(cloud, locks, document, receipt, persist, sleep=time.sleep):
    """After the scale set's groups are gone: only its spoke VNet's peerings and links on the hub side."""
    verify_own_hub(cloud, document)
    _unlink_hub_links(cloud, locks, document, receipt, persist, document["deletion"]["own_hub"]["links"],
                      "own-hub-link", sleep)


def teardown_order(document, rows):
    """Bootstrap hub and private runner closure last, after every other reviewed deletion."""
    hub = access_hub(document)
    deleted = {row["id"].lower(): row for row in rows if row["delete"]}
    late = {key for key in deleted if hub_covers(hub, key)}
    pending = list(late)
    while pending:
        key = pending.pop()
        for value in [*deleted[key].get("depends_on", []), *(parent for parent in deleted if key.startswith(parent + "/"))]:
            if value.lower() in deleted and value.lower() not in late:
                late.add(value.lower())
                pending.append(value.lower())
    if not late:
        return ordered_resources(rows)
    return (ordered_resources([row for row in rows if row["id"].lower() not in late])
            + ordered_resources([row for row in rows if row["id"].lower() in late]))


def connectivity_groups(document, bodies):
    """Shared connectivity resource groups that factory deletion retains whole.

    Declared groups come from the hashed plan, and a group whose name contains
    'connectivity' counts as shared connectivity too. Names only deny deletion; they never
    establish ownership. Resource types do not mark a group: unproven gateways and Bastion
    hosts are already protected resources, and a factory's own bootstrap-proven access hub
    stays deletable under its hub proof, so its groups are never shared connectivity.
    """
    declared = document.get("connectivity_resource_group_ids", [])
    fl.require(isinstance(declared, list)
               and all(isinstance(value, str) and fl.RG_ID.fullmatch(value) for value in declared),
               "factory-delete-connectivity-scopes-invalid")
    groups = {value.lower() for value in declared}
    scopes = {value.lower() for value in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    fl.require(len(groups) == len(declared) and groups <= scopes, "factory-delete-connectivity-scopes-invalid")
    hub = access_hub(document)
    hub_groups = set(hub["resource_group_ids"]) if hub else set()
    fl.require(not groups & hub_groups, "factory-delete-connectivity-scopes-invalid")
    groups.update(fl.arm_scope(key) for key in bodies
                  if fl.RG_ID.fullmatch(key) and "connectivity" in key.rsplit("/", 1)[-1].lower()
                  and fl.arm_scope(key) not in hub_groups)
    return sorted(groups)


def assert_connectivity_group_allowed(document, identifier, body):
    groups = {fl.arm_scope(identifier)}
    groups.update(fl.managed_group_cascades(body, document["target"]["subscription_id"]))
    fl.require(not groups.intersection(document["deletion"]["connectivity_resource_group_ids"]),
               "factory-delete-connectivity-group-deletion-forbidden")


def validate_route(document):
    route = document["route"]
    fl.require(fl.guid(document["identity"].get("deployment_object_id")), "bound-deployment-principal-required")
    fl.require(route.get("scoped_contract") == 1
               and isinstance(route.get("auth_namespace"), str)
               and re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", route["auth_namespace"]),
               "namespaced-route-required")
    runner = route.get("runner", {})
    fl.require(runner.get("os") == "linux" and runner.get("kind") in ("hosted", "self-hosted"),
               "explicit-linux-scoped-runner-required")
    if runner["kind"] == "hosted":
        fl.require(runner.get("image") in ("ubuntu-latest", "ubuntu-24.04", "ubuntu-22.04"),
                   "unsupported-hosted-runner-image")
    elif route["kind"] == "gha":
        labels = runner.get("labels")
        fl.require(isinstance(labels, list) and 2 <= len(labels) <= 16
                   and all(isinstance(label, str) and re.fullmatch(r"[A-Za-z0-9_. -]{1,128}", label) for label in labels)
                   and {"self-hosted", "linux"} <= {label.lower() for label in labels},
                   "explicit-self-hosted-labels-required")
    else:
        fl.require(isinstance(runner.get("pool"), str) and re.fullmatch(r"[A-Za-z0-9_. -]{1,128}", runner["pool"]),
                   "explicit-ado-agent-pool-required")


def normalize_projects(document, projects):
    fl.require(isinstance(projects, list), "factory-delete-registered-projects-required")
    normalized = []
    for project in projects:
        fl.require(isinstance(project, dict) and fl.guid(project.get("project_id"))
                   and isinstance(project.get("project_number"), str)
                   and re.fullmatch(r"[0-9]{3}", project["project_number"])
                   and project["project_number"] != "000", "factory-delete-project-identity-required")
        ids = project.get("registered_resource_ids")
        fl.require(isinstance(ids, list) and ids and all(isinstance(value, str)
                   and (fl.RG_ID.fullmatch(value) or fl.NESTED_ID.fullmatch(value)) for value in ids),
                   "factory-delete-registered-resources-required")
        normalized.append({"project_id": project["project_id"], "project_number": project["project_number"],
                           "registered_resource_ids": sorted(set(value.lower() for value in ids))})
    fl.require(len({row["project_id"] for row in normalized}) == len(normalized)
               and len({row["project_number"] for row in normalized}) == len(normalized)
               and sorted(row["project_number"] for row in normalized) == sorted(document["target"]["project_ids"]),
               "factory-delete-project-registration-mismatch")
    return sorted(normalized, key=lambda row: row["project_number"])


def freeze(cloud, document, ownership_records, registered_projects):
    validate_route(document)
    fl.protected_resource_group_patterns(document)
    connectivity_groups(document, {})
    projects = normalize_projects(document, registered_projects)
    cloud.verify_identity()
    reader = fl.deletion_reader(cloud, document)
    scopes = sorted(set(document["locks"]["scopes"] + document["locks"]["common_dependencies"]), key=str.lower)
    writable = {scope.lower() for scope in document["locks"]["scopes"]}
    hub, links = access_hub(document), shared_hub_links(document)
    # Idempotent like fl.freeze_deletion_inventory: a registered project's group that an earlier run of this deletion
    # already removed (aif-138 2026-11-02: its project stage succeeded, the common stage stopped) is recorded as already
    # absent, never read as a closure; its project stage then only re-proves the absence.
    absent = {scope.lower() for scope in fl.absent_groups(cloud, document["locks"]["scopes"])}
    closure, bodies = fl.collect_resource_closure(cloud, [scope for scope in scopes if scope.lower() not in absent])
    connectivity = set(connectivity_groups(document, bodies))
    # The operator executes common teardown; it must never sit on anything in scope.
    fl.verify_deletion_identity(document, bodies)
    verify_access_hub_network(hub, bodies, links)
    explicit = document.get("protected_resource_ids", [])
    fl.require(isinstance(explicit, list) and all(isinstance(value, str)
               and (fl.RG_ID.fullmatch(value) or fl.NESTED_ID.fullmatch(value)) for value in explicit),
               "factory-delete-protected-identities-invalid")
    explicit = {value.lower() for value in explicit}
    project_map = {row["project_number"]: row for row in projects}
    core_owner = {key: document["target"][key] for key in ("factory_id", "scaleset_id")}
    entries = {}
    # Explicit catalog receipts only, like the sibling deletion freezes; never manifest-embedded copies.
    fl.require(isinstance(ownership_records, dict), "factory-delete-ownership-records-required")
    records = {key.lower(): value for key, value in ownership_records.items()}
    cache = {}
    for key, body in bodies.items():
        tags = body.get("tags") or {}
        owner = {field: tags[tag] for field, tag in fl.TAG_KEYS.items() if tag in tags}
        proof = {"ownership_source": "tags", "owner": owner}
        if not owner and key in records:
            evidence = records[key]
            try:
                owner = fl.verified_receipt_owner(reader, evidence.get("ownership_evidence"), key,
                                                 fl.resource_digest(body), cache)
                fl.require(owner == evidence.get("owner"), "factory-delete-receipt-owner-mismatch")
                proof = {**evidence, "owner": owner}
            except fl.Blocked as error:
                if error.code != "child-instance-ownership-unverified":
                    raise
                # Hash drift warns, never blocks (as fl.freeze_deletion_inventory, aif-138 2026-11-01): a pipeline or
                # the platform updated the child after its receipt. A bootstrap-recorded hub resource (the untagged
                # common VNet whose peerings changed) is proven by the hub proof below; any other by the owned parent
                # it is deleted with (or, for an untagged top-level resource of an option-B pipeline receipt, the group
                # that carries its exact owner). The superseded receipt stays as review evidence.
                superseded = {"code": error.code, "ownership_evidence": copy.deepcopy(evidence.get("ownership_evidence"))}
                if hub_covers(hub, key):
                    owner, proof = {}, {}
                else:
                    owner = copy.deepcopy(evidence.get("owner") or {})
                    proof = {"ownership_source": "managed-parent", "owner": owner,
                             "managed_parent_id": fl.receipt_parent_id(key, bodies, owner)}
                proof["receipt_superseded"] = superseded
        if not owner and key not in records and not hub_covers(hub, key) and not fl.RG_ID.fullmatch(key):
            adopted = managed_parent_owner(key, bodies)
            if adopted:
                owner = adopted[1]
                proof = {"ownership_source": "managed-parent", "owner": owner, "managed_parent_id": adopted[0]}
            attached = None if adopted else attached_subnet_owner(key, bodies, hub, core_owner)
            if attached:
                owner = attached[1]
                proof = {"ownership_source": "attached-subnets", "owner": owner,
                         "attached_virtual_network_ids": attached[0]}
        if hub_covers(hub, key):
            fl.require(not marked_protected(body), "factory-delete-access-hub-marked-protected")
            fl.require(all(owner.get(field, value) == value for field, value in core_owner.items()),
                       "factory-delete-access-hub-owner-conflict")
            if not owner:
                owner = dict(core_owner)
                proof = {"ownership_source": HUB_SOURCE, "owner": owner,
                         "ownership_evidence": copy.deepcopy(hub["evidence"]),
                         **({"receipt_superseded": proof["receipt_superseded"]} if "receipt_superseded" in proof else {})}
        number = owner.get("project_id")
        owned = all(owner.get(field) == value for field, value in core_owner.items())
        selected = owned and (not number or number in project_map)
        if number in project_map and owned:
            logical = tags.get("aifactory.logical_project_id")
            fl.require(not logical or logical == project_map[number]["project_id"],
                       "factory-delete-logical-project-mismatch")
            registered = project_map[number]["registered_resource_ids"]
            fl.require(any(key == value or key.startswith(value + "/") for value in registered),
                       "factory-delete-project-resource-unregistered")
        metadata = closure["groups"].get(key, closure["resources"].get(key))
        keep = protected(body, explicit, hub) or fl.arm_scope(key) in connectivity
        if key in explicit:
            fl.require(not selected, "factory-delete-protected-resource-selected")
        entries[key] = {"id": body["id"], **metadata, **proof,
                        "delete": selected and fl.arm_scope(key) in writable and not keep,
                        "project_number": number if owned and number in project_map else None,
                        "managed_group_ids": sorted(fl.managed_group_cascades(
                            body, document["target"]["subscription_id"])),
                        "depends_on": fl.project_resource_dependencies(body)}
        if entries[key]["delete"]:
            fl.assert_deletion_group_allowed(document, key, body)
        if not entries[key]["delete"]:
            entries[key]["retention_reason"] = ("shared-connectivity-resource-group" if fl.arm_scope(key) in connectivity else
                "protected-infrastructure" if keep else
                "outside-registered-ownership" if not selected else "read-only-dependency")
        if selected and key in closure["resources"] and entries[key]["delete"]:
            fl.require(not str(metadata["type"]).lower() in
                       ("microsoft.authorization/locks", "microsoft.authorization/denyassignments"),
                       "factory-delete-lock-or-deny-present")
    absent_rows = {}
    for project in projects:
        owner = {**core_owner, "project_id": project["project_number"]}
        matches = [key for key in closure["groups"] if entries[key]["owner"] == owner
                   and key in project["registered_resource_ids"]]
        gone = sorted(absent & set(project["registered_resource_ids"]))
        # Registrations are scale-set wide, so a gone common group is "registered" by every project; the catalog's
        # ownership record (owner project_id) names the project's own group (aif-138 2026-11-02 run22). It only labels
        # a group that is gone: never a delete.
        recorded = [key for key in gone
                    if ((records.get(key) or {}).get("owner") or {}).get("project_id") == project["project_number"]]
        if matches or len(gone) > 1 or recorded:
            gone = recorded
        if not matches and not gone:
            # The project's own pipeline deleted its group and, with it, the ownership record (aif-152 2026-11-07,
            # job 4d970c77). AI Factory names a project group with project<NNN>: a gone registered group carrying
            # this project's number is its own group, already deleted. Still only a label for a gone group.
            gone = [key for key in sorted(absent & set(project["registered_resource_ids"]))
                    if re.search(r"project" + project["project_number"] + r"(?![0-9])", key.rsplit("/", 1)[-1])]
        fl.require(len(matches) + len(gone) == 1, "factory-delete-exact-project-group-required")
        if gone:
            project["resource_group_id"] = gone[0]
            absent_rows[gone[0]] = absent_group_row(document, gone[0], project["project_number"])
            continue
        project["resource_group_id"] = matches[0]
        fl.require(all(entry["owner"] == owner or protected(bodies[key], explicit, hub) for key, entry in entries.items()
                       if fl.arm_scope(key) == matches[0]), "factory-delete-project-group-shared-or-unowned")
    # The deployment principal runs only project stages; it may sit solely on bootstrap-proven
    # common hub/runner resources, which the operator tears down after the project barrier.
    worker = copy.deepcopy(document)
    worker["identity"]["object_id"] = document["identity"]["deployment_object_id"]
    fl.verify_deletion_identity(worker, {key: body for key, body in bodies.items()
                                         if not (hub_covers(hub, key) and entries[key]["project_number"] is None)})
    # Retained shared infrastructure prevents deletion of its ancestors and dependencies.
    changed = True
    while changed:
        changed = False
        for key, item in entries.items():
            parent = item.get("managed_parent_id") if item.get("ownership_source") == "managed-parent" else None
            if item["delete"] and parent and not entries.get(parent, {}).get("delete"):
                # Option A owns a child through the parent it is deleted with; a retained parent keeps it
                # (aif-138 2026-11-01: built-in defaultSecurityRules of kept NSGs).
                item["delete"] = False
                item["retention_reason"] = "retained-managed-parent"
                changed = True
            if item["delete"] and platform_child(item) and any(
                    key.startswith(other + "/") and not row["delete"] and not fl.RG_ID.fullmatch(other)
                    for other, row in entries.items()):
                # A platform child leaves only with its parent, so a retained parent keeps it (aif-144 2026-11-04
                # run3: a retained VNet's taggedTrafficConsumers child stopped the freeze, service-lifecycle-unsupported).
                item["delete"] = False
                item["retention_reason"] = "retained-parent"
                changed = True
            if not item["delete"]:
                for candidate, other in entries.items():
                    if other["delete"] and (key.startswith(candidate + "/") or candidate in item["depends_on"]):
                        fl.require(other["project_number"] is None or fl.RG_ID.fullmatch(candidate),
                                   "factory-delete-retained-project-dependency")
                        other["delete"] = False
                        other["retention_reason"] = "retained-resource-dependency"
                        changed = True
    operations = {}
    for key, item in entries.items():
        if not item["delete"] or key in closure["groups"]:
            continue
        namespace = item["type"].split("/", 1)[0]
        if namespace not in operations:
            operations[namespace] = set(cloud.provider_operations(namespace))
        item["independent_delete"] = (item["type"].lower() + "/delete" in operations[namespace]
                                      and not platform_child(item))
    for key, item in entries.items():
        if not item["delete"] or key in closure["groups"] or item["independent_delete"]:
            continue
        parents = [parent for parent, candidate in entries.items() if key.startswith(parent + "/")
                   and candidate["delete"] and candidate.get("independent_delete") is True]
        fl.require(parents and phase(item) not in (0, 1), "factory-delete-service-lifecycle-unsupported")
        item["delete_via_parent"] = max(parents, key=len)
    for key in sorted(absent - set(absent_rows)):
        # A common group a resumed run already removed (aif-138 2026-11-02 run21) is gone like a project's.
        absent_rows[key] = absent_group_row(document, key, None)
    resources = [entries[key] for key in sorted(closure["resources"])]
    groups = [entries.get(key) or absent_rows[key] for key in sorted(set(closure["groups"]) | absent)]
    closure = fl.frozen_closure(closure)  # no provider fingerprints: a rollout never refuses the confirmation
    data = {"inventory_mode": CONTRACT, "inventory_complete": True, "revision": document["manifest_revision"],
            "flags": dict.fromkeys(DELETE_FLAGS, True), "projects": projects, "resource_groups": groups,
            "resources": resources, "inventory_hash": fl.digest(resources), "closure": closure,
            "closure_hash": fl.digest(closure), "bodies": manifest_bodies(bodies), "protected_resource_ids": sorted(explicit),
            "connectivity_resource_group_ids": sorted(connectivity),
            "configuration_hash": fl.digest(document["config"]),
            "route_hash": fl.digest(document["route"]), "source_hash": fl.digest(document["source"])}
    if hub:
        data["access_hub_hash"] = fl.digest(hub)
    if links:
        data["hub_links"], data["retained_hub_links"] = freeze_shared_hub_links(cloud, links, entries)
        data["shared_hub_links_hash"] = fl.digest(links)
    validate({**document, "deletion": data})
    for scope in scopes:
        if scope.lower() not in absent:
            cloud.assert_no_active_deployments(scope)
    verify_permissions(cloud, data, absent)
    verify_link_permissions(cloud, data.get("hub_links", []))
    return data


def absent_group_row(document, key, number):
    """The frozen row of a registered project's group that is already gone: deleted, never read or sent a DELETE."""
    owner = {**{field: document["target"][field] for field in ("factory_id", "scaleset_id")},
             **({"project_id": number} if number else {})}
    scope = next(value for value in document["locks"]["scopes"] if value.lower() == key)
    return {"id": scope, "etag": None, "body_hash": fl.digest({"already_absent": key}), "delete": True, "owner": owner,
            "project_number": number, "already_absent": True, "managed_group_ids": [], "depends_on": []}


def validate(document):
    validate_route(document)
    fl.protected_resource_group_patterns(document)
    data = document["deletion"]
    validate_flags(data.get("flags"))
    fl.require(data.get("inventory_mode") == CONTRACT and data.get("inventory_complete") is True
               and data.get("revision") == document["manifest_revision"], "factory-delete-frozen-inventory-required")
    fl.require(data.get("configuration_hash") == fl.digest(document["config"])
               and data.get("route_hash") == fl.digest(document["route"])
               and data.get("source_hash") == fl.digest(document["source"]), "factory-delete-plan-binding-changed")
    hub, links = access_hub(document), shared_hub_links(document)
    fl.require(data.get("access_hub_hash") == (fl.digest(hub) if hub else None)
               and data.get("shared_hub_links_hash") == (fl.digest(links) if links else None),
               "factory-delete-plan-binding-changed")
    projects = normalize_projects(document, data.get("projects"))
    fl.require([row["project_number"] for row in projects] ==
               [row["project_number"] for row in data["projects"]], "factory-delete-project-order-changed")
    fl.require(data.get("inventory_hash") == fl.digest(data.get("resources"))
               and data.get("closure_hash") == fl.digest(data.get("closure"))
               and isinstance(data.get("bodies"), dict), "factory-delete-inventory-hash-mismatch")
    groups, resources = data["resource_groups"], data["resources"]
    expected_scopes = {scope.lower() for scope in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    fl.require({row["id"].lower() for row in groups} == expected_scopes, "factory-delete-scope-mismatch")
    entries = {row["id"].lower(): row for row in groups + resources}
    absent = {row["id"].lower() for row in groups if row.get("already_absent") is not None}
    fl.require(len(entries) == len(groups + resources) and set(entries) == set(data["bodies"]) | absent
               and not absent & set(data["bodies"]), "factory-delete-complete-inventory-required")
    project_groups = {row["project_number"]: row.get("resource_group_id") for row in data["projects"]}
    for key in absent:
        row = entries[key]
        number = row.get("project_number")
        fl.require(row == absent_group_row(document, key, number)
                   and (project_groups.get(number) == key if number else key not in project_groups.values())
                   and not any(other.startswith(key + "/") for other in entries),
                   "factory-delete-absent-group-unreviewed")
    fl.require(data.get("connectivity_resource_group_ids") == connectivity_groups(document, data["bodies"]),
               "factory-delete-connectivity-scopes-changed")
    fl.protect_coordination_storage(document)
    verify_access_hub_network(hub, data["bodies"], links)
    validate_shared_hub_links(data, links, entries)
    for key, row in entries.items():
        if key in absent:
            continue
        # The type the closure recorded: a listed Log Analytics table has no "type" in its body (as fl.verify_fingerprint).
        fl.require(type(row.get("delete")) is bool
                   and row.get("body_hash") == fl.resource_digest(data["bodies"][key], row.get("type")),
                   "factory-delete-resource-fingerprint-required")
        owner_number = row.get("owner", {}).get("project_id")
        owned = all(row.get("owner", {}).get(field) == document["target"][field]
                    for field in ("factory_id", "scaleset_id"))
        expected_number = owner_number if owned and owner_number in document["target"]["project_ids"] else None
        fl.require(row.get("project_number") == expected_number, "factory-delete-project-stage-mismatch")
        if not row["delete"]:
            continue
        assert_connectivity_group_allowed(document, key, data["bodies"][key])
        fl.assert_deletion_group_allowed(document, key, data["bodies"][key])
        fl.require(fl.arm_scope(key) in {scope.lower() for scope in document["locks"]["scopes"]}
                   and all(row.get("owner", {}).get(field) == document["target"][field]
                           for field in ("factory_id", "scaleset_id")),
                   "factory-delete-resource-owner-mismatch")
        fl.require(not protected(data["bodies"][key], data["protected_resource_ids"], hub),
                   "factory-delete-protected-resource-selected")
        fl.require(row.get("ownership_source") != HUB_SOURCE or (hub_covers(hub, key) and row["owner"] == {
            field: document["target"][field] for field in ("factory_id", "scaleset_id")}),
                   "factory-delete-access-hub-owner-unproven")
        fl.require(row.get("ownership_source") != "attached-subnets" or attached_subnet_owner(
            key, data["bodies"], hub, {field: document["target"][field] for field in ("factory_id", "scaleset_id")})
            == (row.get("attached_virtual_network_ids"), row["owner"]), "factory-delete-attached-subnets-proof-invalid")
        fl.require(not owner_number or owner_number in document["target"]["project_ids"],
                   "factory-delete-project-owner-unregistered")
        fl.require(row.get("managed_group_ids", []) == sorted(fl.managed_group_cascades(
            data["bodies"][key], document["target"]["subscription_id"])), "factory-delete-managed-cascade-changed")
        fl.require(all(scope in entries and all(child["delete"] and child.get("project_number") == expected_number
                       for child in entries.values() if fl.arm_scope(child["id"]) == scope)
                       for scope in row.get("managed_group_ids", [])),
                   "factory-delete-implicit-managed-group-forbidden")
        if expected_number is None:
            fl.require(not any(entries.get(value.lower(), {}).get("project_number") is not None
                               for value in row["depends_on"]), "factory-delete-common-before-project-dependency")
        fl.require(all(child["delete"] for other, child in entries.items()
                       if other.startswith(key + "/")), "factory-delete-retained-child")
        if not fl.RG_ID.fullmatch(key):
            fl.require(type(row.get("independent_delete")) is bool, "factory-delete-provider-delete-proof-required")
            fl.require(not (row["independent_delete"] and platform_child(row)),
                       "factory-delete-platform-child-delete-forbidden")
            if not row["independent_delete"]:
                parent = row.get("delete_via_parent", "")
                fl.require(parent in entries and key.startswith(parent + "/")
                           and entries[parent]["delete"] and entries[parent].get("independent_delete") is True
                           and not fl.RG_ID.fullmatch(parent) and phase(row) not in (0, 1),
                           "factory-delete-service-cascade-unreviewed")
    ordered_resources(groups + resources)


def verify_permissions(cloud, data, absent=()):
    # Check every independent DELETE, not merely an RG cascade permission.
    for item in data["resources"] + data["resource_groups"]:
        if (item["delete"] and not item.get("delete_via_parent")
                and item["id"].lower() not in {value.lower() for value in absent}):
            fl.verify_project_permissions(cloud, {"resource_groups": [item] if fl.RG_ID.fullmatch(item["id"]) else [],
                                                  "resources": [] if fl.RG_ID.fullmatch(item["id"]) else [item]})


def project_rows(document):
    return [row for row in document["deletion"]["resources"] + document["deletion"]["resource_groups"]
            if row["delete"] and row.get("project_number") in document["target"]["project_ids"]]


def verify_worker_result(document, result):
    expected = {row["id"].lower() for row in project_rows(document)}
    fl.require(isinstance(result, dict) and result.get("schema") == 1 and result.get("status") == "succeeded"
               and result.get("run_id") == document["run_id"]
               and result.get("manifest_hash") == document["manifest_hash"]
               and result.get("source_commit") == document["source"]["commit"]
               and result.get("target") == document["target"], "factory-delete-worker-binding-unverified")
    fl.require(result.get("flags") == document["deletion"]["flags"]
               and all(value is True for value in result.get("flags", {}).values())
               and result.get("project_numbers") == document["target"]["project_ids"]
               and isinstance(result.get("deleted_resources"), list)
               and all(isinstance(value, str) for value in result["deleted_resources"])
               and len(result["deleted_resources"]) == len(expected)
               and {value.lower() for value in result["deleted_resources"]} == expected,
               "factory-delete-worker-incomplete")
    fl.require(result.get("projects") == completed_projects(document), "factory-delete-project-evidence-incomplete")
    return result


def completed_projects(document):
    return [{"project_id": project["project_id"], "project_number": project["project_number"],
             "status": "succeeded", "deleted_resources": sorted(row["id"].lower() for row in project_rows(document)
                 if row["project_number"] == project["project_number"])}
            for project in document["deletion"]["projects"]]


def observed_absent(cloud, document):
    absent = []
    for row in document["deletion"]["resources"] + document["deletion"]["resource_groups"]:
        if row["delete"]:
            api = fl.RG_API if fl.RG_ID.fullmatch(row["id"]) else row["api_version"]
            status, _, _ = cloud.arm("GET", row["id"], api, allowed=(200, 404))
            if status == 404:
                absent.append(row["id"])
    return absent


def verify_absent(cloud, rows):
    for row in rows:
        if row["delete"]:
            api = fl.RG_API if fl.RG_ID.fullmatch(row["id"]) else row["api_version"]
            status, _, _ = cloud.arm("GET", row["id"], api, allowed=(200, 404))
            fl.require(status == 404, "factory-delete-resource-still-present")


def group_cascaded_grants(document, rows):
    """The deployment identity's own enrollment grants (fl.enrollment_grant) on a group these rows delete. They go with
    the group delete, never one by one: its Contributor grant deletes the group and its RBAC Administrator grant deletes
    role assignments, so deleting either first locks the stage out (aif-138 2026-11-02, project-delete-permission-required)."""
    if not (document.get("identity") or {}).get("deployment_object_id"):
        return set()  # a bootstrap teardown runs as the operator and has no deployment principal's grants
    groups = [row["id"] for row in rows if row["delete"] and fl.RG_ID.fullmatch(row["id"])]
    bodies = document["deletion"].get("bodies", {})
    return {row["id"].lower() for row in rows
            if row["delete"] and row["id"].lower() in bodies
            and fl.enrollment_grant(row["id"], bodies[row["id"].lower()], document, groups)}


def delete_rows(cloud, locks, document, receipt, persist, rows, sleep=time.sleep, fresh=None):
    flags = document["deletion"]["flags"]
    validate_flags(flags)
    entries = document["deletion"]["resources"] + document["deletion"]["resource_groups"]
    removed = {value.lower() for value in receipt.get("deleted_resources", []) + receipt.get("observed_absent", [])}
    cascaded = group_cascaded_grants(document, rows)
    for row in teardown_order(document, rows):
        key = row["id"].lower()
        if row.get("already_absent") is True:
            verify_absent(cloud, [row])  # the review proved it gone: re-proved, never deleted or counted as deleted
            continue
        if key in removed:
            verify_absent(cloud, [row])
            if key not in {value.lower() for value in receipt.get("deleted_resources", [])}:
                receipt.setdefault("deleted_resources", []).append(row["id"])
                persist()
            continue
        if row.get("delete_via_parent") or key in cascaded:
            continue
        fl.require(flags["enableDeleteForDisabledResources"] is True
                   and flags["deleteAllServicesForProject"] is True,
                   "factory-delete-services-not-enabled")
        if row.get("type", "").startswith("microsoft.keyvault/"):
            fl.require(flags["deleteKeyvaultAlso"] is True, "factory-delete-keyvault-not-enabled")
        locks.authorize(document)
        locks.assert_held()
        cloud.verify_identity()
        api = fl.RG_API if fl.RG_ID.fullmatch(key) else row["api_version"]
        status, _, body = cloud.arm("GET", row["id"], api, allowed=(200, 404))
        if status == 404:
            # Only frozen, reviewed resources may become idempotently absent.
            removed.add(key)
            receipt.setdefault("deleted_resources", []).append(row["id"])
            for child in entries:
                if child["id"].lower().startswith(key + "/") and child["id"].lower() not in removed:
                    fl.require(child["delete"] and (child.get("delete_via_parent") == key
                                                    or child["id"].lower() in cascaded),
                               "factory-delete-unreviewed-service-cascade")
                    fl.wait_absent(cloud, locks, child["id"], child["api_version"], sleep)
                    removed.add(child["id"].lower())
                    receipt["deleted_resources"].append(child["id"])
            persist()
            continue
        # Bootstrap teardown deletes only the bootstrap record's own groups, so it has no shared
        # connectivity groups to protect (and its document carries none).
        if document["deletion"]["inventory_mode"] != TEARDOWN_CONTRACT:
            assert_connectivity_group_allowed(document, row["id"], body)
        fl.assert_deletion_group_allowed(document, row["id"], body)
        if fresh:
            fresh(row, body)
        else:
            fl.verify_project_inventory(cloud, document, removed)
        if fl.RG_ID.fullmatch(key):
            fl.require(flags["deleteAllForProject"] is True, "factory-delete-group-not-enabled")
            fl.require(all(child["id"].lower() in removed | cascaded for child in entries
                           if child["id"].lower().startswith(key + "/")),
                       "factory-delete-project-rg-shortcut-forbidden")
            fl.require(not cloud.list_resources(row["id"]), "factory-delete-group-not-empty")
        verify_permissions(cloud, {"resource_groups": [row] if fl.RG_ID.fullmatch(key) else [],
                                   "resources": [] if fl.RG_ID.fullmatch(key) else [row]})
        locks.authorize(document)
        receipt.update(mutation_started=True, pending_resource=row["id"])
        persist()
        cloud.arm("DELETE", row["id"], api, allowed=(200, 202, 204, 404),
                  headers=delete_condition(body))
        fl.wait_absent(cloud, locks, row["id"], api, sleep)
        removed.add(key)
        receipt.setdefault("deleted_resources", []).append(row["id"])
        for child in entries:
            if child["id"].lower().startswith(key + "/") and child["id"].lower() not in removed:
                fl.require(child["delete"] and (child.get("delete_via_parent") == key
                                                or child["id"].lower() in cascaded),
                           "factory-delete-unreviewed-service-cascade")
                fl.wait_absent(cloud, locks, child["id"], child["api_version"], sleep)
                removed.add(child["id"].lower())
                receipt["deleted_resources"].append(child["id"])
        for scope in row.get("managed_group_ids", []):
            for child in entries:
                if fl.arm_scope(child["id"]) == scope and child["id"].lower() not in removed:
                    fl.wait_absent(cloud, locks, child["id"], fl.RG_API if fl.RG_ID.fullmatch(child["id"])
                                   else child["api_version"], sleep)
                    removed.add(child["id"].lower())
                    receipt["deleted_resources"].append(child["id"])
        receipt.pop("pending_resource", None)
        persist()
    return removed


def run_worker(envelope, source_root, expected_run, expected_hash, cloud=None, sleep=time.sleep):
    document = fl._validate_manifest(envelope.get("manifest"))
    fl.require(document["run_id"] == expected_run and document["manifest_hash"] == expected_hash,
               "worker-run-binding-mismatch")
    context = envelope.get("lease_context")
    scopes = {scope.lower() for scope in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    fl.require(isinstance(context, dict) and set(context) == scopes
               and all(fl.guid(value) for value in context.values()), "worker-lease-context-required")
    if cloud is None:
        fl.require(fl.sys.platform.startswith("linux"), "linux-scoped-worker-required")
    cloud = cloud or fl.Cloud(document, expected_object_id=document["identity"]["deployment_object_id"])
    cloud.verify_identity(require_default=True)
    locks = (fl._RepositoryDeletionWorker if fl.single_writer(document) else fl.BlobLocks)(cloud, document)
    locks.held = dict(context)
    locks.verify_enrollment()
    locks.execution_claim = fl._ExecutionClaim(document, locks.read_claim())
    locks.authorize(document)
    fl._verify_source(cloud, source_root, document["source"], published=False)
    receipt = {"schema": 1, "run_id": document["run_id"], "manifest_hash": document["manifest_hash"],
               "source_commit": document["source"]["commit"], "target": document["target"],
               "status": "running", "deleted_resources": [], "mutation_started": False,
               "flags": copy.deepcopy(document["deletion"]["flags"]),
               "project_numbers": list(document["target"]["project_ids"])}
    blob = "runs/" + document["run_id"] + ".worker.json"
    locks.request("PUT", blob, data=receipt,
                  headers={"x-ms-blob-type": "BlockBlob", "If-None-Match": "*"}, allowed=(201,))

    def persist():
        receipt["updated_at"] = fl.utc_now()
        locks.request("PUT", blob, data=receipt,
                      headers={"x-ms-blob-type": "BlockBlob", "If-Match": "*"}, allowed=(201,))

    try:
        receipt["observed_absent"] = observed_absent(cloud, document)
        fl.verify_project_inventory(cloud, document, receipt["observed_absent"])
        delete_rows(cloud, locks, document, receipt, persist, project_rows(document), sleep)
        verify_absent(cloud, project_rows(document))
        fl.verify_project_inventory(cloud, document, receipt["deleted_resources"] + receipt["observed_absent"])
        receipt["projects"] = completed_projects(document)
        receipt["status"] = "succeeded"
        persist()
    except BaseException as error:
        receipt["status"] = "reconciliation-required"
        receipt.update(fl.failure_fields(error, "unexpected-factory-delete-worker-failure"))
        persist()
    finally:
        cloud.tokens.clear()
    return receipt


def resume_dispatch(cloud, locks, document, receipt, persist, sleep=time.sleep):
    remote = receipt.get("remote_run")
    if not remote:
        fl.require(not receipt.get("pending_dispatch") and not receipt.get("remote_artifacts"),
                   "factory-delete-dispatch-reconciliation-required")
        return False
    route = document["route"]
    fl.require(remote.get("kind") == route["kind"] and type(remote.get("run_id")) is int
               and remote["run_id"] > 0, "factory-delete-run-identity-unverified")
    for _ in range(PROVIDER_RUN_POLLS):
        locks.assert_held()
        if route["kind"] == "gha":
            repo = urlsplit(route["repository"]).path.strip("/").removesuffix(".git")
            result = json.loads(cloud.command(["gh", "api", "--method", "GET",
                f"repos/{repo}/actions/runs/{remote['run_id']}", "--hostname", "github.com"]))
            fl.require(result.get("id") == remote["run_id"] and result.get("head_sha") == route["commit"]
                       and result.get("display_title") == "factory-lifecycle [" + document["run_id"] + "]",
                       "factory-delete-run-identity-unverified")
            terminal, successful = result.get("status") == "completed", result.get("conclusion") == "success"
            active = result.get("status") in ("queued", "in_progress", "waiting", "pending", "requested")
        else:
            organization, project, _, _ = unquote(urlsplit(route["repository"]).path).strip("/").split("/")
            pipeline = remote.get("pipeline_id")
            fl.require(type(pipeline) is int and pipeline > 0, "factory-delete-run-identity-unverified")
            endpoint = ("https://dev.azure.com/" + quote(organization, safe="") + "/" + quote(project, safe="")
                        + f"/_apis/pipelines/{pipeline}/runs/{remote['run_id']}?api-version=7.1")
            result = cloud.request("GET", endpoint, "https://app.vssps.visualstudio.com/")[2]
            fl.require(result.get("id") == remote["run_id"] and result.get("pipeline", {}).get("id") == pipeline
                       and result.get("resources", {}).get("repositories", {}).get("self", {}).get("version") == route["commit"],
                       "factory-delete-run-identity-unverified")
            terminal, successful = result.get("state") == "completed", result.get("result") == "succeeded"
            active = result.get("state") in ("inProgress", "canceling")
        if terminal:
            receipt["remote_terminal"] = True
            persist()
            fl.require(successful, "factory-delete-provider-run-failed")
            return True
        fl.require(active, "factory-delete-provider-state-unverified")
        sleep(15)
    raise fl.Blocked("factory-delete-provider-completion-unverified")


def cleanup_resumed_artifacts(cloud, document, receipt, persist):
    if document["route"]["kind"] != "gha" or receipt.get("remote_artifacts_cleaned"):
        return
    artifacts = receipt.get("remote_artifacts")
    fl.require(isinstance(artifacts, dict) and receipt.get("remote_terminal") is True,
               "factory-delete-remote-artifacts-unverified")
    prefix = "AIF_LIFECYCLE_" + document["run_id"].replace("-", "").upper()
    ref = "refs/tags/aifactory-runs/" + document["run_id"]
    namespace = document["route"]["auth_namespace"]
    fl.require(artifacts.get("ref") == ref and artifacts.get("secret_prefix") == prefix
               and artifacts.get("auth_namespace") == namespace
               and type(artifacts.get("chunks")) is int and 1 <= artifacts["chunks"] <= 16,
               "factory-delete-remote-artifacts-unverified")
    repo = urlsplit(document["route"]["repository"]).path.strip("/").removesuffix(".git")
    existing = json.loads(cloud.command(["gh", "secret", "list", "--repo", "github.com/" + repo,
                                        "--env", namespace, "--json", "name"]))
    fl.require(isinstance(existing, list) and all(isinstance(row, dict) and isinstance(row.get("name"), str)
                                                for row in existing), "factory-delete-secret-inventory-unverified")
    names = {row["name"] for row in existing}
    for index in range(artifacts["chunks"]):
        name = prefix + "_" + str(index)
        if name in names:
            cloud.command(["gh", "secret", "delete", name, "--repo", "github.com/" + repo, "--env", namespace])
    refs = json.loads(cloud.command(["gh", "api", "--method", "GET", "repos/" + repo
        + "/git/matching-refs/" + ref.removeprefix("refs/"), "--hostname", "github.com"]))
    fl.require(isinstance(refs, list), "factory-delete-run-tag-unverified")
    matches = [row for row in refs if row.get("ref") == ref]
    fl.require(len(matches) <= 1 and all(row.get("object", {}).get("sha") == document["route"]["commit"]
                                       for row in matches), "factory-delete-run-tag-changed")
    if matches:
        cloud.command(["gh", "api", "--method", "DELETE", "repos/" + repo + "/git/" + ref,
                       "--hostname", "github.com"])
    receipt["remote_artifacts_cleaned"] = True
    persist()


def execute_cohort(documents, source_root, execution_root, receipt_path, cloud_factory, lock_factory=None):
    fl.require(isinstance(documents, list) and documents, "nonempty-delete-cohort-required")
    documents = json.loads(fl.canonical(documents))
    source_root, execution_root, receipt_path = map(fl.clean_path, (source_root, execution_root, receipt_path))
    fl.require(not execution_root.is_relative_to(source_root) and not source_root.is_relative_to(execution_root)
               and receipt_path.parent == execution_root, "execution-source-isolation-required")
    resume = receipt_path.exists()
    for document in documents:
        (fl._validate_manifest if resume else fl.validate_manifest)(document)
        fl.require(document["operation"] == "delete" and document["deletion"]["inventory_mode"] == CONTRACT,
                   "factory-delete-pipeline-cohort-required")
    first = documents[0]
    fl.require(all(document["target"]["factory_id"] == first["target"]["factory_id"]
                   and document["source"] == first["source"] for document in documents),
               "factory-delete-cohort-binding-mismatch")
    fl.require(len({document["run_id"] for document in documents}) == len(documents),
               "cohort-duplicate-child")
    scopes = [scope.lower() for document in documents for scope in document["locks"]["scopes"]]
    fl.require(len(set(scopes)) == len(scopes), "cohort-duplicate-writable-scope")
    # Overlapping readable closures would need independently bound prior-run evidence.
    # Do not silently accept a re-frozen inventory after another member changed it.
    deletes = {row["id"].lower() for document in documents
               for row in document["deletion"]["resources"] + document["deletion"]["resource_groups"] if row["delete"]}
    for document in documents:
        own = {row["id"].lower() for row in document["deletion"]["resources"] +
               document["deletion"]["resource_groups"] if row["delete"]}
        fl.require(not (set(document["deletion"]["bodies"]) & (deletes - own)),
                   "factory-delete-overlapping-closure-requires-one-manifest")
    require_unique_hub_links(documents)
    # Single-writer: one repository CAS reserves the cohort; its worker and receipts live in the state ref.
    repository = fl.single_writer(first)
    fl.require(all(fl.single_writer(document) == repository for document in documents),
               "cohort-coordination-mode-mismatch")
    clouds = [cloud_factory(document) for document in documents]
    members = [(lock_factory or (fl._RepositoryDeletionMember if repository else fl.BlobLocks))(cloud, document)
               for cloud, document in zip(clouds, documents)]
    union = (fl._RepositoryDeletionCohort if repository else fl._CohortLeases)(members)
    scopes = {scope.lower() for document in documents
              for scope in document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
    # Same aggregate identity as the generic cohort, so catalog verification is shared.
    cohort_hash = fl.digest(sorted(document["manifest_hash"] for document in documents))
    claimed, claim_attempted = set(), False
    if resume:
        aggregate = json.loads(receipt_path.read_text(encoding="utf-8"))
        fl.require(aggregate.get("cohort_hash") == cohort_hash
                   and aggregate.get("contract") == CONTRACT, "factory-delete-resume-binding-mismatch")
        fl.require(isinstance(aggregate.get("children"), list)
                   and len(aggregate["children"]) == len(documents), "factory-delete-resume-incomplete")
    else:
        fl.require(not execution_root.exists(), "new-isolated-execution-directory-required")
        aggregate = {"schema": 1, "contract": CONTRACT, "operation": "delete-factory",
                     "cohort_hash": cohort_hash, "factory_id": first["target"]["factory_id"],
                     "source_commit": first["source"]["commit"], "source_ref": first["source"]["ref"],
                     "status": "validating",
                     "children": [{"schema": 1, "run_id": document["run_id"],
                                   "manifest_hash": document["manifest_hash"],
                                   "manifest_revision": document["manifest_revision"], "operation": "delete",
                                   "source_commit": document["source"]["commit"],
                                   "source_ref": document["source"]["ref"], "target": document["target"],
                                   "cohort_hash": cohort_hash, "status": "validating", "mutation_started": False,
                                   "deleted_resources": []} for document in documents]}
        execution_root.mkdir(parents=True, mode=0o700)

    def persist():
        aggregate["updated_at"] = fl.utc_now()
        aggregate["mutation_started"] = any(row["mutation_started"] for row in aggregate["children"])
        aggregate["lease_context"] = dict(union.held)
        aggregate["locks_retained"] = sorted(union.held)
        aggregate["lock_retained"] = bool(union.held)
        for locks, receipt in zip(members, aggregate["children"]):
            receipt["locks_retained"] = sorted(locks.held)
            receipt["lock_retained"] = bool(locks.held)
            if not repository and receipt["run_id"] in claimed:
                locks.store_receipt(receipt)
        if repository:
            union.persist(aggregate["children"], aggregate)
        for receipt in aggregate["children"]:
            fl.write_receipt(execution_root / (receipt["run_id"] + ".receipt.json"), receipt)
        fl.write_receipt(receipt_path, aggregate)

    try:
        fl.verify_source(clouds[0], source_root, first["source"])
        for cloud in clouds:
            cloud.verify_identity()
        if resume:
            # Durable remote evidence, never a caller-edited local receipt, is the
            # authority for a resumed provider run or retained physical lease.
            for locks, document, receipt in zip(members, documents, aggregate["children"]):
                durable = locks.request("GET", "runs/" + document["run_id"] + ".json")[2]
                fl.require(durable == receipt and receipt.get("run_id") == document["run_id"]
                           and receipt.get("manifest_hash") == document["manifest_hash"],
                           "factory-delete-durable-receipt-mismatch")
            if aggregate["status"] == "succeeded":
                fl.require(not aggregate.get("lock_retained")
                           and all(row.get("status") == "succeeded" and not row.get("lock_retained")
                                   for row in aggregate["children"]), "factory-delete-success-receipt-incomplete")
                for cloud, document in zip(clouds, documents):
                    verify_absent(cloud, document["deletion"]["resources"] + document["deletion"]["resource_groups"])
                return aggregate
            context = aggregate.get("lease_context")
            fl.require(isinstance(context, dict) and set(context) == scopes
                       and all(fl.guid(value) for value in context.values()),
                       "factory-delete-retained-leases-required")
            if repository:
                union.resume(context)
            else:
                union.held = dict(context)
            claim_attempted = True
            for locks, document, receipt in zip(members, documents, aggregate["children"]):
                locks.held = {scope.lower(): context[scope.lower()] for scope in
                              document["locks"]["scopes"] + document["locks"]["common_dependencies"]}
                locks.cohort_guard = union.assert_held
                proof = locks.read_claim()
                fl.require(proof == receipt.get("execution_claim")
                           and proof.get("manifest_hash") == document["manifest_hash"]
                           and proof.get("lease_context_hash") == fl.digest(locks.held),
                           "factory-delete-resume-claim-mismatch")
                locks.execution_claim = fl._ExecutionClaim(document, proof)
                claimed.add(document["run_id"])
                receipt["status"] = "running"
            union.assert_held()
            persist()
        else:
            persist()
            union.acquire()
            for cloud, locks, document, receipt in zip(clouds, members, documents, aggregate["children"]):
                cloud.assert_no_active_runs(locks.enrollment)
                receipt["observed_absent"] = observed_absent(cloud, document)
                fl.verify_project_inventory(cloud, document, receipt["observed_absent"])
                verify_permissions(cloud, document["deletion"], receipt["observed_absent"])
                verify_link_permissions(cloud, document["deletion"].get("hub_links", []))
            for locks, document, receipt in zip(members, documents, aggregate["children"]):
                claim_attempted = True
                locks.claim_run()
                claimed.add(document["run_id"])
                receipt["status"] = "running"
            persist()
        aggregate["status"] = "running"
        for cloud, locks, document, receipt in zip(clouds, members, documents, aggregate["children"]):
            locks.authorize(document)
            if not document["target"]["project_ids"] or all(
                    row.get("already_absent") is True for row in project_rows(document)):
                # Nothing left but groups the review proved gone (aif-138 2026-11-02 run20: the runner VM that runs
                # project pipelines had been deleted too); verify_absent below re-proves them before common teardown.
                receipt["projects_succeeded"] = True
                continue
            resumed = resume_dispatch(cloud, locks, document, receipt, persist)
            if not resumed:
                (fl.github_scoped if document["route"]["kind"] == "gha" else fl.ado_scoped)(
                    cloud, locks, document, source_root, receipt, persist)
            result = fl.verify_worker_receipt(locks, document)
            if resumed:
                cleanup_resumed_artifacts(cloud, document, receipt, persist)
            receipt["worker_receipt"] = result
            receipt["projects_succeeded"] = True
            receipt["deleted_resources"] = sorted(set(receipt["deleted_resources"]) | set(result["deleted_resources"]))
            persist()
        fl.require(all(row.get("projects_succeeded") is True for row in aggregate["children"]),
                   "factory-delete-project-pipeline-barrier-incomplete")
        union.assert_held()
        for cloud, document in zip(clouds, documents):
            verify_absent(cloud, project_rows(document))
        for cloud, locks, document, receipt in zip(clouds, members, documents, aggregate["children"]):
            rows = [row for row in document["deletion"]["resources"] + document["deletion"]["resource_groups"]
                    if row["delete"] and row.get("project_number") is None]
            delete_rows(cloud, locks, document, receipt, persist, rows)
            fl.verify_project_inventory(cloud, document, receipt["deleted_resources"] + receipt.get("observed_absent", []))
            receipt["deletion_complete"] = True
        # Last, once every spoke VNet of the cohort is gone: this factory's own links in a shared hub.
        for cloud, locks, document, receipt in zip(clouds, members, documents, aggregate["children"]):
            if document["deletion"].get("hub_links"):
                unlink_shared_hub(cloud, locks, document, receipt, persist)
        union.assert_held()
        for cloud, document in zip(clouds, documents):
            verify_absent(cloud, document["deletion"]["resources"] + document["deletion"]["resource_groups"])
        if repository:
            # The repository claim is released only against durable succeeded receipts.
            for receipt in aggregate["children"]:
                receipt["status"] = "succeeded"
            aggregate["status"] = "succeeded"
            persist()
            union.release()
            persist()
            return aggregate
        # Store completion while leases still exist; the final receipt is only
        # successful after every lease is durably observed released.
        persist()
        union.release()
        for receipt in aggregate["children"]:
            receipt["status"] = "succeeded"
        aggregate["status"] = "succeeded"
        persist()
    except BaseException as error:
        aggregate["status"] = ("reconciliation-required" if claim_attempted
                               or any(row.get("mutation_started") for row in aggregate["children"]) else "blocked")
        aggregate.update(fl.failure_fields(error, "unexpected-factory-delete-failure"))
        if not claim_attempted:
            try:
                if repository:
                    # The aborted reservation stores these receipts as its terminal records.
                    for receipt in aggregate["children"]:
                        receipt["status"] = aggregate["status"]
                    union.abort(aggregate["children"], aggregate)
                else:
                    union.release()
            except BaseException:
                aggregate["status"] = "reconciliation-required"
        # Keep active durable claims available to an already-running worker.
        for receipt in aggregate["children"]:
            if receipt["run_id"] not in claimed:
                receipt["status"] = aggregate["status"]
        try:
            persist()
        except BaseException:
            # Durable storage refused the write; local evidence still names every retained scope.
            for receipt in aggregate["children"]:
                fl.write_receipt(execution_root / (receipt["run_id"] + ".receipt.json"), receipt)
            fl.write_receipt(receipt_path, aggregate)
    finally:
        for cloud in clouds:
            cloud.tokens.clear()
    return aggregate


# --- bootstrap-operator-teardown-v1 -------------------------------------------------------
# A factory whose Full bootstrap created its groups but that was never registered or enrolled
# has no lease store, route or pipeline. The operator tears it down from frozen, reviewed
# inventory: fresh identity, inventory and active-deployment checks stand in for leases.

TEARDOWN_CONTRACT = "bootstrap-operator-teardown-v1"
TEARDOWN_SOURCE = "bootstrap-record"
RECORD_CONTRACT = "consumed-bootstrap-stage-evidence-v1"
# Audited child collections that link a hub to a spoke network, with fixed API versions.
HUB_LINK_COLLECTIONS = {
    "microsoft.network/privatednszones": ("virtualNetworkLinks", "2024-06-01"),
    "microsoft.network/dnsforwardingrulesets": ("virtualNetworkLinks", "2022-07-01"),
    "microsoft.network/virtualnetworks": ("virtualNetworkPeerings", "2024-05-01"),
}
PEERING_TYPE = "microsoft.network/virtualnetworks/virtualnetworkpeerings"


class _OperatorTeardown:
    """Stands in for leases: there is no enrollment to lease, so callers re-verify fresh state."""

    held = {}

    def __init__(self, document):
        self.document = document

    def assert_held(self):
        return None

    def authorize(self, document):
        fl.require(document is self.document, "bootstrap-teardown-document-changed")


def teardown_digest(document):
    return fl.digest({key: value for key, value in document.items() if key != "manifest_hash"})


def _sorted_ids(values, pattern, allow_empty=False):
    return (isinstance(values, list) and (allow_empty or values) and values == sorted(set(values))
            and all(isinstance(value, str) and value == value.lower() and pattern.fullmatch(value)
                    for value in values))


def _overlaps(left, right):
    return left == right or left.startswith(right + "/") or right.startswith(left + "/")


def _remote(body):
    field = HUB_LINK_TARGETS.get(fl.resource_type_from_id(str(body.get("id", "")).lower()))
    value = ((body.get("properties") or {}).get(field) or {}).get("id") if field else None
    return value.lower() if isinstance(value, str) else ""


def _request(document):
    return {key: value for key, value in document.items() if key not in ("deletion", "manifest_hash")}


def validate_teardown_request(document):
    target = document.get("target") if isinstance(document, dict) else None
    record = document.get("bootstrap_record") if isinstance(document, dict) else None
    fl.require(isinstance(document, dict) and document.get("schema") == 1
               and document.get("contract") == TEARDOWN_CONTRACT and fl.guid(document.get("run_id"))
               and isinstance(target, dict) and all(isinstance(target.get(key), str) and target[key]
                                                    for key in ("factory_id", "scaleset_id"))
               and target.get("environment") in ("dev", "stage", "prod")
               and fl.guid(target.get("tenant_id")) and fl.guid(target.get("subscription_id"))
               and fl.guid((document.get("identity") or {}).get("object_id"))
               and isinstance((document.get("source") or {}).get("commit"), str)
               and re.fullmatch(r"[0-9a-f]{40}", document["source"]["commit"])
               and _sorted_ids(document.get("scopes"), fl.RG_ID)
               and all(scope.split("/")[2] == target["subscription_id"].lower() for scope in document["scopes"])
               and isinstance(record, dict) and record.get("contract") == RECORD_CONTRACT
               and fl.guid(record.get("workflow_id")) and fl.hash_value(record.get("record_hash"))
               and record.get("groups") == document["scopes"]
               and _sorted_ids(record.get("resources"), fl.NESTED_ID, allow_empty=True)
               and all(fl.arm_scope(value) in document["scopes"] for value in record["resources"])
               and isinstance(record.get("principal_ids", []), list)
               and record.get("principal_ids", []) == sorted(set(record.get("principal_ids", [])))
               and all(fl.guid(value) and value == value.lower() for value in record.get("principal_ids", []))
               and _sorted_ids(document.get("hub_scopes"), fl.RG_ID, allow_empty=True)
               and not set(document["hub_scopes"]) & set(document["scopes"])
               and isinstance(document.get("protected_resource_ids"), list)
               and all(isinstance(value, str) and value == value.lower()
                       and (fl.RG_ID.fullmatch(value) or fl.NESTED_ID.fullmatch(value))
                       for value in document["protected_resource_ids"])
               and not any(_overlaps(scope, value) for scope in document["scopes"]
                           for value in document["protected_resource_ids"]),
               "bootstrap-teardown-request-invalid")
    prepared, expires = fl.timestamp(document.get("prepared_at")), fl.timestamp(document.get("expires_at"))
    fl.require(0 < expires - prepared <= TEARDOWN_REQUEST_MAX_LIFETIME_SECONDS, "bootstrap-teardown-request-invalid")


def _hub_inventory(cloud, hub_scopes, code):
    """Every DNS zone/ruleset link and VNet peering in the hub groups, plus the hub VNets."""
    links, hub_vnets = [], set()
    for scope in hub_scopes:
        for row in cloud.list_resources(scope):
            key = str(row.get("id", "")).lower()
            fl.require(fl.arm_scope(key) == scope, code)
            kind = fl.resource_type_from_id(key)
            if kind == VNET_TYPE:
                hub_vnets.add(key)
            if kind not in HUB_LINK_COLLECTIONS:
                continue
            child, api = HUB_LINK_COLLECTIONS[kind]
            items, unsupported = cloud.collection(row["id"] + "/" + child, api)
            fl.require(unsupported is None and isinstance(items, list), code)
            for item in items:
                identifier = str(item.get("id", "")).lower()
                fl.require(identifier.startswith(key + "/") and fl.NESTED_ID.fullmatch(identifier), code)
                links.append({"id": item["id"], "type": fl.resource_type_from_id(identifier), "api_version": api,
                              "remote_virtual_network_id": _remote(item), "side": "hub"})
    return links, hub_vnets


def _hub_links(cloud, document, factory_vnets):
    """Only links and peerings in the configured hub groups whose remote is one of this factory's VNets."""
    links, hub_vnets = _hub_inventory(cloud, document["hub_scopes"], "bootstrap-teardown-hub-inventory-incomplete")
    return [row for row in links if row["remote_virtual_network_id"] in factory_vnets], hub_vnets


def verify_link_permissions(cloud, links):
    verify_permissions(cloud, {"resource_groups": [], "resources": [
        {"id": row["id"], "type": row["type"], "delete": True, "depends_on": []} for row in links]})


def _parent_resource(key):
    """Nearest parent resource of a child or extension resource; never the resource group."""
    head, separator, tail = key.rpartition("/providers/")
    parts = tail.split("/")
    if separator and len(parts) == 3 and "/providers/" in head:
        return head  # Extension resource on a resource, e.g. a role assignment on a vault.
    parent = key.rsplit("/", 2)[0]
    return parent if separator and "/providers/" in parent and len(parent.rsplit("/providers/", 1)[1].split("/")) >= 3 else None


def _cascades(key, item, parent):
    """A true child (not an extension resource such as a role assignment, not a peering) goes with its parent."""
    return (key.startswith(parent + "/") and "/providers/" not in key[len(parent):]
            and str(item.get("type", "")).lower() != PEERING_TYPE and phase(item) not in (0, 1))


def teardown_owner(document, closure, bodies, key):
    """(owner, source) proving this resource belongs to exactly this factory and scale set."""
    record = document["bootstrap_record"]
    core = {field: document["target"][field] for field in ("factory_id", "scaleset_id")}
    body = bodies[key]
    tags = body.get("tags") or {}
    fl.require(isinstance(tags, dict), "malformed-project-ownership-tags")
    owner = {field: tags[tag] for field, tag in fl.TAG_KEYS.items() if tag in tags}
    fl.require(all(owner.get(field, value) == value for field, value in core.items()),
               "bootstrap-teardown-owner-conflict")
    if owner:
        return owner, "tags"
    if key in record["groups"] or hub_covers({"resource_ids": record["resources"]}, key):
        return dict(core), TEARDOWN_SOURCE
    if fl.resource_type_from_id(key).startswith("microsoft.authorization/"):
        # Role assignments carry no tags: only a principal the bootstrap recorded proves them.
        principal = str((body.get("properties") or {}).get("principalId", "")).lower()
        fl.require(principal in record.get("principal_ids", []), "bootstrap-teardown-unowned-resource")
        return dict(core), "bootstrap-principal"
    parent = _parent_resource(key)
    fl.require(parent in bodies, "bootstrap-teardown-unowned-resource")
    return teardown_owner(document, closure, bodies, parent)[0], "parent"


def tag_owner(body):
    tags = body.get("tags") or {}
    return {field: tags[tag] for field, tag in fl.TAG_KEYS.items() if tag in tags}


def managed_parent_owner(key, bodies):
    """Option A (aif-138 2026-11-01, as fl.freeze_deletion_inventory): (parent, owner) of an untaggable child without
    a receipt (a pipeline's role assignment at an owned group, a child of an owned resource) through the tagged
    ancestor it is deleted with, or None. fl.managed_parent_id never adopts an untagged top-level resource."""
    try:
        parent = fl.managed_parent_id(key, bodies, {})
        ancestor = parent
        while not tag_owner(bodies[ancestor]):
            ancestor = fl.managed_parent_id(ancestor, bodies, {})
    except fl.Blocked:
        return None
    return parent, tag_owner(bodies[ancestor])


# Network resources a project pipeline deploys untagged into the common group and attaches to its subnets.
ATTACHED_SUBNET_TYPES = {"microsoft.network/networksecuritygroups", "microsoft.network/routetables"}


def attached_subnet_owner(key, bodies, hub, core_owner):
    """(VNet ids, owner) of an untagged NSG or route table that only subnets of owned VNets use, or None.

    aif-144 (2026-11-04): the project pipeline deploys each project's NSGs into the common group untagged and option B
    receipts cover only the project group, so the common VNet was retained. A VNet is owned by this factory's tags or
    the access-hub proof; the NSG then leaves with the common teardown, owned by the scale set (no project)."""
    if fl.resource_type_from_id(key) not in ATTACHED_SUBNET_TYPES:
        # A nested child (an NSG's built-in defaultSecurityRules, which have no ARM delete) leaves with the NSG this
        # proves. aif-154 (2026-11-09, ESAF jobs 3b2e6a7e, 49200019): unowned they were retained and the whole-group
        # teardown refused; a managed-parent proof through the untagged NSG then failed the worker's re-proof.
        scope, _, relative = key.partition("/providers/")
        parts = relative.split("/")
        parent = scope + "/providers/" + "/".join(parts[:-2]) if len(parts) > 3 else ""
        if fl.resource_type_from_id(parent) not in ATTACHED_SUBNET_TYPES or parent not in bodies:
            return None
        return attached_subnet_owner(parent, bodies, hub, core_owner)
    subnets = (bodies[key].get("properties") or {}).get("subnets")
    if not isinstance(subnets, list) or not subnets:
        return None
    vnets = set()
    for subnet in subnets:
        identifier = str((subnet or {}).get("id", "") if isinstance(subnet, dict) else "").lower()
        vnet = identifier.rsplit("/subnets/", 1)[0]
        if "/subnets/" not in identifier or fl.resource_type_from_id(vnet) != VNET_TYPE or vnet not in bodies:
            return None
        owner = tag_owner(bodies[vnet])
        if not (hub_covers(hub, vnet) or owner and all(owner.get(field) == value
                                                        for field, value in core_owner.items())):
            return None
        vnets.add(vnet)
    return sorted(vnets), dict(core_owner)


def absent_groups(cloud, scopes):
    """Recorded groups already deleted; only 404 ResourceGroupNotFound proves absence (fl.absent_groups)."""
    return fl.absent_groups(cloud, scopes, "bootstrap-teardown-group-absence-unverified")


def _recorded_vnets(document, absent):
    """The bootstrap-recorded VNets of groups proven absent: their hub links are still this factory's own."""
    return {value for value in document["bootstrap_record"]["resources"]
            if fl.arm_scope(value) in absent and fl.resource_type_from_id(value) == VNET_TYPE
            and value.count("/") == 8}


def freeze_teardown(cloud, document):
    validate_teardown_request(document)
    cloud.verify_identity()
    # Idempotent: a recorded group that is already gone has nothing left to delete; it is recorded, not read.
    absent = absent_groups(cloud, document["scopes"])
    scopes = [scope for scope in document["scopes"] if scope not in absent]
    closure, bodies = fl.collect_resource_closure(cloud, scopes)
    fl.verify_deletion_identity(document, bodies)
    record = document["bootstrap_record"]
    proof = {"resource_ids": record["resources"]}
    explicit = set(document["protected_resource_ids"])
    core = {key: document["target"][key] for key in ("factory_id", "scaleset_id")}
    entries = {}
    for key, body in bodies.items():
        owner, source = teardown_owner(document, closure, bodies, key)
        group = key in closure["groups"]
        # Connectivity types pass only as bootstrap-recorded parts of the factory's own hub.
        fl.require(not protected(body, explicit, proof), "bootstrap-teardown-protected-resource")
        fl.require(group or not owner.get("project_id"), "bootstrap-teardown-project-resources-require-pipelines")
        fl.require(not fl.managed_group_cascades(body, document["target"]["subscription_id"]),
                   "bootstrap-teardown-managed-group-unsupported")
        metadata = closure["groups"].get(key, closure["resources"].get(key))
        fl.require(group or str(metadata["type"]).lower() not in (
            "microsoft.authorization/locks", "microsoft.authorization/denyassignments"),
                   "factory-delete-lock-or-deny-present")
        entries[key] = {"id": body["id"], **metadata, "delete": True, "project_number": None,
                        "ownership_source": source, "owner": owner,
                        "managed_group_ids": [], "depends_on": fl.project_resource_dependencies(body)}
    operations = {}
    for key, item in entries.items():
        if key in closure["groups"]:
            continue
        namespace = item["type"].split("/", 1)[0]
        if namespace not in operations:
            operations[namespace] = set(cloud.provider_operations(namespace))
        item["independent_delete"] = (item["type"].lower() + "/delete" in operations[namespace]
                                      and not platform_child(item))
    # Whole groups go, so a child resource (NSG rule, subnet, zone link, VM extension) leaves with
    # its nearest deleted parent instead of one checked delete each. Ancestors are decided first.
    for key in sorted(entries, key=len):
        item = entries[key]
        if key in closure["groups"]:
            continue
        parents = [parent for parent, candidate in entries.items() if key.startswith(parent + "/")
                   and candidate.get("independent_delete") is True and not candidate.get("delete_via_parent")]
        if item["independent_delete"] and not (parents and _cascades(key, item, max(parents, key=len))):
            continue
        fl.require(parents and phase(item) not in (0, 1), "factory-delete-service-lifecycle-unsupported")
        item["delete_via_parent"] = max(parents, key=len)
    factory_vnets ={key for key in bodies if not fl.RG_ID.fullmatch(key)
                     and fl.resource_type_from_id(key) == "microsoft.network/virtualnetworks"}
    factory_vnets |= _recorded_vnets(document, absent)
    links, hub_vnets = _hub_links(cloud, document, factory_vnets)
    # This factory's own side of each hub peering goes in the same unlink stage.
    links += [{"id": entries[key]["id"], "type": PEERING_TYPE, "api_version": entries[key]["api_version"],
               "remote_virtual_network_id": _remote(bodies[key]), "side": "factory"}
              for key in bodies if not fl.RG_ID.fullmatch(key)
              and fl.resource_type_from_id(key) == PEERING_TYPE and _remote(bodies[key]) in hub_vnets]
    resources = [entries[key] for key in sorted(closure["resources"])]
    data = {"inventory_mode": TEARDOWN_CONTRACT, "inventory_complete": True,
            "flags": dict.fromkeys(DELETE_FLAGS, True), "resource_groups": [entries[key] for key in sorted(closure["groups"])],
            "resources": resources, "inventory_hash": fl.digest(resources), "closure": closure,
            "closure_hash": fl.digest(closure), "bodies": manifest_bodies(bodies),
            "hub_links": sorted(links, key=lambda row: row["id"].lower()),
            "factory_virtual_networks": sorted(factory_vnets), "hub_virtual_networks": sorted(hub_vnets),
            "absent_resource_groups": absent, "request_hash": fl.digest(_request(document))}
    validate_teardown({**document, "deletion": data}, check_hash=False)
    for scope in scopes:
        cloud.assert_no_active_deployments(scope)
    verify_permissions(cloud, data)
    verify_link_permissions(cloud, [row for row in data["hub_links"] if row["side"] == "hub"])
    return data


def validate_teardown(document, require_unexpired=False, check_hash=True):
    validate_teardown_request(document)
    fl.require(not check_hash or document.get("manifest_hash") == teardown_digest(document),
               "bootstrap-teardown-hash-mismatch")
    fl.require(not require_unexpired or time.time() < fl.timestamp(document["expires_at"]),
               "bootstrap-teardown-expired")
    data = document.get("deletion")
    fl.require(isinstance(data, dict) and data.get("inventory_mode") == TEARDOWN_CONTRACT
               and data.get("inventory_complete") is True and data.get("request_hash") == fl.digest(_request(document))
               and data.get("inventory_hash") == fl.digest(data.get("resources"))
               and data.get("closure_hash") == fl.digest(data.get("closure")) and isinstance(data.get("bodies"), dict),
               "bootstrap-teardown-inventory-unbound")
    validate_flags(data.get("flags"))
    groups, resources = data["resource_groups"], data["resources"]
    absent = data.get("absent_resource_groups", [])
    entries = {row["id"].lower(): row for row in groups + resources}
    fl.require(_sorted_ids(absent, fl.RG_ID, allow_empty=True) and set(absent) <= set(document["scopes"])
               and {row["id"].lower() for row in groups} == set(document["scopes"]) - set(absent)
               and len(entries) == len(groups + resources) and set(entries) == set(data["bodies"])
               and not any(fl.arm_scope(key) in absent for key in entries),
               "bootstrap-teardown-inventory-unbound")
    record = document["bootstrap_record"]
    proof = {"resource_ids": record["resources"]}
    for key, row in entries.items():
        body = data["bodies"][key]
        fl.require(row.get("delete") is True and row.get("body_hash") == fl.resource_digest(body)
                   and fl.arm_scope(key) in document["scopes"] and row.get("project_number") is None
                   and row.get("managed_group_ids") == [], "bootstrap-teardown-inventory-unbound")
        fl.require(not protected(body, document["protected_resource_ids"], proof),
                   "bootstrap-teardown-protected-resource")
        owner, source = teardown_owner(document, data["closure"], data["bodies"], key)
        fl.require(row.get("ownership_source") == source and row.get("owner") == owner
                   and (key in data["closure"]["groups"] or not owner.get("project_id")),
                   "bootstrap-teardown-unowned-resource")
        if not fl.RG_ID.fullmatch(key):
            fl.require(type(row.get("independent_delete")) is bool, "factory-delete-provider-delete-proof-required")
            fl.require(not (row["independent_delete"] and platform_child(row)),
                       "factory-delete-platform-child-delete-forbidden")
            if not row["independent_delete"] or "delete_via_parent" in row:
                parent = row.get("delete_via_parent", "")
                fl.require(parent in entries and key.startswith(parent + "/")
                           and entries[parent].get("independent_delete") is True
                           and "delete_via_parent" not in entries[parent] and phase(row) not in (0, 1)
                           and (not row["independent_delete"] or _cascades(key, row, parent)),
                           "factory-delete-service-cascade-unreviewed")
    vnets ={key for key in entries if not fl.RG_ID.fullmatch(key)
             and fl.resource_type_from_id(key) == "microsoft.network/virtualnetworks"}
    vnets |= _recorded_vnets(document, absent)
    links = data.get("hub_links")
    fl.require(data.get("factory_virtual_networks") == sorted(vnets)
               and _sorted_ids(data.get("hub_virtual_networks"), fl.NESTED_ID, allow_empty=True)
               and all(fl.arm_scope(value) in document["hub_scopes"] for value in data["hub_virtual_networks"])
               and isinstance(links, list) and links == sorted(links, key=lambda row: row["id"].lower())
               and len({row["id"].lower() for row in links}) == len(links),
               "bootstrap-teardown-hub-links-invalid")
    for row in links:
        key = row["id"].lower()
        fl.require(row.get("type") in HUB_LINK_TARGETS and row["type"] == fl.resource_type_from_id(key)
                   and isinstance(row.get("api_version"), str)
                   and (row.get("side") == "hub" and fl.arm_scope(key) in document["hub_scopes"]
                        and row.get("remote_virtual_network_id") in vnets
                        or row.get("side") == "factory" and key in entries and row["type"] == PEERING_TYPE
                        and row.get("remote_virtual_network_id") in data["hub_virtual_networks"]
                        and _remote(data["bodies"][key]) == row["remote_virtual_network_id"]),
                   "bootstrap-teardown-hub-links-invalid")
    ordered_resources(groups + resources)


def _teardown_fresh(cloud, document):
    """Per-delete check: still the reviewed resource, same owner, no new dependency, no deployment running.

    Whole groups are deleted, so the complete inventory is verified only before the first change
    and after the last; an unreviewed new resource still blocks its group's empty-group check.
    """
    bodies, subscription = document["deletion"]["bodies"], document["target"]["subscription_id"]

    def check(row, body):
        key = row["id"].lower()
        before = bodies[key]
        cloud.assert_no_active_deployments(fl.arm_scope(key))
        fl.require(str(body.get("id", "")).lower() == key
                   and str(body.get("type", "")).lower() == str(before.get("type", "")).lower()
                   and body.get("location") == before.get("location")
                   and (body.get("tags") or {}) == (before.get("tags") or {})
                   and (body.get("properties") or {}).get("principalId")
                   == (before.get("properties") or {}).get("principalId")
                   and set(fl.project_resource_dependencies(body)) <= {value.lower() for value in row["depends_on"]}
                   and not fl.managed_group_cascades(body, subscription), "bootstrap-teardown-resource-changed")
    return check


def execute_teardown(document, receipt_path, cloud=None, sleep=time.sleep):
    document = json.loads(fl.canonical(document))
    validate_teardown(document, require_unexpired=True)
    receipt_path = fl.clean_path(receipt_path)
    cloud = cloud or fl.Cloud(document)
    data = document["deletion"]
    receipt = {"schema": 1, "contract": TEARDOWN_CONTRACT, "run_id": document["run_id"],
               "manifest_hash": document["manifest_hash"], "source_commit": document["source"]["commit"],
               "target": document["target"], "status": "running", "mutation_started": False,
               "deleted_hub_links": [], "deleted_resources": [], "observed_absent": [],
               "absent_resource_groups": data.get("absent_resource_groups", [])}

    def persist():
        receipt["updated_at"] = fl.utc_now()
        fl.write_receipt(receipt_path, receipt)

    lease = _OperatorTeardown(document)
    try:
        persist()
        cloud.verify_identity()
        absent = receipt["absent_resource_groups"]
        fl.require(absent_groups(cloud, absent) == absent, "bootstrap-teardown-absent-group-reappeared")
        for scope in document["scopes"]:
            if scope not in absent:
                cloud.assert_no_active_deployments(scope)
        receipt["observed_absent"] = observed_absent(cloud, document)
        fl.verify_project_inventory(cloud, document, receipt["observed_absent"])
        verify_permissions(cloud, data, receipt["observed_absent"])
        # Unlink first: this factory's own hub DNS links and both sides of its hub peerings.
        for link in data["hub_links"]:
            status, _, body = cloud.arm("GET", link["id"], link["api_version"], allowed=(200, 404))
            if status != 404:
                fl.require(_remote(body) == link["remote_virtual_network_id"], "bootstrap-teardown-hub-link-changed")
                receipt.update(mutation_started=True, pending_resource=link["id"])
                persist()
                cloud.arm("DELETE", link["id"], link["api_version"], allowed=(200, 202, 204, 404),
                          headers=delete_condition(body))
                fl.wait_absent(cloud, lease, link["id"], link["api_version"], sleep)
                receipt.pop("pending_resource", None)
            receipt["deleted_hub_links"].append(link["id"])
            if link["side"] == "factory":
                receipt["deleted_resources"].append(link["id"])
            persist()
        delete_rows(cloud, lease, document, receipt, persist,
                    [row for row in data["resources"] + data["resource_groups"] if row["delete"]], sleep,
                    fresh=_teardown_fresh(cloud, document))
        fl.verify_project_inventory(cloud, document, receipt["deleted_resources"] + receipt["observed_absent"])
        receipt["status"] = "succeeded"
    except BaseException as error:
        receipt["status"] = "reconciliation-required" if receipt["mutation_started"] else "blocked"
        receipt.update(fl.failure_fields(error, "unexpected-bootstrap-teardown-failure"))
    finally:
        getattr(cloud, "tokens", {}).clear()
    persist()
    return receipt
