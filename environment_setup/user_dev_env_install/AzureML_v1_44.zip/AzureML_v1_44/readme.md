# Conda version
- 4.14.0
# Pip version
- 22.2.2
# Python version
- 3.8.13
# Azure ML and AutoML version
- 1.44
# Tested OK history: fresh install on DSVM, with MiniConda, started in Admin mode
- 2022-09~01: Ok
- 2022-09-12: Breaking (partner reported, Azure ML/AutoML cannot be installed on DSVM)
- 2022-09-13: Ok (MS CSU + PG fixed it)
- Next test: 2022-12-01: -