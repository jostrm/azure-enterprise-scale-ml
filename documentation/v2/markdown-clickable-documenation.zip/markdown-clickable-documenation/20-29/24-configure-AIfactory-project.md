# Configure AIFactory project
This is ususally done by ESML Core team, before onboarding project team

1) Copy all configuration files, by running [this Notebook](../../../copy_my_subfolders_to_my_grandparent/02_update_templates_QUICK.ipynb)
2) Configure enteprise scale settings
    - settings\enterprise_specific\dev_test_prod_settings.json
3) Configure security_config
    - settings\project_specific\security_config.json
4) Configure lake_settings
    - settings\project_specific\model\lake_settings.json