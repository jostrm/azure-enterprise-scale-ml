# `Infra:AIFactory`: Flow diagrams - Add AIFactory project, Add users (CoreTeam)

## Flow: Add AIFactory ESML Project in DEV, with 3 users
![](./images/13-flowdiagram-add-project-esml.png)

## Flow: Add project team users, to existing AIFactory project in DEV, with 3 users
![](./images/13-flowdiagram-add-project-esml.png)