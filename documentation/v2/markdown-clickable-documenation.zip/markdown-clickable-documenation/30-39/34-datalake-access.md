# HOWTO - Quickstart: Copy AI Factory notebook templates - to accelerate

# Prerequisites 

[HOWTO - install AzureML SDK v1+v2 and ESML accelerator library](../v2/30-39/33-install-azureml-sdk-v1+v2.md)

[HOWTO - Supported use cases & Accelerated use cases](../v2/30-39/33-install-azureml-sdk-v1+v2.md)

# 1) 

# 2) 

# 3) 