# HOWTO - Quickstart: DataOps with Azure Datafactory ESML templates

# Prerequisites

- TBA 

# Context and pippline outputs: DataOps in relation to MLOps

- ![](./images/39-end-2-end-dataops-mlops.png)

# 1) Configure Datafactory with your GIT repo

# 2) Import ESML templates to Azure Data factory

# 3) Configure ESML templates in Azure Data factory

